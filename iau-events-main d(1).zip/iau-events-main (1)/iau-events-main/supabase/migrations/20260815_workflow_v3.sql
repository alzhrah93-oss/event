-- Migration: workflow_v3 (applied to project uobhwrnqgdxcxnclubxm on 2026-08-15)
-- Approval chain v3: organizer submits → head of the organizing entity
-- (dean/manager/president) approves or rejects → IIE dean (super admin)
-- assigns an IIE admin → admin recommends with reason → IIE dean takes the
-- final decision with reason → decision visible to organizer + entity head.
-- Request closes when the organizer submits the final report (unchanged).
--
-- Entity heads are matched to requests through a route key:
--   college:medicine · deanship:student_affairs · institute:… · center:… ·
--   hospital:kfhu · Student Council routes to deanship:student_affairs.
-- Requests whose route key has no registered head (e.g. entity "other")
-- skip the entity stage and land directly in the IIE queue ('new').

-- 1. Entity head identity ----------------------------------------------------
alter table public.profiles
  add column if not exists entity_key text;
create index if not exists profiles_entity_key_idx
  on public.profiles (entity_key) where entity_key is not null;

-- 2. Entity stage fields on requests ----------------------------------------
alter table public.event_requests
  add column if not exists entity_route_key text,
  add column if not exists entity_head_id uuid references public.profiles (id) on delete set null,
  add column if not exists entity_decision text
    check (entity_decision in ('approve', 'not_approve')),
  add column if not exists entity_decision_reason text,
  add column if not exists entity_decided_at timestamptz;

create index if not exists event_requests_entity_route_idx
  on public.event_requests (entity_route_key, status);
create index if not exists event_requests_entity_head_idx
  on public.event_requests (entity_head_id);

-- New submissions start at the entity stage; a routing trigger forwards
-- requests without a registered head straight to the IIE queue.
alter table public.event_requests alter column status set default 'entity_review';

-- 3. Role helpers ------------------------------------------------------------
create or replace function public.is_entity_head()
returns boolean
language sql security definer set search_path = public stable
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'entity_head'
  );
$$;

create or replace function public.current_entity_key()
returns text
language sql security definer set search_path = public stable
as $$
  select entity_key from public.profiles
  where id = (select auth.uid()) and role = 'entity_head';
$$;

-- 4. Routing: entity stage when a head is registered, IIE queue otherwise ----
-- Normalizes in BOTH directions so a client cannot skip the entity stage by
-- inserting status 'new' directly.
create or replace function public.route_new_request()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  if new.status in ('entity_review', 'new') then
    if new.entity_route_key is not null
       and exists (select 1 from public.profiles
                   where role = 'entity_head'
                     and entity_key = new.entity_route_key) then
      new.status := 'entity_review';
    else
      new.status := 'new';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists event_requests_route on public.event_requests;
create trigger event_requests_route
  before insert on public.event_requests
  for each row execute function public.route_new_request();

-- 5. Organizer RLS. WITH CHECK evaluates AFTER before-triggers, so both
-- normalized statuses must be allowed here; the trigger guarantees the
-- entity stage cannot be skipped when a head exists.
drop policy "organizer submits requests" on public.event_requests;
create policy "organizer submits requests" on public.event_requests
  for insert with check (
    (select auth.uid()) = organizer_id
    and status in ('entity_review', 'new'));

-- Organizers may cancel while the request awaits the entity head too
drop policy "organizer cancels own request" on public.event_requests;
create policy "organizer cancels own request" on public.event_requests
  for update
  using (
    organizer_id = (select auth.uid())
    and status in ('entity_review', 'new', 'pending_completion', 'under_review', 'awaiting_final'))
  with check (
    organizer_id = (select auth.uid())
    and status = 'cancelled');

-- 6. Entity head RLS ---------------------------------------------------------
-- Read requests routed to their entity
create policy "entity head reads own entity requests" on public.event_requests
  for select using (
    public.is_entity_head()
    and entity_route_key = public.current_entity_key());

-- Decide on requests awaiting entity review: approve → 'new', reject → 'entity_rejected'
create policy "entity head decides entity_review" on public.event_requests
  for update
  using (
    public.is_entity_head()
    and entity_route_key = public.current_entity_key()
    and status = 'entity_review')
  with check (
    public.is_entity_head()
    and entity_route_key = public.current_entity_key()
    and status in ('new', 'entity_rejected'));

-- Child tables: alignment / history / attachments / final reports
create policy "entity head reads alignment" on public.request_alignment
  for select using (
    exists (select 1 from public.event_requests r
            where r.id = request_id
              and public.is_entity_head()
              and r.entity_route_key = public.current_entity_key()));

create policy "entity head reads history" on public.request_status_history
  for select using (
    exists (select 1 from public.event_requests r
            where r.id = request_id
              and public.is_entity_head()
              and r.entity_route_key = public.current_entity_key()));

create policy "entity head writes history" on public.request_status_history
  for insert with check (
    actor_id = (select auth.uid())
    and exists (select 1 from public.event_requests r
                where r.id = request_id
                  and public.is_entity_head()
                  and r.entity_route_key = public.current_entity_key()));

create policy "entity head reads attachments" on public.attachments
  for select using (
    exists (select 1 from public.event_requests r
            where r.id = request_id
              and public.is_entity_head()
              and r.entity_route_key = public.current_entity_key()));

create policy "entity head reads reports" on public.final_reports
  for select using (
    exists (select 1 from public.event_requests r
            where r.id = request_id
              and public.is_entity_head()
              and r.entity_route_key = public.current_entity_key()));

-- Storage: entity heads may read (sign) every file of their entity's requests,
-- including final-report evidence — they must be able to download report
-- attachments from their dashboard.
drop policy "request files read" on storage.objects;
create policy "request files read" on storage.objects
  for select using (
    bucket_id = 'request-attachments' and (
      exists (select 1 from public.event_requests r
              where r.id::text = (storage.foldername(name))[1]
                and r.organizer_id = (select auth.uid()))
      or (public.is_admin() and (
            name not like '%/report-%'
            or public.has_permission('reports', 'download')))
      or (public.is_entity_head() and
          exists (select 1 from public.event_requests r
                  where r.id::text = (storage.foldername(name))[1]
                    and r.entity_route_key = public.current_entity_key()))));

-- 7. Notifications -----------------------------------------------------------
-- Submission: organizer always; entity head when the request awaits them;
-- super admins when it skipped straight to the IIE queue.
create or replace function public.notify_on_submit()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_user(
    new.organizer_id, 'submitted',
    jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
    new.id);
  if new.status = 'entity_review' then
    perform public.notify_user(
        p.id, 'entity_new_request',
        jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
        new.id)
      from public.profiles p
      where p.role = 'entity_head' and p.entity_key = new.entity_route_key;
  else
    perform public.notify_user(
        p.id, 'new_request',
        jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
        new.id)
      from public.profiles p where p.role = 'super_admin';
  end if;
  return new;
end; $$;

-- Status changes across the whole chain
create or replace function public.notify_on_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare ntype text;
begin
  if new.assigned_admin_id is not null
     and new.assigned_admin_id is distinct from old.assigned_admin_id then
    perform public.notify_user(
      new.assigned_admin_id, 'assigned',
      jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
      new.id);
  end if;

  if new.status = old.status then return new; end if;

  -- Entity head approved → request enters the IIE dean's queue
  if old.status = 'entity_review' and new.status = 'new' then
    perform public.notify_user(
      new.organizer_id, 'entity_approved',
      jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
      new.id);
    perform public.notify_user(
        p.id, 'new_request',
        jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
        new.id)
      from public.profiles p where p.role = 'super_admin';
  end if;

  -- Entity head rejected → organizer hears the reason
  if new.status = 'entity_rejected' then
    perform public.notify_user(
      new.organizer_id, 'entity_rejected',
      jsonb_build_object(
        'requestNumber', new.request_number,
        'title', new.title,
        'reason', coalesce(new.entity_decision_reason, '')),
      new.id);
  end if;

  -- IIE admin recommendation ready → super admins decide
  if new.status = 'awaiting_final' then
    perform public.notify_user(
        p.id, 'recommendation',
        jsonb_build_object(
          'requestNumber', new.request_number,
          'title', new.title,
          'reason', coalesce(new.admin_recommendation_reason, '')),
        new.id)
      from public.profiles p where p.role = 'super_admin';
  end if;

  -- Final decision / cancellation → organizer, and the entity head that
  -- approved the request also hears the final outcome.
  ntype := case new.status
    when 'approved' then 'approved'
    when 'not_approved' then 'not_approved'
    when 'cancelled' then 'cancelled'
    else null end;
  if ntype is not null then
    perform public.notify_user(
      new.organizer_id, ntype,
      jsonb_build_object(
        'requestNumber', new.request_number,
        'title', new.title,
        'reason', coalesce(new.decision_reason, '')),
      new.id);
    if ntype in ('approved', 'not_approved') and new.entity_route_key is not null then
      perform public.notify_user(
          p.id, ntype,
          jsonb_build_object(
            'requestNumber', new.request_number,
            'title', new.title,
            'reason', coalesce(new.decision_reason, '')),
          new.id)
        from public.profiles p
        where p.role = 'entity_head' and p.entity_key = new.entity_route_key;
    end if;
  end if;
  return new;
end; $$;

-- Final report received → organizer (existing) + the entity head
create or replace function public.notify_on_report()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  select organizer_id, request_number, title, entity_route_key into r
    from public.event_requests where id = new.request_id;
  perform public.notify_user(
    r.organizer_id, 'report_received',
    jsonb_build_object('requestNumber', r.request_number, 'title', r.title),
    new.request_id);
  if r.entity_route_key is not null then
    perform public.notify_user(
        p.id, 'report_received',
        jsonb_build_object('requestNumber', r.request_number, 'title', r.title),
        new.request_id)
      from public.profiles p
      where p.role = 'entity_head' and p.entity_key = r.entity_route_key;
  end if;
  return new;
end; $$;

-- 8. Lock down the new trigger/helper functions (qa_hardening pattern) -------
revoke execute on function public.route_new_request() from public, anon, authenticated;

-- 9. Backfill route keys for legacy rows whose detail is a catalogued slug ---
update public.event_requests
  set entity_route_key = organizing_entity || ':' || entity_detail
  where entity_route_key is null
    and organizing_entity in ('college', 'deanship', 'institute', 'center')
    and entity_detail ~ '^[a-z0-9_]+$';
