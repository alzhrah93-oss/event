-- Migration: profiles_and_roles (applied to project uobhwrnqgdxcxnclubxm on 2026-07-15)
-- Roles
create type public.user_role as enum ('organizer', 'admin', 'super_admin');

-- Profiles: one row per auth user
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null,
  national_id text not null default '',
  email text not null,
  phone text not null default '',
  role public.user_role not null default 'organizer',
  permissions jsonb not null default '{}',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Helper: is the current user an admin/super_admin? (security definer avoids
-- recursive RLS when policies on profiles need to check profiles)
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid())
      and role in ('admin', 'super_admin')
  );
$$;

create or replace function public.is_super_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'super_admin'
  );
$$;

-- Read own profile
create policy "read own profile"
  on public.profiles for select
  using ((select auth.uid()) = id);

-- Admins read all profiles
create policy "admins read all profiles"
  on public.profiles for select
  using (public.is_admin());

-- Users may update their own contact fields (not role/permissions —
-- enforced by trigger below)
create policy "update own profile"
  on public.profiles for update
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

-- Super admins manage all profiles
create policy "super admin updates profiles"
  on public.profiles for update
  using (public.is_super_admin())
  with check (public.is_super_admin());

-- Block privilege escalation: non-super-admins cannot change role/permissions
create or replace function public.prevent_privilege_escalation()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if (new.role is distinct from old.role
      or new.permissions is distinct from old.permissions)
     and not public.is_super_admin() then
    raise exception 'Only a super admin can change roles or permissions';
  end if;
  return new;
end;
$$;

create trigger profiles_no_escalation
  before update on public.profiles
  for each row execute function public.prevent_privilege_escalation();

-- Auto-create a profile on sign-up. Role is ALWAYS organizer for client
-- sign-ups; seed/admin accounts are promoted explicitly by the platform team.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, national_id, email, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'national_id', ''),
    coalesce(new.email, ''),
    coalesce(new.raw_user_meta_data ->> 'phone', '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
