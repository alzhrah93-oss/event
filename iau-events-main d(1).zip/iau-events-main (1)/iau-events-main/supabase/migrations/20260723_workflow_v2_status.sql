-- Migration: workflow_v2_status (applied to project uobhwrnqgdxcxnclubxm on 2026-07-23)
-- New status for the two-stage review flow: an assigned admin has submitted a
-- recommendation and the request awaits the super admin's final decision.
-- (Kept separate from workflow_v2 — a new enum value must commit before use.)
alter type public.request_status add value if not exists 'awaiting_final' before 'approved';
