-- Migration: admin_management (applied to project uobhwrnqgdxcxnclubxm on 2026-07-16)
-- Permission helper (security definer avoids recursive RLS)
create or replace function public.has_permission(section text, required text)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid())
      and (role = 'super_admin'
           or (role = 'admin' and permissions ->> section = required))
  );
$$;

-- Defense in depth: deciding requests now requires the 'approve' permission
drop policy "admins update requests" on public.event_requests;
create policy "admins update requests" on public.event_requests
  for update
  using (public.has_permission('requests', 'approve'))
  with check (public.has_permission('requests', 'approve'));

-- Backfill default permissions for existing admins
update public.profiles
  set permissions = '{"requests":"approve","reports":"view","analytics":"view"}'::jsonb
  where role = 'admin' and permissions = '{}'::jsonb;

-- Create a new admin account (super admin only)
create or replace function public.create_admin(p_email text, p_password text, p_name text)
returns uuid
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  uid uuid := gen_random_uuid();
begin
  if not public.is_super_admin() then
    raise exception 'forbidden';
  end if;
  if p_email is null or p_email !~ '^[^\s@]+@[^\s@]+\.[^\s@]+$' then
    raise exception 'invalid_email';
  end if;
  if length(coalesce(p_password, '')) < 8 then
    raise exception 'weak_password';
  end if;
  if exists (select 1 from auth.users where lower(email) = lower(p_email)) then
    raise exception 'email_exists';
  end if;

  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change, email_change_token_new
  ) values (
    '00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated',
    lower(p_email), extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    jsonb_build_object('full_name', p_name), now(), now(), '', '', '', ''
  );
  insert into auth.identities (
    id, user_id, provider_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    gen_random_uuid(), uid, uid::text,
    jsonb_build_object('sub', uid::text, 'email', lower(p_email), 'email_verified', true),
    'email', now(), now(), now()
  );

  update public.profiles
    set role = 'admin',
        full_name = coalesce(nullif(p_name, ''), full_name),
        permissions = '{"requests":"approve","reports":"view","analytics":"view"}'::jsonb
    where id = uid;

  return uid;
end;
$$;

-- Delete an admin account (super admin only; admins only — never organizers/super admins)
create or replace function public.delete_admin(target uuid)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_super_admin() then
    raise exception 'forbidden';
  end if;
  if not exists (select 1 from public.profiles where id = target and role = 'admin') then
    raise exception 'not_an_admin';
  end if;
  delete from auth.users where id = target;
end;
$$;

revoke execute on function public.create_admin(text, text, text) from public, anon;
revoke execute on function public.delete_admin(uuid) from public, anon;
grant execute on function public.create_admin(text, text, text) to authenticated;
grant execute on function public.delete_admin(uuid) to authenticated;
