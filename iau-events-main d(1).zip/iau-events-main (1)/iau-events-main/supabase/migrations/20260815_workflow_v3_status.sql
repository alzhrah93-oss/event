-- Migration: workflow_v3_status (applied to project uobhwrnqgdxcxnclubxm on 2026-08-15)
-- New enum values must be committed before any function/policy references them,
-- so they live in their own migration (same pattern as workflow_v2_status).

-- Entity-approval stage: a request now starts at the head of the organizing
-- entity (dean/manager/president) before it reaches the Institute.
alter type public.request_status add value if not exists 'entity_review' before 'new';
alter type public.request_status add value if not exists 'entity_rejected' after 'not_approved';

-- New role for the heads of organizing entities
alter type public.user_role add value if not exists 'entity_head';
