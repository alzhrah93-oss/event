-- Migration: event_requests (applied to project uobhwrnqgdxcxnclubxm on 2026-07-15)
create type public.request_status as enum
  ('new','pending_completion','under_review','approved','not_approved','cancelled','closed');

-- Per-year counter for human-readable request numbers
create table public.request_counters (
  year int primary key,
  n int not null default 0
);

create table public.event_requests (
  id uuid primary key default gen_random_uuid(),
  request_number text unique,
  organizer_id uuid not null references public.profiles (id) on delete cascade,
  status public.request_status not null default 'new',

  -- 1. Applicant & entity
  organizing_entity text not null,
  applicant_name text not null,
  job_title text not null,
  university_email text not null,
  mobile text not null,
  alt_coordinator text,

  -- 2. Activity
  request_types text[] not null,
  title text not null,
  description text not null,
  activity_date date not null,
  start_time time not null,
  end_time time not null,
  target_audience text[] not null,
  expected_attendance int not null,
  activity_format text not null,

  -- 3. Venue & external participation
  venue text not null,
  external_host text,
  city_country text,
  location_details text,
  external_participation_type text,
  represents_university boolean not null default false,

  -- 4. Participants
  has_students boolean not null default false,
  student_count int,
  has_faculty boolean not null default false,
  faculty_count int,
  has_partners boolean not null default false,

  -- 5. Partners (list of {name, type, has_mou, mou_ref, has_obligation, obligation_note})
  partners jsonb not null default '[]',

  -- 6. Strategic alignment & impact
  sdgs text[] not null default '{}',
  expected_outputs text[] not null default '{}',
  impact_indicators text,
  followup_pathways text[] not null default '{}',

  -- 7. Intellectual property
  presents_ip text not null default 'no',   -- yes | no | unsure
  ip_disclosed boolean,
  ip_prototype boolean,
  ip_patent text,                            -- yes | no | in_progress
  ip_unpublished boolean,
  ip_nda text,                               -- yes | no | institute_decides

  -- 8. Budget & operations
  needs_funding boolean not null default false,
  funding_source text,
  budget_items jsonb not null default '[]',  -- [{item, description, cost, source, justification}]
  needs_labs boolean not null default false,
  labs_details text,
  needs_materials boolean not null default false,
  materials_details text,
  needs_media boolean not null default false,

  -- Administrative (hidden from applicant)
  reviewer_id uuid references public.profiles (id),
  institute_notes text,
  decision_reason text,
  decided_at timestamptz,
  cancelled_at timestamptz,
  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index event_requests_organizer_idx on public.event_requests (organizer_id);
create index event_requests_status_idx on public.event_requests (status);
create index event_requests_date_idx on public.event_requests (activity_date);

-- Request number: REQ-YYYY-NNNN
create or replace function public.generate_request_number()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  yr int := extract(year from now())::int;
  next_n int;
begin
  insert into public.request_counters as rc (year, n) values (yr, 1)
    on conflict (year) do update set n = rc.n + 1
    returning n into next_n;
  new.request_number := 'REQ-' || yr || '-' || lpad(next_n::text, 4, '0');
  return new;
end;
$$;

create trigger event_requests_number
  before insert on public.event_requests
  for each row execute function public.generate_request_number();

create table public.request_alignment (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.event_requests (id) on delete cascade,
  focus_area_id text not null,
  goals text[] not null default '{}'
);
create index request_alignment_request_idx on public.request_alignment (request_id);

create table public.request_status_history (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.event_requests (id) on delete cascade,
  from_status public.request_status,
  to_status public.request_status not null,
  actor_id uuid references public.profiles (id),
  note text,
  created_at timestamptz not null default now()
);
create index request_status_history_request_idx on public.request_status_history (request_id);

create table public.attachments (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.event_requests (id) on delete cascade,
  kind text not null,
  file_name text not null,
  storage_path text not null,
  uploaded_by uuid references public.profiles (id),
  created_at timestamptz not null default now()
);
create index attachments_request_idx on public.attachments (request_id);

-- RLS
alter table public.event_requests enable row level security;
alter table public.request_alignment enable row level security;
alter table public.request_status_history enable row level security;
alter table public.attachments enable row level security;
alter table public.request_counters enable row level security;

-- Organizers: own requests
create policy "organizer reads own requests" on public.event_requests
  for select using ((select auth.uid()) = organizer_id);
create policy "organizer submits requests" on public.event_requests
  for insert with check ((select auth.uid()) = organizer_id and status = 'new');

-- Admins: all requests
create policy "admins read all requests" on public.event_requests
  for select using (public.is_admin());
create policy "admins update requests" on public.event_requests
  for update using (public.is_admin()) with check (public.is_admin());

-- Alignment rows follow parent
create policy "alignment read" on public.request_alignment for select using (
  exists (select 1 from public.event_requests r
          where r.id = request_id
            and (r.organizer_id = (select auth.uid()) or public.is_admin())));
create policy "alignment insert" on public.request_alignment for insert with check (
  exists (select 1 from public.event_requests r
          where r.id = request_id and r.organizer_id = (select auth.uid())));

-- History: readable by owner/admins; inserts by owner (submission/cancel) or admins
create policy "history read" on public.request_status_history for select using (
  exists (select 1 from public.event_requests r
          where r.id = request_id
            and (r.organizer_id = (select auth.uid()) or public.is_admin())));
create policy "history insert own" on public.request_status_history for insert with check (
  actor_id = (select auth.uid()) and (
    public.is_admin() or
    exists (select 1 from public.event_requests r
            where r.id = request_id and r.organizer_id = (select auth.uid()))));

-- Attachments follow parent
create policy "attachments read" on public.attachments for select using (
  exists (select 1 from public.event_requests r
          where r.id = request_id
            and (r.organizer_id = (select auth.uid()) or public.is_admin())));
create policy "attachments insert" on public.attachments for insert with check (
  uploaded_by = (select auth.uid()) and
  exists (select 1 from public.event_requests r
          where r.id = request_id and r.organizer_id = (select auth.uid())));

-- Storage bucket (private)
insert into storage.buckets (id, name, public)
  values ('request-attachments', 'request-attachments', false)
  on conflict (id) do nothing;

create policy "request files owner upload" on storage.objects
  for insert with check (
    bucket_id = 'request-attachments' and
    exists (select 1 from public.event_requests r
            where r.id::text = (storage.foldername(name))[1]
              and r.organizer_id = (select auth.uid())));

create policy "request files read" on storage.objects
  for select using (
    bucket_id = 'request-attachments' and (
      public.is_admin() or
      exists (select 1 from public.event_requests r
              where r.id::text = (storage.foldername(name))[1]
                and r.organizer_id = (select auth.uid()))));
