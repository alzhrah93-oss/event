-- Migration: entity_detail (applied to project uobhwrnqgdxcxnclubxm on 2026-07-30)
-- Which specific entity is organizing: for organizing_entity = 'college'
-- this holds the college slug (see COLLEGES in src/lib/requests/options.ts);
-- for every other entity it holds the free-text name the applicant typed
-- (e.g. the deanship's name).
alter table public.event_requests
  add column if not exists entity_detail text;
