-- Migration: public_events_view (applied to project uobhwrnqgdxcxnclubxm on 2026-07-16)
-- Public calendar/marquee source: ONLY safe display columns of approved events.
-- The view runs with owner privileges (bypasses RLS) by design; no personal
-- data columns (emails, phones, budgets) are exposed.
create or replace view public.public_events as
  select id, title, activity_date, start_time, end_time,
         request_types, venue, location_details, organizing_entity
  from public.event_requests
  where status in ('approved', 'closed');

grant select on public.public_events to anon, authenticated;
