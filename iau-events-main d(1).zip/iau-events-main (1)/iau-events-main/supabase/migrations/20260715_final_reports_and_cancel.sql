-- Migration: final_reports_and_cancel (applied to project uobhwrnqgdxcxnclubxm on 2026-07-15)
-- Final reports (governance guide §11) — one per request
create table public.final_reports (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null unique references public.event_requests (id) on delete cascade,
  implementation_summary text not null,
  actual_date date not null,
  actual_location text not null,
  actual_attendance int not null,
  student_count int not null default 0,
  ideas_received int not null default 0,
  projects_nominated int not null default 0,
  projects_nominated_desc text,
  partnerships text,
  satisfaction text,
  actual_budget jsonb not null default '[]',
  submitted_by uuid references public.profiles (id),
  submitted_at timestamptz not null default now()
);

alter table public.final_reports enable row level security;

create policy "organizer reads own report" on public.final_reports
  for select using (
    exists (select 1 from public.event_requests r
            where r.id = request_id and r.organizer_id = (select auth.uid())));

create policy "admins read all reports" on public.final_reports
  for select using (public.is_admin());

-- Organizer may submit a report only for their own APPROVED request
create policy "organizer submits report" on public.final_reports
  for insert with check (
    submitted_by = (select auth.uid()) and
    exists (select 1 from public.event_requests r
            where r.id = request_id
              and r.organizer_id = (select auth.uid())
              and r.status = 'approved'));

-- Submitting the final report closes the request (+ history)
create or replace function public.close_request_on_report()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.event_requests
    set status = 'closed'
    where id = new.request_id;
  insert into public.request_status_history (request_id, from_status, to_status, actor_id, note)
    values (new.request_id, 'approved', 'closed', new.submitted_by, 'Final report submitted');
  return new;
end;
$$;

create trigger final_report_closes_request
  after insert on public.final_reports
  for each row execute function public.close_request_on_report();

-- Organizer cancel: only own requests, only while reviewable, only to 'cancelled'
create policy "organizer cancels own request" on public.event_requests
  for update
  using (
    organizer_id = (select auth.uid())
    and status in ('new', 'pending_completion', 'under_review'))
  with check (
    organizer_id = (select auth.uid())
    and status = 'cancelled');

-- Stamp cancelled_at / decided_at automatically
create or replace function public.stamp_cancelled_at()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'cancelled' and old.status is distinct from 'cancelled' then
    new.cancelled_at := now();
  end if;
  if new.status in ('approved', 'not_approved')
     and old.status not in ('approved', 'not_approved') then
    new.decided_at := now();
  end if;
  return new;
end;
$$;

create trigger event_requests_stamps
  before update on public.event_requests
  for each row execute function public.stamp_cancelled_at();

-- Follow-up (author_fks_set_null): author references must not block account deletion
alter table public.request_status_history
  drop constraint request_status_history_actor_id_fkey,
  add constraint request_status_history_actor_id_fkey
    foreign key (actor_id) references public.profiles (id) on delete set null;
alter table public.attachments
  drop constraint attachments_uploaded_by_fkey,
  add constraint attachments_uploaded_by_fkey
    foreign key (uploaded_by) references public.profiles (id) on delete set null;
alter table public.final_reports
  drop constraint final_reports_submitted_by_fkey,
  add constraint final_reports_submitted_by_fkey
    foreign key (submitted_by) references public.profiles (id) on delete set null;
alter table public.event_requests
  drop constraint event_requests_reviewer_id_fkey,
  add constraint event_requests_reviewer_id_fkey
    foreign key (reviewer_id) references public.profiles (id) on delete set null;
