-- Migration: notifications (applied to project uobhwrnqgdxcxnclubxm on 2026-07-16)
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  type text not null,           -- submitted | approved | not_approved | cancelled | report_received | report_reminder
  data jsonb not null default '{}',  -- {requestNumber, title, reason?}
  request_id uuid references public.event_requests (id) on delete cascade,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, read, created_at desc);

alter table public.notifications enable row level security;

create policy "own notifications read" on public.notifications
  for select using ((select auth.uid()) = user_id);
create policy "own notifications mark read" on public.notifications
  for update using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

-- Helper used by triggers (definer => bypasses RLS for inserts)
create or replace function public.notify_user(
  p_user uuid, p_type text, p_data jsonb, p_request uuid
) returns void
language sql
security definer
set search_path = public
as $$
  insert into public.notifications (user_id, type, data, request_id)
  values (p_user, p_type, p_data, p_request);
$$;

-- 1. Request submitted
create or replace function public.notify_on_submit()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_user(
    new.organizer_id, 'submitted',
    jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
    new.id);
  return new;
end; $$;
create trigger notify_request_submitted
  after insert on public.event_requests
  for each row execute function public.notify_on_submit();

-- 2. Status changes the organizer must hear about
create or replace function public.notify_on_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare ntype text;
begin
  if new.status = old.status then return new; end if;
  ntype := case new.status
    when 'approved' then 'approved'
    when 'not_approved' then 'not_approved'
    when 'cancelled' then 'cancelled'
    else null end;
  if ntype is not null then
    perform public.notify_user(
      new.organizer_id, ntype,
      jsonb_build_object(
        'requestNumber', new.request_number,
        'title', new.title,
        'reason', coalesce(new.decision_reason, '')),
      new.id);
  end if;
  return new;
end; $$;
create trigger notify_request_status
  after update on public.event_requests
  for each row execute function public.notify_on_status_change();

-- 3. Final report received
create or replace function public.notify_on_report()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  select organizer_id, request_number, title into r
    from public.event_requests where id = new.request_id;
  perform public.notify_user(
    r.organizer_id, 'report_received',
    jsonb_build_object('requestNumber', r.request_number, 'title', r.title),
    new.request_id);
  return new;
end; $$;
create trigger notify_report_received
  after insert on public.final_reports
  for each row execute function public.notify_on_report();

-- Follow-up (lock_notify_user): triggers/service only — not client callers
revoke execute on function public.notify_user(uuid, text, jsonb, uuid) from public, anon, authenticated;
grant execute on function public.notify_user(uuid, text, jsonb, uuid) to service_role;
