-- Migration: ai_features (applied to project uobhwrnqgdxcxnclubxm on 2026-08-16)
-- Stores AI-generated evaluations and cached summaries for the admin workflow.

create table public.ai_evaluations (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null unique references public.event_requests (id) on delete cascade,
  overall_score int not null check (overall_score between 0 and 100),
  -- [{key, score (0-10), comment}]
  criteria jsonb not null default '[]',
  strengths text[] not null default '{}',
  weaknesses text[] not null default '{}',
  recommendation text not null,
  model text not null,
  locale text not null default 'en',
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.ai_summaries (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.event_requests (id) on delete cascade,
  kind text not null check (kind in ('request', 'report')),
  locale text not null,
  summary text not null,
  model text not null,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  unique (request_id, kind, locale)
);

alter table public.ai_evaluations enable row level security;
alter table public.ai_summaries enable row level security;

-- Admin-only surface: the AI panels live exclusively in the admin dashboard.
create policy "admins manage ai evaluations" on public.ai_evaluations
  for all using (public.is_admin()) with check (public.is_admin());

create policy "admins manage ai summaries" on public.ai_summaries
  for all using (public.is_admin()) with check (public.is_admin());
