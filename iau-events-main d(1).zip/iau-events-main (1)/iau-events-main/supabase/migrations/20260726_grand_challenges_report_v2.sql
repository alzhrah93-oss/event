-- Migration: grand_challenges_report_v2 (applied to project uobhwrnqgdxcxnclubxm on 2026-07-26)
-- 1) Grand challenges (التحديات الكبرى) selected per focus area in the
--    request's strategic alignment. Stable english-slug ids; only 3 of the
--    6 focus areas carry challenges (health, energy, future economies).
alter table public.request_alignment
  add column if not exists grand_challenges text[] not null default '{}';

-- 2) Final report v2 — governance guide §11 full field set:
--    satisfaction as a percentage (survey result) and the Institute's
--    internal recommendation on closure. actual_budget jsonb already exists.
alter table public.final_reports
  add column if not exists satisfaction_pct int
    check (satisfaction_pct is null or satisfaction_pct between 0 and 100),
  add column if not exists institute_recommendation text
    check (institute_recommendation in ('closure', 'follow_up', 'transfer'));

-- Admins with final-report access may record the internal recommendation.
-- (has_permission already returns true for super admins.)
create policy "reports admins update" on public.final_reports
  for update
  using (
    public.has_permission('reports', 'view')
    or public.has_permission('reports', 'download'))
  with check (
    public.has_permission('reports', 'view')
    or public.has_permission('reports', 'download'));
