-- Migration: qa_hardening (applied to project uobhwrnqgdxcxnclubxm on 2026-07-23)
-- Fixes from the QA pass (Supabase advisors):
-- 1. Trigger functions were callable through the public RPC surface. Triggers
--    fire regardless of the caller's EXECUTE privilege, so client roles never
--    need it. (is_admin / is_super_admin / has_permission keep EXECUTE — RLS
--    policies evaluate them as the querying role.)
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.prevent_privilege_escalation() from public, anon, authenticated;
revoke execute on function public.generate_request_number() from public, anon, authenticated;
revoke execute on function public.close_request_on_report() from public, anon, authenticated;
revoke execute on function public.stamp_cancelled_at() from public, anon, authenticated;
revoke execute on function public.notify_on_submit() from public, anon, authenticated;
revoke execute on function public.notify_on_status_change() from public, anon, authenticated;
revoke execute on function public.notify_on_report() from public, anon, authenticated;

-- 2. Covering indexes for foreign keys flagged by the performance advisor
create index if not exists attachments_uploaded_by_idx on public.attachments (uploaded_by);
create index if not exists event_requests_reviewer_idx on public.event_requests (reviewer_id);
create index if not exists final_reports_submitted_by_idx on public.final_reports (submitted_by);
create index if not exists notifications_request_idx on public.notifications (request_id);
create index if not exists request_status_history_actor_idx on public.request_status_history (actor_id);
