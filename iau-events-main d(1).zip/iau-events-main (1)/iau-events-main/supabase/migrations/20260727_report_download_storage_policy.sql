-- Migration: report_download_storage_policy (applied to project uobhwrnqgdxcxnclubxm on 2026-07-27)
-- Defense in depth for the final-report download permission: report evidence
-- files (stored as <request-id>/report-<name>) may only be signed/read by
-- admins holding the 'download' level (has_permission is true for super
-- admins). Regular request attachments stay readable by every admin, and
-- organizers keep access to all files of their own requests.
drop policy "request files read" on storage.objects;
create policy "request files read" on storage.objects
  for select using (
    bucket_id = 'request-attachments' and (
      exists (select 1 from public.event_requests r
              where r.id::text = (storage.foldername(name))[1]
                and r.organizer_id = (select auth.uid()))
      or (public.is_admin() and (
            name not like '%/report-%'
            or public.has_permission('reports', 'download')))));
