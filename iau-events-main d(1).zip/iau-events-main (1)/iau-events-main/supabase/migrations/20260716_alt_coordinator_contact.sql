-- Migration: alt_coordinator_contact (applied to project uobhwrnqgdxcxnclubxm on 2026-07-16)
alter table public.event_requests
  add column alt_coordinator_phone text,
  add column alt_coordinator_email text;
