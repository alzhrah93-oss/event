-- Migration: workflow_v2 (applied to project uobhwrnqgdxcxnclubxm on 2026-07-23)
-- Two-stage review: organizer submits → super admin assigns a specific admin →
-- admin recommends approve/not_approve with reasoning → super admin takes the
-- final decision. Also: only @iau.edu.sa accounts may be created.

-- Assignment + recommendation fields
alter table public.event_requests
  add column if not exists assigned_admin_id uuid references public.profiles (id) on delete set null,
  add column if not exists assigned_at timestamptz,
  add column if not exists admin_recommendation text
    check (admin_recommendation in ('approve', 'not_approve')),
  add column if not exists admin_recommendation_reason text,
  add column if not exists recommended_at timestamptz;

create index if not exists event_requests_assigned_idx
  on public.event_requests (assigned_admin_id, status);

-- Organizers may still cancel while a recommendation awaits the final decision
drop policy "organizer cancels own request" on public.event_requests;
create policy "organizer cancels own request" on public.event_requests
  for update
  using (
    organizer_id = (select auth.uid())
    and status in ('new', 'pending_completion', 'under_review', 'awaiting_final'))
  with check (
    organizer_id = (select auth.uid())
    and status = 'cancelled');

-- Submission also alerts every super admin (in-app 'new_request')
create or replace function public.notify_on_submit()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_user(
    new.organizer_id, 'submitted',
    jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
    new.id);
  perform public.notify_user(
      p.id, 'new_request',
      jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
      new.id)
    from public.profiles p where p.role = 'super_admin';
  return new;
end; $$;

-- Assignment → assigned admin; recommendation → super admins; final → organizer
create or replace function public.notify_on_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare ntype text;
begin
  if new.assigned_admin_id is not null
     and new.assigned_admin_id is distinct from old.assigned_admin_id then
    perform public.notify_user(
      new.assigned_admin_id, 'assigned',
      jsonb_build_object('requestNumber', new.request_number, 'title', new.title),
      new.id);
  end if;

  if new.status = old.status then return new; end if;

  if new.status = 'awaiting_final' then
    perform public.notify_user(
        p.id, 'recommendation',
        jsonb_build_object(
          'requestNumber', new.request_number,
          'title', new.title,
          'reason', coalesce(new.admin_recommendation_reason, '')),
        new.id)
      from public.profiles p where p.role = 'super_admin';
  end if;

  ntype := case new.status
    when 'approved' then 'approved'
    when 'not_approved' then 'not_approved'
    when 'cancelled' then 'cancelled'
    else null end;
  if ntype is not null then
    perform public.notify_user(
      new.organizer_id, ntype,
      jsonb_build_object(
        'requestNumber', new.request_number,
        'title', new.title,
        'reason', coalesce(new.decision_reason, '')),
      new.id);
  end if;
  return new;
end; $$;

-- Only @iau.edu.sa accounts may be created (signup + admin creation both pass
-- through auth.users inserts, so this trigger is the single enforcement point)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.email is null or new.email !~* '@iau\.edu\.sa$' then
    raise exception 'email_domain_not_allowed';
  end if;
  insert into public.profiles (id, full_name, national_id, email, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'national_id', ''),
    coalesce(new.email, ''),
    coalesce(new.raw_user_meta_data ->> 'phone', '')
  );
  return new;
end;
$$;

-- create_admin: reject non-IAU emails with the same 'invalid_email' error the UI maps
create or replace function public.create_admin(p_email text, p_password text, p_name text)
returns uuid
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  uid uuid := gen_random_uuid();
begin
  if not public.is_super_admin() then
    raise exception 'forbidden';
  end if;
  if p_email is null
     or p_email !~ '^[^\s@]+@[^\s@]+\.[^\s@]+$'
     or p_email !~* '@iau\.edu\.sa$' then
    raise exception 'invalid_email';
  end if;
  if length(coalesce(p_password, '')) < 8 then
    raise exception 'weak_password';
  end if;
  if exists (select 1 from auth.users where lower(email) = lower(p_email)) then
    raise exception 'email_exists';
  end if;

  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change, email_change_token_new
  ) values (
    '00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated',
    lower(p_email), extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    jsonb_build_object('full_name', p_name), now(), now(), '', '', '', ''
  );
  insert into auth.identities (
    id, user_id, provider_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    gen_random_uuid(), uid, uid::text,
    jsonb_build_object('sub', uid::text, 'email', lower(p_email), 'email_verified', true),
    'email', now(), now(), now()
  );

  update public.profiles
    set role = 'admin',
        full_name = coalesce(nullif(p_name, ''), full_name),
        permissions = '{"requests":"approve","reports":"view","analytics":"view"}'::jsonb
    where id = uid;

  return uid;
end;
$$;
