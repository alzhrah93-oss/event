# IAU Events Platform — Architecture Overview

Event management platform for the Institute of Innovation and Entrepreneurship,
Imam Abdulrahman Bin Faisal University. This document explains the frontend,
backend, and database layers and how they integrate.

## 1. The stack at a glance

| Layer | Technology | Role |
|---|---|---|
| Frontend | Next.js 16 (React 19) + Tailwind CSS v4 | Pages, forms, dashboards, motion |
| Backend | Next.js Server Components + Server Actions | All privileged logic runs on the server |
| Database | Supabase (PostgreSQL) | Data, triggers, Row-Level Security |
| Auth | Supabase Auth | Email/password sessions, password reset |
| Files | Supabase Storage (private bucket) | Request attachments, report evidence |
| Email | Resend REST API | Bilingual transactional email (optional key) |
| i18n | next-intl | English/Arabic catalogs, RTL layout |
| Hosting | Vercel (planned) | Auto-deploy from GitHub, cron scheduler |

One codebase contains both frontend and backend: Next.js renders the UI *and*
executes the server-side logic. There is no separate API server.

## 2. Frontend logic

- **Routing & languages.** Every page lives under `src/app/[locale]/…`. The
  `next-intl` middleware prefixes each URL with `/en` or `/ar`, loads the
  matching message catalog (`messages/en.json`, `messages/ar.json`), and sets
  `dir="rtl"` for Arabic so the whole layout mirrors. A unit test enforces that
  both catalogs always contain exactly the same keys.
- **Server components by default.** Pages fetch their own data on the server
  (lists, dashboards, details) and send ready HTML to the browser. Only
  interactive islands are client components: the 8-step request wizard, the
  language switcher, the notifications bell, the calendar, decision panels.
- **The request wizard** (`src/components/request/`) keeps its state in a
  single typed object, autosaves drafts to `localStorage`, validates each step
  with pure functions (`src/lib/requests/validate.ts` — the same rules run
  again on the server), and reveals conditional sections (off-campus, partners,
  IP, budget) only when relevant.
- **Design system.** IAU palette sampled from the official site (green
  `#12573A` family + gold accent), white-first surfaces, one motion vocabulary
  (scroll reveals, spring-pop cards, animated progress tracker, count-up
  numbers) — all respecting `prefers-reduced-motion`.

## 3. Database logic (PostgreSQL on Supabase)

Core tables:

- `profiles` — one row per user; `role` = organizer / admin / super_admin,
  plus a `permissions` JSON map for admins (e.g. requests: view|approve).
- `event_requests` — the entire governance form (~50 columns + JSON for
  partner and budget lists), lifecycle `status`
  (new → under_review → approved/not_approved → closed, or cancelled),
  reviewer fields, and automatic timestamps.
- `request_alignment` — chosen focus areas and goals per request.
- `request_status_history` — every status change with actor and note; this
  feeds the progress tracker and the admin timeline.
- `final_reports` — one per request (guide §11 fields).
- `attachments` — file metadata pointing into the private storage bucket.
- `notifications` — in-app notifications (`type` + parameters; the UI renders
  them in the viewer's language).
- `public_events` — a **view** exposing only safe display columns of
  approved events to the public site (never emails/phones).

**The database enforces the business rules itself:**

- *Triggers*: request numbers (`REQ-2026-0001`) are generated on insert;
  `cancelled_at`/`decided_at` stamp themselves on status change; submitting a
  final report automatically closes the request; every lifecycle event inserts
  a notification for the organizer; a guard trigger blocks anyone but the
  super admin from changing roles/permissions.
- *Row-Level Security (RLS)* on every table: organizers can read/insert only
  their own requests and may update them **only** to `cancelled` while still
  reviewable; admins can read everything but can decide only if their
  permission map says `requests: approve`; notifications are visible only to
  their owner; storage files are readable only by the owner and admins.
  Because these rules live in the database, they hold even if someone calls
  the API directly and bypasses the UI.
- *Security-definer functions*: `create_admin` / `delete_admin` (callable only
  when the caller is verified as super admin) and `notify_user` (locked to
  triggers/service role).

## 4. Backend logic (Server Actions)

User interactions that change data call **Server Actions** — functions that
run only on the server (`src/lib/**/actions.ts`):

- `submitRequest` — re-validates the whole form (client is never trusted),
  inserts the request (trigger assigns the number), saves alignment rows,
  uploads attachments to the private bucket, writes history, sends the
  confirmation email, and returns the request number for the success page.
- `cancelRequest` — allowed states checked in code *and* by RLS; history +
  email follow.
- `reviewRequest` (admin) — verifies the admin's permission, requires a reason
  for rejection, updates status/reason/notes, writes history, emails the
  organizer on final decisions.
- `submitFinalReport` — inserts the report (DB trigger closes the request),
  uploads evidence, emails confirmation.
- Auth actions (`signUp`, `signIn` per role door, password reset) and
  super-admin actions (`createAdmin`, `deleteAdmin`, `updateAdminPermissions`).

A scheduled endpoint `GET /api/cron/report-reminders` (guarded by a secret,
run daily by Vercel Cron after deployment) finds approved events that ended
5+ working days ago without a final report and sends reminder notifications
and emails, at most once per 3 days per request.

## 5. How the layers integrate

```
Browser (React UI, EN/AR)
   │  reads pages          │ submits forms
   ▼                       ▼
Next.js Server Components  Server Actions ──────────► Resend API (email)
   │            │                │
   │            └── Supabase JS client (user's session JWT)
   ▼                             ▼
Supabase Auth ◄──── session ───► PostgreSQL  ◄─► Storage (private files)
                                  • RLS checks every query against the JWT
                                  • triggers fire on insert/update
                                  • notifications rows appear → header bell
```

The key integration idea: the frontend talks to the database **as the
logged-in user**. The Supabase client attaches the user's session token to
every query, and PostgreSQL's Row-Level Security decides — per row — what that
user may see or change. The server actions add a second validation layer, and
database triggers guarantee the bookkeeping (numbers, timestamps, history,
notifications) can never be skipped. The public site reads only the
`public_events` view, so visitor traffic can never touch personal data.

## 6. Typical flow: one request end-to-end

1. Organizer signs in (Supabase Auth session cookie) → dashboard.
2. Fills the 8-step wizard → `submitRequest` re-validates → row inserted →
   trigger assigns `REQ-2026-NNNN` + notification → files uploaded → history
   row → confirmation email → success page.
3. Admin's queue lists the request (RLS grants admins read access). The admin
   opens the full detail (signed 10-minute URLs for attachments), decides —
   rejection demands a reason. Triggers stamp `decided_at`, insert the
   notification; the action emails the organizer.
4. If approved, the event automatically appears on the public calendar and
   home marquee via the `public_events` view.
5. After the event ends, the organizer submits the final report → trigger
   closes the request → the admin's reports section moves it from "missing"
   to "submitted"; analytics dashboards update from the same tables.
