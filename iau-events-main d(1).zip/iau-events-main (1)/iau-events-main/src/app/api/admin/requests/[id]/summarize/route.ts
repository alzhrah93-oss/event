import { NextResponse } from "next/server";
import { aiConfigured, AI_MODEL } from "@/lib/ai/client";
import {
  buildReportDocument,
  buildRequestDocument,
  runSummary,
  type ReportInput,
  type RequestInput,
  type SummaryKind,
} from "@/lib/ai/summarize";
import { getSessionProfile } from "@/lib/auth/guard";
import { canViewReports } from "@/lib/auth/permissions";
import { createClient } from "@/lib/supabase/server";

export const maxDuration = 120;

/**
 * "Summarize with AI": condenses the event request (kind=request) or its
 * final report (kind=report). Summaries are cached per request+kind+locale;
 * `force` regenerates. Admin dashboard only.
 */
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const me = await getSessionProfile();
  if (!me || !["admin", "super_admin"].includes(me.role)) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as {
    kind?: unknown;
    locale?: unknown;
    force?: unknown;
  };
  const kind: SummaryKind = body.kind === "report" ? "report" : "request";
  const locale = body.locale === "ar" ? "ar" : "en";
  const force = body.force === true;

  // Report summaries follow the same per-admin permission as the report page.
  if (kind === "report" && !canViewReports(me)) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const supabase = await createClient();

  if (!force) {
    const { data: cached } = await supabase
      .from("ai_summaries")
      .select("summary")
      .eq("request_id", id)
      .eq("kind", kind)
      .eq("locale", locale)
      .maybeSingle();
    if (cached) return NextResponse.json({ summary: cached.summary, cached: true });
  }

  if (!aiConfigured()) {
    return NextResponse.json({ error: "not_configured" }, { status: 503 });
  }

  const { data: r } = await supabase
    .from("event_requests")
    .select("*")
    .eq("id", id)
    .single();
  if (!r) return NextResponse.json({ error: "not found" }, { status: 404 });

  let document: string;
  if (kind === "report") {
    const { data: report } = await supabase
      .from("final_reports")
      .select("*")
      .eq("request_id", id)
      .maybeSingle();
    if (!report) {
      return NextResponse.json({ error: "no report" }, { status: 404 });
    }
    document = buildReportDocument(report as ReportInput, r.title);
  } else {
    const { data: alignment } = await supabase
      .from("request_alignment")
      .select("focus_area_id, grand_challenges")
      .eq("request_id", id);
    const input: RequestInput = {
      ...r,
      focus_areas: (alignment ?? []).map((a) => a.focus_area_id as string),
      grand_challenges: (alignment ?? []).flatMap(
        (a) => (a.grand_challenges ?? []) as string[],
      ),
    };
    document = buildRequestDocument(input);
  }

  try {
    const summary = await runSummary(kind, document, locale);
    await supabase.from("ai_summaries").upsert(
      {
        request_id: id,
        kind,
        locale,
        summary,
        model: AI_MODEL,
        created_by: me.id,
        created_at: new Date().toISOString(),
      },
      { onConflict: "request_id,kind,locale" },
    );
    return NextResponse.json({ summary, cached: false });
  } catch (e) {
    console.error("AI summary failed:", e);
    return NextResponse.json({ error: "failed" }, { status: 502 });
  }
}
