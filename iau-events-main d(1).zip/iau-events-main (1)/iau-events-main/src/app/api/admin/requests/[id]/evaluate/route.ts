import { NextResponse } from "next/server";
import { aiConfigured, AI_MODEL } from "@/lib/ai/client";
import { runEvaluation, type EvaluationInput } from "@/lib/ai/evaluate";
import { getSessionProfile } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

export const maxDuration = 120;

/**
 * AI Event Evaluation: reads the full request, asks the model for a
 * criteria-based assessment, and stores it (one evaluation per request;
 * re-running overwrites). Admin dashboard only.
 */
export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const me = await getSessionProfile();
  if (!me || !["admin", "super_admin"].includes(me.role)) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  if (!aiConfigured()) {
    return NextResponse.json({ error: "not_configured" }, { status: 503 });
  }

  const { id } = await params;
  const url = new URL(_req.url);
  const locale = url.searchParams.get("locale") === "ar" ? "ar" : "en";

  const supabase = await createClient();
  const [{ data: r }, { data: alignment }] = await Promise.all([
    supabase.from("event_requests").select("*").eq("id", id).single(),
    supabase
      .from("request_alignment")
      .select("focus_area_id, grand_challenges")
      .eq("request_id", id),
  ]);
  if (!r) return NextResponse.json({ error: "not found" }, { status: 404 });

  const input: EvaluationInput = {
    ...r,
    focus_areas: (alignment ?? []).map((a) => a.focus_area_id as string),
    grand_challenges: (alignment ?? []).flatMap(
      (a) => (a.grand_challenges ?? []) as string[],
    ),
  };

  try {
    const evaluation = await runEvaluation(input, locale);
    const { data: saved, error } = await supabase
      .from("ai_evaluations")
      .upsert(
        {
          request_id: id,
          overall_score: evaluation.overallScore,
          criteria: evaluation.criteria,
          strengths: evaluation.strengths,
          weaknesses: evaluation.weaknesses,
          recommendation: evaluation.recommendation,
          model: AI_MODEL,
          locale,
          created_by: me.id,
          created_at: new Date().toISOString(),
        },
        { onConflict: "request_id" },
      )
      .select("*")
      .single();
    if (error) throw error;
    return NextResponse.json({ evaluation: saved });
  } catch (e) {
    console.error("AI evaluation failed:", e);
    return NextResponse.json({ error: "failed" }, { status: 502 });
  }
}
