import { NextResponse } from "next/server";
import { loadLabeledEvents } from "@/lib/ai/success-data";
import {
  buildSuccessModel,
  MIN_TRAINING_EVENTS,
  predictSuccess,
  type TrainedSuccessModel,
} from "@/lib/ai/success-model";
import { getSessionProfile } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

export const maxDuration = 30;

/**
 * Event Success Prediction: trains a logistic-regression model on the
 * platform's own closed events (no LLM involved) and predicts the success
 * probability of this request. The trained model is cached in-memory per
 * server instance for a few minutes — training is cheap but not free.
 */
let cache: { model: TrainedSuccessModel; at: number } | null = null;
const CACHE_MS = 10 * 60 * 1000;

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const me = await getSessionProfile();
  if (!me || !["admin", "super_admin"].includes(me.role)) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const supabase = await createClient();
  const { data: r } = await supabase
    .from("event_requests")
    .select(
      "expected_attendance, activity_format, request_types, activity_date, start_time, end_time, has_students, has_faculty, has_partners, sdgs, expected_outputs",
    )
    .eq("id", id)
    .single();
  if (!r) return NextResponse.json({ error: "not found" }, { status: 404 });

  let trained = cache && Date.now() - cache.at < CACHE_MS ? cache.model : null;
  if (!trained) {
    const events = await loadLabeledEvents();
    if (events.length < MIN_TRAINING_EVENTS) {
      return NextResponse.json({
        ok: false,
        reason: "insufficient_data",
        needed: MIN_TRAINING_EVENTS,
        available: events.length,
      });
    }
    trained = buildSuccessModel(events);
    cache = { model: trained, at: Date.now() };
  }

  const prediction = predictSuccess(trained, r);
  return NextResponse.json({
    ok: true,
    probability: prediction.probability,
    likelihood: prediction.likelihood,
    factors: prediction.factors,
    metrics: trained.metrics,
    trainedOn: trained.trainedOn,
    positives: trained.positives,
  });
}
