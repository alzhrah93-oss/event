import ExcelJS from "exceljs";
import { NextResponse } from "next/server";
import { FOCUS_AREAS, GRAND_CHALLENGES } from "@/lib/content";
import { canViewAnalytics } from "@/lib/auth/permissions";
import type { SessionProfile } from "@/lib/auth/guard";
import { optionLabel } from "@/lib/requests/display";
import {
  ACTIVITY_FORMATS,
  ALL_ENTITY_DETAILS,
  EXPECTED_OUTPUTS,
  FUNDING_SOURCES,
  ORGANIZING_ENTITIES,
  REQUEST_TYPES,
  SDGS,
  TARGET_AUDIENCE,
  VENUES,
} from "@/lib/requests/options";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const STATUS_LABELS: Record<string, string> = {
  entity_review: "Entity Review",
  new: "New",
  pending_completion: "Pending Completion",
  under_review: "Under Review",
  awaiting_final: "Awaiting Final Decision",
  approved: "Approved",
  not_approved: "Not Approved",
  entity_rejected: "Rejected by Entity",
  cancelled: "Cancelled",
  closed: "Closed",
};

const labels = (list: Parameters<typeof optionLabel>[0], values: string[] | null) =>
  (values ?? []).map((v) => optionLabel(list, v, "en")).join("; ");

const yn = (v: boolean | null) => (v === null ? "" : v ? "Yes" : "No");

type BudgetRow = { approved?: unknown; spent?: unknown };
const budgetTotal = (rows: unknown, key: keyof BudgetRow) =>
  Array.isArray(rows)
    ? rows.reduce((a, r) => a + (Number((r as BudgetRow)[key]) || 0), 0)
    : 0;

/**
 * Full data export for admins: one workbook, one sheet per dataset, with
 * readable English labels, split date parts (year/month/day) and Excel
 * auto-filters so the data can be sliced freely in Excel.
 */
export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return new NextResponse("Unauthorized", { status: 401 });

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, email, role, permissions")
    .eq("id", user.id)
    .single();
  const me: SessionProfile = {
    id: user.id,
    fullName: profile?.full_name ?? "",
    email: profile?.email ?? "",
    role: (profile?.role ?? "organizer") as SessionProfile["role"],
    permissions: (profile?.permissions ?? {}) as Record<string, string>,
    entityKey: null,
  };
  if (!["admin", "super_admin"].includes(me.role) || !canViewAnalytics(me))
    return new NextResponse("Forbidden", { status: 403 });

  // The events-data export covers CLOSED events only (approved + final
  // report submitted) — in-flight requests are not part of the dataset.
  const [
    { data: requests },
    { data: reports },
    { data: alignmentAll },
    { data: historyAll },
  ] = await Promise.all([
    supabase
      .from("event_requests")
      .select("*")
      .eq("status", "closed")
      .order("submitted_at"),
    supabase.from("final_reports").select("*").order("submitted_at"),
    supabase.from("request_alignment").select("*"),
    supabase
      .from("request_status_history")
      .select("*")
      .order("created_at"),
  ]);
  const closedIds = new Set((requests ?? []).map((r) => r.id));
  const alignment = (alignmentAll ?? []).filter((a) =>
    closedIds.has(a.request_id),
  );
  const history = (historyAll ?? []).filter((h) => closedIds.has(h.request_id));
  const closedReports = (reports ?? []).filter((r) =>
    closedIds.has(r.request_id),
  );

  const numberOf = new Map(
    (requests ?? []).map((r) => [r.id, r.request_number as string]),
  );
  const titleOf = new Map((requests ?? []).map((r) => [r.id, r.title as string]));
  const alignmentOf = new Map<string, { focus: string[]; challenges: string[] }>();
  for (const a of alignment) {
    const cur = alignmentOf.get(a.request_id) ?? { focus: [], challenges: [] };
    cur.focus.push(
      FOCUS_AREAS.find((f) => f.id === a.focus_area_id)?.name.en ??
        a.focus_area_id,
    );
    for (const c of (a.grand_challenges ?? []) as string[]) {
      cur.challenges.push(
        GRAND_CHALLENGES.find((g) => g.id === c)?.short.en ?? c,
      );
    }
    alignmentOf.set(a.request_id, cur);
  }
  const reportedIds = new Set(closedReports.map((r) => r.request_id));

  const wb = new ExcelJS.Workbook();
  wb.created = new Date();

  const addSheet = (
    name: string,
    columns: { header: string; key: string; width?: number }[],
    rows: Record<string, unknown>[],
  ) => {
    const ws = wb.addWorksheet(name);
    ws.columns = columns.map((c) => ({ ...c, width: c.width ?? 18 }));
    ws.addRows(rows);
    ws.getRow(1).font = { bold: true };
    ws.autoFilter = {
      from: { row: 1, column: 1 },
      to: { row: 1, column: columns.length },
    };
    ws.views = [{ state: "frozen", ySplit: 1 }];
    return ws;
  };

  addSheet(
    "Requests",
    [
      { header: "Request No", key: "no" },
      { header: "Status", key: "status" },
      { header: "Organizing Entity Type", key: "entityType", width: 20 },
      { header: "Entity Name", key: "entityName", width: 40 },
      { header: "Applicant", key: "applicant", width: 22 },
      { header: "Job Title", key: "job", width: 20 },
      { header: "University Email", key: "email", width: 26 },
      { header: "Event Title", key: "title", width: 36 },
      { header: "Request Types", key: "types", width: 26 },
      { header: "Activity Date", key: "date" },
      { header: "Year", key: "year", width: 8 },
      { header: "Month", key: "month", width: 8 },
      { header: "Day", key: "day", width: 8 },
      { header: "Start", key: "start", width: 10 },
      { header: "End", key: "end", width: 10 },
      { header: "Format", key: "format", width: 12 },
      { header: "Venue", key: "venue", width: 12 },
      { header: "Expected Attendance", key: "attendance", width: 12 },
      { header: "Target Audience", key: "audience", width: 30 },
      { header: "Students Involved", key: "students", width: 10 },
      { header: "Student Count", key: "studentCount", width: 10 },
      { header: "Faculty Involved", key: "faculty", width: 10 },
      { header: "Partners", key: "partners", width: 10 },
      { header: "Focus Areas", key: "focus", width: 34 },
      { header: "Grand Challenges", key: "challenges", width: 34 },
      { header: "SDGs", key: "sdgs", width: 30 },
      { header: "Expected Outputs", key: "outputs", width: 30 },
      { header: "Needs Funding", key: "funding", width: 10 },
      { header: "Funding Source", key: "fundingSource", width: 16 },
      { header: "Submitted At", key: "submitted", width: 20 },
      { header: "Decided At", key: "decided", width: 20 },
      { header: "Decision Reason", key: "reason", width: 30 },
      { header: "Final Report Received", key: "hasReport", width: 12 },
    ],
    (requests ?? []).map((r) => {
      const al = alignmentOf.get(r.id);
      return {
        no: r.request_number,
        status: STATUS_LABELS[r.status] ?? r.status,
        entityType: optionLabel(ORGANIZING_ENTITIES, r.organizing_entity, "en"),
        entityName: r.entity_detail
          ? optionLabel(ALL_ENTITY_DETAILS, r.entity_detail, "en")
          : "",
        applicant: r.applicant_name,
        job: r.job_title,
        email: r.university_email,
        title: r.title,
        types: labels(REQUEST_TYPES, r.request_types),
        date: r.activity_date,
        year: Number(r.activity_date?.slice(0, 4)),
        month: Number(r.activity_date?.slice(5, 7)),
        day: Number(r.activity_date?.slice(8, 10)),
        start: r.start_time?.slice(0, 5),
        end: r.end_time?.slice(0, 5),
        format: optionLabel(ACTIVITY_FORMATS, r.activity_format, "en"),
        venue: optionLabel(VENUES, r.venue, "en"),
        attendance: r.expected_attendance,
        audience: labels(TARGET_AUDIENCE, r.target_audience),
        students: yn(r.has_students),
        studentCount: r.student_count ?? "",
        faculty: yn(r.has_faculty),
        partners: yn(r.has_partners),
        focus: (al?.focus ?? []).join("; "),
        challenges: (al?.challenges ?? []).join("; "),
        sdgs: labels(SDGS, r.sdgs),
        outputs: labels(EXPECTED_OUTPUTS, r.expected_outputs),
        funding: yn(r.needs_funding),
        fundingSource: r.funding_source
          ? optionLabel(FUNDING_SOURCES, r.funding_source, "en")
          : "",
        submitted: r.submitted_at?.slice(0, 16).replace("T", " "),
        decided: r.decided_at?.slice(0, 16).replace("T", " ") ?? "",
        reason: r.decision_reason ?? "",
        hasReport: reportedIds.has(r.id) ? "Yes" : "No",
      };
    }),
  );

  addSheet(
    "Final Reports",
    [
      { header: "Request No", key: "no" },
      { header: "Event Title", key: "title", width: 36 },
      { header: "Submitted At", key: "submitted", width: 20 },
      { header: "Actual Date", key: "date" },
      { header: "Year", key: "year", width: 8 },
      { header: "Month", key: "month", width: 8 },
      { header: "Actual Location", key: "location", width: 26 },
      { header: "Actual Attendance", key: "attendance", width: 12 },
      { header: "Participating Students", key: "students", width: 12 },
      { header: "Ideas Received", key: "ideas", width: 12 },
      { header: "Projects Nominated", key: "projects", width: 12 },
      { header: "Nomination Details", key: "projectsDesc", width: 30 },
      { header: "Partnerships", key: "partnerships", width: 30 },
      { header: "Satisfaction %", key: "satisfactionPct", width: 12 },
      { header: "Satisfaction Notes", key: "satisfaction", width: 26 },
      { header: "Budget Approved (SAR)", key: "approved", width: 14 },
      { header: "Budget Spent (SAR)", key: "spent", width: 14 },
    ],
    closedReports.map((r) => ({
      no: numberOf.get(r.request_id) ?? r.request_id,
      title: titleOf.get(r.request_id) ?? "",
      submitted: r.submitted_at?.slice(0, 16).replace("T", " "),
      date: r.actual_date,
      year: Number(r.actual_date?.slice(0, 4)),
      month: Number(r.actual_date?.slice(5, 7)),
      location: r.actual_location,
      attendance: r.actual_attendance,
      students: r.student_count,
      ideas: r.ideas_received,
      projects: r.projects_nominated,
      projectsDesc: r.projects_nominated_desc ?? "",
      partnerships: r.partnerships ?? "",
      satisfactionPct: r.satisfaction_pct ?? "",
      satisfaction: r.satisfaction ?? "",
      approved: budgetTotal(r.actual_budget, "approved"),
      spent: budgetTotal(r.actual_budget, "spent"),
    })),
  );

  addSheet(
    "Status History",
    [
      { header: "Request No", key: "no" },
      { header: "From", key: "from", width: 22 },
      { header: "To", key: "to", width: 22 },
      { header: "At", key: "at", width: 20 },
      { header: "Note", key: "note", width: 40 },
    ],
    history.map((h) => ({
      no: numberOf.get(h.request_id) ?? h.request_id,
      from: h.from_status ? (STATUS_LABELS[h.from_status] ?? h.from_status) : "",
      to: STATUS_LABELS[h.to_status] ?? h.to_status,
      at: h.created_at?.slice(0, 16).replace("T", " "),
      note: h.note ?? "",
    })),
  );

  const buffer = await wb.xlsx.writeBuffer();
  return new NextResponse(new Uint8Array(buffer as ArrayBuffer), {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="iau-events-data-${new Date().toISOString().slice(0, 10)}.xlsx"`,
    },
  });
}
