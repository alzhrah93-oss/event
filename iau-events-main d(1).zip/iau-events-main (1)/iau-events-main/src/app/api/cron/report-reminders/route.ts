import { NextResponse, type NextRequest } from "next/server";
import { createServiceClient } from "@/lib/supabase/service";
import { addWorkingDays } from "@/lib/requests/working-days";

/**
 * Overdue final-report reminders. Wired to Vercel Cron at deploy
 * (vercel.ts crons → daily). Guarded by CRON_SECRET; safe to invoke manually:
 *   curl -H "authorization: Bearer $CRON_SECRET" /api/cron/report-reminders
 *
 * A request is overdue when: approved, activity ended more than 5 working
 * days ago, and no final report exists. Reminders repeat at most every 3 days.
 */
export async function GET(request: NextRequest) {
  const secret = process.env.CRON_SECRET;
  const auth = request.headers.get("authorization");
  if (!secret || auth !== `Bearer ${secret}`) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const supabase = createServiceClient();
  if (!supabase) {
    return NextResponse.json(
      { error: "service key not configured" },
      { status: 503 },
    );
  }
  const today = new Date().toISOString().slice(0, 10);

  const { data: approved } = await supabase
    .from("event_requests")
    .select("id, request_number, title, activity_date, organizer_id")
    .eq("status", "approved")
    .lt("activity_date", today);

  const { data: reports } = await supabase
    .from("final_reports")
    .select("request_id");
  const reported = new Set((reports ?? []).map((r) => r.request_id));

  const cutoff = new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString();
  let sent = 0;

  for (const r of approved ?? []) {
    if (reported.has(r.id)) continue;
    // overdue = activity_date + 5 working days < today
    if (addWorkingDays(r.activity_date, 5) >= today) continue;

    // 3-day cooldown per request
    const { data: recent } = await supabase
      .from("notifications")
      .select("id")
      .eq("request_id", r.id)
      .eq("type", "report_reminder")
      .gte("created_at", cutoff)
      .limit(1);
    if (recent && recent.length > 0) continue;

    await supabase.rpc("notify_user", {
      p_user: r.organizer_id,
      p_type: "report_reminder",
      p_data: { requestNumber: r.request_number, title: r.title },
      p_request: r.id,
    });
    sent++;
  }

  return NextResponse.json({ ok: true, sent });
}
