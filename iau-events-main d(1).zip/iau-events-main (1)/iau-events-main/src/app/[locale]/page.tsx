import { getTranslations } from "next-intl/server";
import Hero from "@/components/home/Hero";
import Reveal from "@/components/ui/Reveal";
import {
  StrategicAlignment,
  StrategicGoals,
  VisionMission,
} from "@/components/home/StrategySection";
import EventsMarquee from "@/components/events/EventsMarquee";
import { getOngoingAndUpcoming } from "@/lib/events-data";
import { getPublicEvents } from "@/lib/requests/events-server";

export default async function HomePage() {
  const t = await getTranslations("home");
  const events = getOngoingAndUpcoming(await getPublicEvents());

  return (
    <main>
      <Hero />
      <VisionMission />
      <StrategicGoals />
      <StrategicAlignment />
      <section className="bg-white">
        <div className="mx-auto max-w-7xl px-4 py-20">
          <Reveal>
            <h2 className="mb-3 text-center text-3xl font-bold text-iau-green">
              {t("eventsTitle")}
            </h2>
            <div className="mx-auto mb-10 h-1 w-16 rounded bg-iau-gold" />
          </Reveal>
          <EventsMarquee events={events} />
        </div>
      </section>
    </main>
  );
}
