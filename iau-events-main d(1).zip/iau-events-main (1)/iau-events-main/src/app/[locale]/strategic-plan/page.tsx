import { useTranslations } from "next-intl";
import {
  StrategicAlignment,
  StrategicGoals,
  VisionMission,
} from "@/components/home/StrategySection";
import DashboardBackLink from "@/components/ui/DashboardBackLink";
import { STRATEGIC_PLAN_PDF } from "@/lib/content";

export default function StrategicPlanPage() {
  const t = useTranslations("strategicPlan");
  const tp = useTranslations("pages");

  return (
    <main>
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center">
          <div className="text-start">
            <DashboardBackLink />
          </div>
          <h1 className="text-4xl font-bold text-iau-green">
            {tp("strategicPlanTitle")}
          </h1>
          <div className="mx-auto mt-4 h-1 w-16 rounded bg-iau-gold" />
          <p className="mx-auto mt-5 max-w-2xl leading-7 text-gray-600">
            {t("intro")}
          </p>
          <a
            href={STRATEGIC_PLAN_PDF}
            target="_blank"
            rel="noopener noreferrer"
            className="press mt-8 inline-block rounded-md bg-iau-green px-6 py-3 font-semibold text-white shadow-sm transition-colors hover:bg-iau-green-dark"
          >
            {t("viewDocument")}
          </a>
        </div>
      </section>
      <VisionMission />
      <StrategicAlignment />
      <StrategicGoals />
    </main>
  );
}
