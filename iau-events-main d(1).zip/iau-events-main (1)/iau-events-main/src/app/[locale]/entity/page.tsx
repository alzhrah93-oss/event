import { getLocale, getTranslations } from "next-intl/server";
import DashboardCard from "@/components/dashboard/DashboardCard";
import CountUp from "@/components/ui/CountUp";
import Reveal from "@/components/ui/Reveal";
import { requireUser } from "@/lib/auth/guard";
import { optionLabel } from "@/lib/requests/display";
import { ALL_ENTITY_DETAILS } from "@/lib/requests/options";
import { createClient } from "@/lib/supabase/server";

/**
 * Dashboard for entity heads (deans/managers/presidents). RLS already scopes
 * every query to requests routed to the head's entity.
 */
export default async function EntityDashboardPage() {
  const profile = await requireUser(["entity_head"]);
  const t = await getTranslations("entity");
  const locale = (await getLocale()) as "en" | "ar";
  const supabase = await createClient();

  const [{ data: statuses }, { count: reportCount }] = await Promise.all([
    supabase.from("event_requests").select("status"),
    supabase.from("final_reports").select("id", { count: "exact", head: true }),
  ]);

  const count = (fn: (s: string) => boolean) =>
    statuses?.filter((r) => fn(r.status)).length ?? 0;
  const pending = count((s) => s === "entity_review");
  const total = statuses?.length ?? 0;

  const entitySlug = profile.entityKey?.split(":")[1];
  const entityName = entitySlug
    ? optionLabel(ALL_ENTITY_DETAILS, entitySlug, locale)
    : "";

  const stats = [
    { label: t("stats.pending"), value: pending },
    { label: t("stats.total"), value: total },
    { label: t("stats.reports"), value: reportCount ?? 0 },
  ];

  const cards = [
    {
      title: t("cards.requests"),
      desc: t("cards.requestsDesc"),
      href: "/entity/requests",
      badge: pending,
    },
    {
      title: t("cards.reports"),
      desc: t("cards.reportsDesc"),
      href: "/entity/reports",
    },
  ];

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="hero-stagger">
            <h1 className="text-3xl font-bold text-iau-green">{t("title")}</h1>
            <p className="mt-2 text-gray-600">
              {t("welcome", { name: profile.fullName || profile.email })}
            </p>
            {entityName && (
              <p className="mt-1 text-sm font-semibold text-iau-green">
                {entityName}
              </p>
            )}
            <div className="mt-6 flex flex-wrap gap-3">
              {stats.map((s) => (
                <div
                  key={s.label}
                  className="flex items-baseline gap-2 rounded-full border border-gray-200 bg-iau-section px-4 py-1.5"
                >
                  <span className="text-lg font-bold text-iau-green">
                    <CountUp value={s.value} />
                  </span>
                  <span className="text-xs font-medium text-gray-500">
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-6 sm:grid-cols-2">
          {cards.map((c, i) => (
            <Reveal key={c.title} delay={i * 70} pop className="h-full">
              <DashboardCard
                title={c.title}
                description={c.desc}
                href={c.href}
                badge={c.badge}
              />
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
