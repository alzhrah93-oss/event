import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import { requireUser } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

/**
 * Final reports for the head's entity (RLS scopes the join to requests
 * routed to their entity).
 */
export default async function EntityReportsPage() {
  await requireUser(["entity_head"]);
  const t = await getTranslations("admin");
  const te = await getTranslations("entity");
  const locale = await getLocale();
  const supabase = await createClient();

  const { data: reports } = await supabase
    .from("final_reports")
    .select(
      "id, request_id, actual_date, actual_attendance, submitted_at, event_requests!inner(id, request_number, title, applicant_name)",
    )
    .order("submitted_at", { ascending: false });

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <BackLink href="/entity" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {te("cards.reports")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10">
        {!reports || reports.length === 0 ? (
          <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
            {te("reportsEmpty")}
          </p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-iau-section text-xs uppercase tracking-wide text-gray-500">
                  <th className="px-4 py-3 text-start">{t("listHeaders.number")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.titleCol")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.organizer")}</th>
                  <th className="px-4 py-3 text-start">{te("listHeaders.actualDate")}</th>
                  <th className="px-4 py-3 text-start">{te("listHeaders.attendance")}</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((rep, i) => {
                  const req = rep.event_requests as unknown as {
                    id: string;
                    request_number: string;
                    title: string;
                    applicant_name: string;
                  };
                  return (
                    <tr
                      key={rep.id}
                      style={
                        { "--row-delay": `${i * 40}ms` } as React.CSSProperties
                      }
                      className="row-in border-b border-gray-100 transition-colors last:border-0 hover:bg-iau-green-light/30"
                    >
                      <td
                        className="px-4 py-3 font-semibold text-iau-green"
                        dir="ltr"
                      >
                        <Link
                          href={`/entity/reports/${rep.request_id}`}
                          className="hover:underline"
                        >
                          {req.request_number}
                        </Link>
                      </td>
                      <td className="max-w-64 truncate px-4 py-3 text-gray-800">
                        <Link
                          href={`/entity/reports/${rep.request_id}`}
                          className="hover:underline"
                        >
                          {req.title}
                        </Link>
                      </td>
                      <td className="max-w-40 truncate px-4 py-3 text-gray-600">
                        {req.applicant_name}
                      </td>
                      <td className="px-4 py-3 text-gray-600">
                        {fmt.format(new Date(`${rep.actual_date}T00:00:00`))}
                      </td>
                      <td className="px-4 py-3 text-gray-600" dir="ltr">
                        {rep.actual_attendance}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
