import { getLocale, getTranslations } from "next-intl/server";
import { notFound } from "next/navigation";
import BackLink from "@/components/ui/BackLink";
import DownloadReportPdf from "@/components/reports/DownloadReportPdf";
import FinalReportView from "@/components/reports/FinalReportView";
import { requireUser } from "@/lib/auth/guard";
import { formatDate } from "@/lib/requests/display";
import { createClient } from "@/lib/supabase/server";

/**
 * Final report detail for the entity head, attachments downloadable —
 * storage RLS signs files only for requests routed to the head's entity.
 */
export default async function EntityReportDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireUser(["entity_head"]);
  const { id } = await params;
  const t = await getTranslations("admin.reports");
  const locale = (await getLocale()) as "en" | "ar";
  const supabase = await createClient();

  const { data: request } = await supabase
    .from("event_requests")
    .select("id, request_number, title, applicant_name, activity_date, status")
    .eq("id", id)
    .single();
  if (!request) notFound();

  const { data: report } = await supabase
    .from("final_reports")
    .select("*")
    .eq("request_id", id)
    .maybeSingle();
  if (!report) notFound();

  const { data: evidence } = await supabase
    .from("attachments")
    .select("*")
    .eq("request_id", id)
    .eq("kind", "report_evidence");

  const signed = new Map<string, string>();
  for (const a of evidence ?? []) {
    const { data } = await supabase.storage
      .from("request-attachments")
      .createSignedUrl(a.storage_path, 600, { download: true });
    if (data?.signedUrl) signed.set(a.id, data.signedUrl);
  }

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-4xl px-4 py-12">
          <BackLink href="/entity/reports" />
          <h1 className="mt-3 text-2xl font-bold text-iau-green" dir="ltr">
            {t("reportFor", { number: request.request_number })}
          </h1>
          <p className="mt-1 text-gray-600">{request.title}</p>
          <p className="mt-1 text-sm text-gray-500">
            {request.applicant_name} —{" "}
            {formatDate(request.activity_date, locale)}
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-4xl gap-6 px-4 py-10">
        <DownloadReportPdf
          containerId="final-report-pdf"
          fileName={`final-report-${request.request_number}.pdf`}
        />
        <div id="final-report-pdf" className="grid gap-6">
          <FinalReportView
            report={report}
            evidence={evidence ?? []}
            signed={signed}
            mayDownload
          />
        </div>
      </section>
    </main>
  );
}
