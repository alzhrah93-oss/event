import { getLocale, getTranslations } from "next-intl/server";
import { notFound } from "next/navigation";
import BackLink from "@/components/ui/BackLink";
import EntityDecisionPanel from "@/components/entity/EntityDecisionPanel";
import StatusBadge from "@/components/requests/StatusBadge";
import RequestDetailSections, {
  Row,
  Section,
} from "@/components/requests/RequestDetailSections";
import { requireUser } from "@/lib/auth/guard";
import { formatDate } from "@/lib/requests/display";
import type { RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";

type Loc = "en" | "ar";

/**
 * Entity head request detail: the full request info plus the approve/reject
 * panel while the request awaits the entity's decision. RLS guarantees the
 * head only ever reads requests routed to their own entity.
 */
export default async function EntityRequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireUser(["entity_head"]);
  const { id } = await params;
  const t = await getTranslations("admin");
  const te = await getTranslations("entity");
  const locale = (await getLocale()) as Loc;
  const supabase = await createClient();

  const { data: r } = await supabase
    .from("event_requests")
    .select("*")
    .eq("id", id)
    .single();
  if (!r) notFound();

  const [{ data: alignment }, { data: attachments }, { data: history }] =
    await Promise.all([
      supabase.from("request_alignment").select("*").eq("request_id", id),
      supabase
        .from("attachments")
        .select("*")
        .eq("request_id", id)
        .neq("kind", "report_evidence"),
      supabase
        .from("request_status_history")
        .select("*")
        .eq("request_id", id)
        .order("created_at", { ascending: true }),
    ]);

  // Signed URLs for attachments (10 minutes, downloadable)
  const signed = new Map<string, string>();
  for (const a of attachments ?? []) {
    const { data } = await supabase.storage
      .from("request-attachments")
      .createSignedUrl(a.storage_path, 600, { download: true });
    if (data?.signedUrl) signed.set(a.id, data.signedUrl);
  }

  const status = r.status as RequestStatus;
  const dtFmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/entity/requests" />
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-iau-green" dir="ltr">
                {t("detail.title", { number: r.request_number })}
              </h1>
              <p className="mt-1 text-gray-600">{r.title}</p>
              <p className="mt-1 text-sm text-gray-400">
                {t("detail.submittedOn", {
                  date: formatDate(r.submitted_at, locale),
                })}
              </p>
            </div>
            <StatusBadge status={status} />
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-6 px-4 py-10">
        {/* Final decision from the Institute, once taken */}
        {["approved", "not_approved", "closed"].includes(status) && (
          <div className="rounded-xl border border-gray-200 bg-white p-5 text-sm text-gray-600 shadow-sm">
            {t("decision.alreadyDecided")}{" "}
            {r.decided_at &&
              t("decision.decidedOn", {
                date: formatDate(r.decided_at, locale),
              })}
            {r.decision_reason && (
              <p className="mt-2 rounded-md bg-red-50 px-3 py-2 text-red-700">
                {r.decision_reason}
              </p>
            )}
          </div>
        )}

        <RequestDetailSections
          r={r}
          alignment={alignment ?? []}
          attachments={attachments ?? []}
          signed={signed}
          history={history ?? []}
        />

        {/* The head's own recorded decision */}
        {r.entity_decision && (
          <Section title={te("workflow.decisionSection")} delay={400}>
            <Row
              label={te("workflow.decisionLabel")}
              value={
                r.entity_decision === "approve"
                  ? te("workflow.approve")
                  : te("workflow.reject")
              }
            />
            {r.entity_decision_reason && (
              <Row
                label={te("workflow.reasonLabel")}
                value={r.entity_decision_reason}
              />
            )}
            {r.entity_decided_at && (
              <Row
                label={te("workflow.decidedOnLabel")}
                value={dtFmt.format(new Date(r.entity_decided_at))}
              />
            )}
          </Section>
        )}

        {status === "entity_review" && <EntityDecisionPanel requestId={r.id} />}
      </section>
    </main>
  );
}
