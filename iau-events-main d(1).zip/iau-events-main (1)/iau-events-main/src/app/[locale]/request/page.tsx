import { getTranslations } from "next-intl/server";
import BackLink from "@/components/ui/BackLink";
import Wizard from "@/components/request/Wizard";
import { requireUser } from "@/lib/auth/guard";

export default async function RequestPage() {
  const profile = await requireUser(["organizer"]);
  const t = await getTranslations("request");

  return (
    <main className="bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-4xl px-4 py-12">
          <BackLink href="/dashboard" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">{t("title")}</h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <p className="mt-4 text-gray-600">{t("intro")}</p>
        </div>
      </section>
      <Wizard userId={profile.id} />
    </main>
  );
}
