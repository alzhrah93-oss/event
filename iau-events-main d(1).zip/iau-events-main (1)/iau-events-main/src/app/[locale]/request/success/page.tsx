import { getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import { requireUser } from "@/lib/auth/guard";

export default async function RequestSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ rn?: string }>;
}) {
  await requireUser(["organizer"]);
  const { rn } = await searchParams;
  const t = await getTranslations("request.success");

  return (
    <main className="flex min-h-[60vh] items-center justify-center bg-iau-section px-4 py-16">
      <div className="hero-stagger w-full max-w-lg rounded-lg border border-gray-200 bg-white p-10 text-center shadow-sm">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-iau-green-light">
          <svg
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            className="text-iau-green"
            aria-hidden
          >
            <path d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h1 className="mt-5 text-2xl font-bold text-iau-green">{t("title")}</h1>
        <p className="mt-3 leading-7 text-gray-600">{t("body")}</p>
        {rn && (
          <div className="mt-6 rounded-md bg-iau-section px-4 py-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">
              {t("numberLabel")}
            </p>
            <p className="mt-1 text-2xl font-bold text-iau-green" dir="ltr">
              {rn}
            </p>
          </div>
        )}
        <p className="mt-4 text-sm text-gray-500">{t("keep")}</p>
        <Link
          href="/dashboard"
          className="press mt-8 inline-block rounded-md bg-iau-green px-6 py-3 font-semibold text-white transition-colors hover:bg-iau-green-dark"
        >
          {t("goDashboard")}
        </Link>
      </div>
    </main>
  );
}
