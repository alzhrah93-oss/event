import { getLocale, getTranslations } from "next-intl/server";
import { redirect } from "next/navigation";
import BackLink from "@/components/ui/BackLink";
import DataExplorer from "@/components/analytics/DataExplorer";
import { requireUser } from "@/lib/auth/guard";
import { canViewAnalytics } from "@/lib/auth/permissions";
import { loadAnalyticsRows } from "@/lib/analytics/load-rows";

/**
 * The Events Data — an Excel-like, filterable, sortable sheet of closed
 * events (approved + final report submitted) with their alignment and
 * final-report outputs, plus the workbook export. In-flight requests are
 * excluded. Same permission gate as analytics.
 */
export default async function AllDataPage() {
  const me = await requireUser(["admin", "super_admin"]);
  const locale = await getLocale();
  if (!canViewAnalytics(me)) redirect(`/${locale}/admin`);
  const t = await getTranslations("dataPage");
  const rows = await loadAnalyticsRows({ closedOnly: true });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <BackLink href="/admin" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("title")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <p className="mt-4 text-gray-600">{t("intro")}</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10">
        <DataExplorer rows={rows} />
      </section>
    </main>
  );
}
