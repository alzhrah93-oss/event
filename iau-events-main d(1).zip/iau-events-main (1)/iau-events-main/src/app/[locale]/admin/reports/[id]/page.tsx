import { getLocale, getTranslations } from "next-intl/server";
import { notFound, redirect } from "next/navigation";
import { Link } from "@/i18n/navigation";
import AiSummaryPanel from "@/components/admin/AiSummaryPanel";
import BackLink from "@/components/ui/BackLink";
import DownloadReportPdf from "@/components/reports/DownloadReportPdf";
import FinalReportView from "@/components/reports/FinalReportView";
import { requireUser } from "@/lib/auth/guard";
import { canDownloadReports, canViewReports } from "@/lib/auth/permissions";
import { formatDate } from "@/lib/requests/display";
import { createClient } from "@/lib/supabase/server";

export default async function AdminReportDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const me = await requireUser(["admin", "super_admin"]);
  const locale = (await getLocale()) as "en" | "ar";
  if (!canViewReports(me)) redirect(`/${locale}/admin`);
  const { id } = await params;
  const t = await getTranslations("admin.reports");
  const supabase = await createClient();

  const { data: request } = await supabase
    .from("event_requests")
    .select("id, request_number, title, applicant_name, activity_date, status")
    .eq("id", id)
    .single();
  if (!request) notFound();

  const { data: report } = await supabase
    .from("final_reports")
    .select("*")
    .eq("request_id", id)
    .maybeSingle();

  const { data: evidence } = await supabase
    .from("attachments")
    .select("*")
    .eq("request_id", id)
    .eq("kind", "report_evidence");

  const { data: reportSummary } = await supabase
    .from("ai_summaries")
    .select("summary")
    .eq("request_id", id)
    .eq("kind", "report")
    .eq("locale", locale)
    .maybeSingle();

  // Attachment downloads are a separate privilege: super admin always, and
  // only admins the super admin granted the "download" level.
  const mayDownload = canDownloadReports(me);
  const signed = new Map<string, string>();
  if (mayDownload) {
    for (const a of evidence ?? []) {
      const { data } = await supabase.storage
        .from("request-attachments")
        .createSignedUrl(a.storage_path, 600, { download: true });
      if (data?.signedUrl) signed.set(a.id, data.signedUrl);
    }
  }

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-4xl px-4 py-12">
          <BackLink href="/admin/reports" />
          <h1 className="mt-3 text-2xl font-bold text-iau-green" dir="ltr">
            {t("reportFor", { number: request.request_number })}
          </h1>
          <p className="mt-1 text-gray-600">{request.title}</p>
          <p className="mt-1 text-sm text-gray-500">
            {request.applicant_name} —{" "}
            {formatDate(request.activity_date, locale)}
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-4xl gap-6 px-4 py-10">
        {!report ? (
          <div className="goal-item rounded-xl border-2 border-amber-300 bg-white p-10 text-center shadow-sm">
            <p className="text-lg font-semibold text-amber-700">
              {t("notSubmitted")}
            </p>
            <Link
              href={`/admin/requests/${request.id}`}
              className="press mt-5 inline-block rounded-md border border-iau-green px-5 py-2.5 text-sm font-semibold text-iau-green transition-colors hover:bg-iau-green-light"
            >
              {request.request_number}
            </Link>
          </div>
        ) : (
          <>
            <AiSummaryPanel
              requestId={request.id}
              kind="report"
              initialSummary={reportSummary?.summary ?? null}
            />
            <DownloadReportPdf
              containerId="final-report-pdf"
              fileName={`final-report-${request.request_number}.pdf`}
            />
            <div id="final-report-pdf" className="grid gap-6">
              <FinalReportView
                report={report}
                evidence={evidence ?? []}
                signed={signed}
                mayDownload={mayDownload}
              />
            </div>
          </>
        )}
      </section>
    </main>
  );
}
