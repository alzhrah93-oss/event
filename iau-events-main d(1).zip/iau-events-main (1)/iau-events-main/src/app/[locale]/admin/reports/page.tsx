import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import { redirect } from "next/navigation";
import { getLocale as getLoc } from "next-intl/server";
import { requireUser } from "@/lib/auth/guard";
import { canViewReports } from "@/lib/auth/permissions";
import { createClient } from "@/lib/supabase/server";
import { cn } from "@/lib/utils";

export default async function AdminReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string }>;
}) {
  const me = await requireUser(["admin", "super_admin"]);
  if (!canViewReports(me)) redirect(`/${await getLoc()}/admin`);
  const { tab } = await searchParams;
  const active = tab === "missing" ? "missing" : "submitted";
  const t = await getTranslations("admin.reports");
  const locale = await getLocale();
  const supabase = await createClient();
  const today = new Date().toISOString().slice(0, 10);

  // Submitted: requests with a final report (status closed)
  const { data: submitted } = await supabase
    .from("final_reports")
    .select(
      "id, request_id, submitted_at, event_requests ( request_number, title, applicant_name, activity_date )",
    )
    .order("submitted_at", { ascending: false });

  // Missing: approved, event ended, no report row
  const { data: approvedPast } = await supabase
    .from("event_requests")
    .select("id, request_number, title, applicant_name, activity_date")
    .eq("status", "approved")
    .lt("activity_date", today)
    .order("activity_date", { ascending: false });
  const reportedIds = new Set((submitted ?? []).map((s) => s.request_id));
  const missing = (approvedPast ?? []).filter((r) => !reportedIds.has(r.id));

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  const tabs = [
    {
      key: "submitted",
      label: t("submittedTab"),
      count: t("submittedCount", { count: submitted?.length ?? 0 }),
    },
    {
      key: "missing",
      label: t("missingTab"),
      count: t("missingCount", { count: missing.length }),
    },
  ] as const;

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/admin" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("title")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <div className="mt-6 flex flex-wrap gap-2">
            {tabs.map((tb) => (
              <Link
                key={tb.key}
                href={`/admin/reports?tab=${tb.key}`}
                className={cn(
                  "press rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                  tb.key === active
                    ? "border-iau-green bg-iau-green text-white"
                    : "border-gray-300 bg-white text-gray-700 hover:border-iau-green hover:text-iau-green",
                )}
              >
                {tb.label}
                <span
                  className={cn(
                    "ms-2 rounded-full px-2 py-0.5 text-xs font-bold",
                    tb.key === active
                      ? "bg-white/20 text-white"
                      : "bg-iau-green-light text-iau-green",
                  )}
                >
                  {tb.count}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10">
        {active === "submitted" ? (
          !submitted || submitted.length === 0 ? (
            <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
              {t("emptySubmitted")}
            </p>
          ) : (
            <div className="grid gap-3">
              {submitted.map((s, i) => {
                const req = s.event_requests as unknown as {
                  request_number: string;
                  title: string;
                  applicant_name: string;
                  activity_date: string;
                };
                return (
                  <Link
                    key={s.id}
                    href={`/admin/reports/${s.request_id}`}
                    style={{ "--row-delay": `${i * 40}ms` } as React.CSSProperties}
                    className="row-in card-lift press flex flex-wrap items-center justify-between gap-2 rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                  >
                    <div>
                      <span className="font-semibold text-iau-green" dir="ltr">
                        {req.request_number}
                      </span>
                      <span className="ms-3 text-gray-800">{req.title}</span>
                      <p className="mt-1 text-sm text-gray-500">
                        {req.applicant_name}
                      </p>
                    </div>
                    <span className="rounded-full bg-iau-green-light px-3 py-1 text-xs font-semibold text-iau-green">
                      {t("fields.submittedOn", {
                        date: fmt.format(new Date(s.submitted_at)),
                      })}
                    </span>
                  </Link>
                );
              })}
            </div>
          )
        ) : missing.length === 0 ? (
          <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("emptyMissing")}
          </p>
        ) : (
          <div className="grid gap-3">
            {missing.map((r, i) => (
              <Link
                key={r.id}
                href={`/admin/reports/${r.id}`}
                style={{ "--row-delay": `${i * 40}ms` } as React.CSSProperties}
                className="row-in card-lift press flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-200 bg-white p-5 shadow-sm"
              >
                <div>
                  <span className="font-semibold text-iau-green" dir="ltr">
                    {r.request_number}
                  </span>
                  <span className="ms-3 text-gray-800">{r.title}</span>
                  <p className="mt-1 text-sm text-gray-500">{r.applicant_name}</p>
                </div>
                <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
                  {fmt.format(new Date(`${r.activity_date}T00:00:00`))}
                </span>
              </Link>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
