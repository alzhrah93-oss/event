import { getLocale, getTranslations } from "next-intl/server";
import { notFound } from "next/navigation";
import BackLink from "@/components/ui/BackLink";
import AiEvaluationPanel, {
  type AiEvaluationRow,
} from "@/components/admin/AiEvaluationPanel";
import AiSummaryPanel from "@/components/admin/AiSummaryPanel";
import SuccessPredictionPanel from "@/components/admin/SuccessPredictionPanel";
import AssignPanel from "@/components/admin/AssignPanel";
import FinalDecisionPanel from "@/components/admin/FinalDecisionPanel";
import RecommendationPanel from "@/components/admin/RecommendationPanel";
import StatusBadge from "@/components/requests/StatusBadge";
import RequestDetailSections, {
  Row,
  Section,
} from "@/components/requests/RequestDetailSections";
import { requireUser } from "@/lib/auth/guard";
import { canApprove } from "@/lib/auth/permissions";
import { formatDate, optionLabel } from "@/lib/requests/display";
import { ALL_ENTITY_DETAILS } from "@/lib/requests/options";
import type { RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";

type Loc = "en" | "ar";

export default async function AdminRequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const me = await requireUser(["admin", "super_admin"]);
  const { id } = await params;
  const t = await getTranslations("admin");
  const locale = (await getLocale()) as Loc;
  const supabase = await createClient();

  const { data: r } = await supabase
    .from("event_requests")
    .select("*")
    .eq("id", id)
    .single();
  if (!r) notFound();

  const isSuper = me.role === "super_admin";
  const [
    { data: alignment },
    { data: attachments },
    { data: history },
    { data: adminProfiles },
    { data: aiEvaluation },
    { data: aiSummary },
  ] = await Promise.all([
    supabase.from("request_alignment").select("*").eq("request_id", id),
    // Report evidence lives on the final-report page (download is a separate
    // permission there) — only request attachments belong here.
    supabase
      .from("attachments")
      .select("*")
      .eq("request_id", id)
      .neq("kind", "report_evidence"),
    supabase
      .from("request_status_history")
      .select("*")
      .eq("request_id", id)
      .order("created_at", { ascending: true }),
    supabase
      .from("profiles")
      .select("id, full_name, email")
      .eq("role", "admin")
      .order("full_name"),
    supabase
      .from("ai_evaluations")
      .select("*")
      .eq("request_id", id)
      .maybeSingle(),
    supabase
      .from("ai_summaries")
      .select("summary")
      .eq("request_id", id)
      .eq("kind", "request")
      .eq("locale", locale)
      .maybeSingle(),
  ]);

  const admins = (adminProfiles ?? []).map((a) => ({
    id: a.id,
    name: a.full_name || a.email,
  }));
  const assignedAdmin = admins.find((a) => a.id === r.assigned_admin_id);

  // Signed URLs for attachments (10 minutes, downloadable)
  const signed = new Map<string, string>();
  for (const a of attachments ?? []) {
    const { data } = await supabase.storage
      .from("request-attachments")
      .createSignedUrl(a.storage_path, 600, { download: true });
    if (data?.signedUrl) signed.set(a.id, data.signedUrl);
  }

  const status = r.status as RequestStatus;
  const dtFmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  // Entity stage summary (route key = "<type>:<slug>")
  const entitySlug = r.entity_route_key?.split(":")[1] ?? null;

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/admin/requests" />
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-iau-green" dir="ltr">
                {t("detail.title", { number: r.request_number })}
              </h1>
              <p className="mt-1 text-gray-600">{r.title}</p>
              <p className="mt-1 text-sm text-gray-400">
                {t("detail.submittedOn", {
                  date: formatDate(r.submitted_at, locale),
                })}
              </p>
            </div>
            <StatusBadge status={status} />
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-6 px-4 py-10">
        {["approved", "not_approved", "cancelled", "closed"].includes(
          status,
        ) && (
          <div className="rounded-xl border border-gray-200 bg-white p-5 text-sm text-gray-600 shadow-sm">
            {t("decision.alreadyDecided")}{" "}
            {r.decided_at &&
              t("decision.decidedOn", {
                date: formatDate(r.decided_at, locale),
              })}
            {r.decision_reason && (
              <p className="mt-2 rounded-md bg-red-50 px-3 py-2 text-red-700">
                {r.decision_reason}
              </p>
            )}
          </div>
        )}

        <RequestDetailSections
          r={r}
          alignment={alignment ?? []}
          attachments={attachments ?? []}
          signed={signed}
          history={history ?? []}
        />

        {/* AI assistance — summary, evaluation, and success prediction */}
        <AiSummaryPanel
          requestId={r.id}
          kind="request"
          initialSummary={aiSummary?.summary ?? null}
        />
        <AiEvaluationPanel
          requestId={r.id}
          initial={(aiEvaluation as AiEvaluationRow | null) ?? null}
        />
        <SuccessPredictionPanel requestId={r.id} />

        {/* Review workflow — status + actions sit under the full request details */}
        <Section title={t("workflow.sectionTitle")} delay={400}>
          {r.entity_route_key && (
            <Row
              label={t("workflow.entityStage")}
              value={
                status === "entity_review"
                  ? t("workflow.entityPending", {
                      entity: entitySlug
                        ? optionLabel(ALL_ENTITY_DETAILS, entitySlug, locale)
                        : r.entity_route_key,
                    })
                  : r.entity_decision
                    ? r.entity_decision === "approve"
                      ? t("workflow.entityApproved")
                      : t("workflow.entityRejected")
                    : "—"
              }
            />
          )}
          {r.entity_decision_reason && (
            <Row
              label={t("workflow.entityReasonLabel")}
              value={r.entity_decision_reason}
            />
          )}
          {r.entity_decided_at && (
            <Row
              label={t("workflow.entityDecidedOnLabel")}
              value={dtFmt.format(new Date(r.entity_decided_at))}
            />
          )}
          <Row
            label={t("workflow.assignedAdmin")}
            value={
              assignedAdmin ? assignedAdmin.name : t("workflow.notAssignedYet")
            }
          />
          {r.assigned_at && (
            <Row
              label={t("workflow.assignedOnLabel")}
              value={dtFmt.format(new Date(r.assigned_at))}
            />
          )}
          {r.admin_recommendation && (
            <>
              <Row
                label={t("workflow.recommendationLabel")}
                value={
                  r.admin_recommendation === "approve"
                    ? t("workflow.recommendApprove")
                    : t("workflow.recommendNotApprove")
                }
              />
              <Row
                label={t("workflow.reasoningLabel")}
                value={r.admin_recommendation_reason}
              />
              {r.recommended_at && (
                <Row
                  label={t("workflow.recommendedOnLabel")}
                  value={dtFmt.format(new Date(r.recommended_at))}
                />
              )}
            </>
          )}
        </Section>

        {isSuper && status === "entity_review" && (
          <div className="rounded-xl border border-gray-200 bg-white p-5 text-sm text-gray-600 shadow-sm">
            {t("workflow.waitingEntity")}
          </div>
        )}

        {isSuper &&
          ["new", "under_review", "pending_completion"].includes(status) && (
            <AssignPanel
              requestId={r.id}
              admins={admins}
              currentAdminId={r.assigned_admin_id}
            />
          )}

        {!isSuper &&
          status === "under_review" &&
          r.assigned_admin_id === me.id &&
          canApprove(me) && <RecommendationPanel requestId={r.id} />}

        {!isSuper &&
          status === "awaiting_final" &&
          r.assigned_admin_id === me.id && (
            <div className="rounded-xl border border-gray-200 bg-white p-5 text-sm text-gray-600 shadow-sm">
              {t("workflow.waitingSuper")}
            </div>
          )}

        {isSuper && status === "awaiting_final" && (
          <FinalDecisionPanel requestId={r.id} />
        )}
      </section>
    </main>
  );
}
