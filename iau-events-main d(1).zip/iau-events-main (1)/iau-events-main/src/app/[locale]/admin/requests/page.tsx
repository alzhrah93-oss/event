import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import RequestStatusFilter from "@/components/admin/RequestStatusFilter";
import StatusBadge from "@/components/requests/StatusBadge";
import { requireUser } from "@/lib/auth/guard";
import type { RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";

const STATUS_VALUES: RequestStatus[] = [
  "entity_review",
  "new",
  "pending_completion",
  "under_review",
  "awaiting_final",
  "approved",
  "not_approved",
  "entity_rejected",
  "cancelled",
  "closed",
];

/**
 * One queue page, chosen by a status dropdown (?f=): the dashboard cards
 * preselect it (new / awaiting_final), "actionable" is the caller's default
 * work set, and any status — including cancelled and closed — can be picked
 * from the filter.
 */
export default async function AdminRequestsPage({
  searchParams,
}: {
  searchParams: Promise<{ f?: string }>;
}) {
  const me = await requireUser(["admin", "super_admin"]);
  const isSuper = me.role === "super_admin";
  const { f } = await searchParams;
  const mode =
    f === "all" || STATUS_VALUES.includes(f as RequestStatus)
      ? (f as "all" | RequestStatus)
      : "actionable";
  const t = await getTranslations("admin");
  const td = await getTranslations("dashboard.cards");
  const locale = await getLocale();
  const supabase = await createClient();

  let query = supabase
    .from("event_requests")
    .select("id, request_number, title, applicant_name, activity_date, status")
    .order("submitted_at", { ascending: false });
  // Regular admins only handle requests the super admin sent to them
  if (!isSuper) query = query.eq("assigned_admin_id", me.id);
  if (mode === "actionable")
    query = query.in(
      "status",
      isSuper
        ? ["new", "awaiting_final", "pending_completion"]
        : ["under_review"],
    );
  else if (mode !== "all") query = query.eq("status", mode);
  const { data: requests } = await query;

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  const title =
    mode === "new" && isSuper
      ? td("newRequests")
      : mode === "awaiting_final" && isSuper
        ? td("finalDecisions")
        : t("title");

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <BackLink href="/admin" />
          <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-iau-green">{title}</h1>
              <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
            </div>
            <RequestStatusFilter current={mode} />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10">
        {!requests || requests.length === 0 ? (
          <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("empty")}
          </p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-iau-section text-xs uppercase tracking-wide text-gray-500">
                  <th className="px-4 py-3 text-start">{t("listHeaders.number")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.titleCol")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.organizer")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.date")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.status")}</th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r, i) => (
                  <tr
                    key={r.id}
                    style={{ "--row-delay": `${i * 40}ms` } as React.CSSProperties}
                    className="row-in border-b border-gray-100 transition-colors last:border-0 hover:bg-iau-green-light/30"
                  >
                    <td className="px-4 py-3 font-semibold text-iau-green" dir="ltr">
                      <Link href={`/admin/requests/${r.id}`} className="hover:underline">
                        {r.request_number}
                      </Link>
                    </td>
                    <td className="max-w-64 truncate px-4 py-3 text-gray-800">
                      <Link href={`/admin/requests/${r.id}`} className="hover:underline">
                        {r.title}
                      </Link>
                    </td>
                    <td className="max-w-40 truncate px-4 py-3 text-gray-600">
                      {r.applicant_name}
                    </td>
                    <td className="px-4 py-3 text-gray-600">
                      {fmt.format(new Date(`${r.activity_date}T00:00:00`))}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={r.status as RequestStatus} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
