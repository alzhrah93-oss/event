import { getTranslations } from "next-intl/server";
import DashboardCard from "@/components/dashboard/DashboardCard";
import CountUp from "@/components/ui/CountUp";
import Reveal from "@/components/ui/Reveal";
import { requireUser } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

export default async function AdminDashboardPage() {
  const profile = await requireUser(["admin", "super_admin"]);
  const t = await getTranslations("dashboard");
  const ta = await getTranslations("admin");
  const supabase = await createClient();

  const isSuper = profile.role === "super_admin";
  const [{ data: statuses }, { count: reportCount }] = await Promise.all([
    supabase.from("event_requests").select("status, assigned_admin_id"),
    supabase
      .from("final_reports")
      .select("id", { count: "exact", head: true }),
  ]);

  const count = (fn: (r: { status: string; assigned_admin_id: string | null }) => boolean) =>
    statuses?.filter(fn).length ?? 0;

  // Super admin decides on new + recommended; regular admins review what was
  // sent to them.
  const newCount = count((r) => r.status === "new");
  const finalCount = count((r) => r.status === "awaiting_final");
  const assignedToMe = count(
    (r) => r.status === "under_review" && r.assigned_admin_id === profile.id,
  );
  const needsAction = isSuper ? newCount + finalCount : assignedToMe;
  const approved = count((r) => r.status === "approved");

  const stats = [
    { label: ta("stats.needsAction"), value: needsAction },
    { label: ta("stats.approved"), value: approved },
    { label: ta("stats.reports"), value: reportCount ?? 0 },
  ];

  const cards: {
    title: string;
    desc: string;
    href?: string;
    note?: string;
    badge?: number;
  }[] = [
    ...(isSuper
      ? [
          {
            title: t("cards.newRequests"),
            desc: t("cards.newRequestsDesc"),
            href: "/admin/requests?f=new",
            badge: newCount,
          },
          {
            title: t("cards.finalDecisions"),
            desc: t("cards.finalDecisionsDesc"),
            href: "/admin/requests?f=awaiting_final",
            badge: finalCount,
          },
        ]
      : []),
    {
      title: t("cards.eventRequests"),
      desc: t("cards.eventRequestsDesc"),
      href: "/admin/requests",
      badge: needsAction,
    },
    {
      title: t("cards.finalReports"),
      desc: t("cards.finalReportsDesc"),
      href: "/admin/reports",
    },
    {
      title: t("cards.analytics"),
      desc: t("cards.analyticsDesc"),
      href: "/admin/analytics",
    },
    {
      title: t("cards.eventsData"),
      desc: t("cards.eventsDataDesc"),
      href: "/admin/data",
    },
    ...(isSuper
      ? [
          {
            title: t("cards.admins"),
            desc: t("cards.adminsDesc"),
            href: "/admin/admins",
          },
        ]
      : []),
  ];

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="hero-stagger">
            <h1 className="text-3xl font-bold text-iau-green">
              {t("adminTitle")}
            </h1>
            <p className="mt-2 text-gray-600">
              {t("welcome", { name: profile.fullName || profile.email })}
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              {stats.map((s) => (
                <div
                  key={s.label}
                  className="flex items-baseline gap-2 rounded-full border border-gray-200 bg-iau-section px-4 py-1.5"
                >
                  <span className="text-lg font-bold text-iau-green">
                    <CountUp value={s.value} />
                  </span>
                  <span className="text-xs font-medium text-gray-500">
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((c, i) => (
            <Reveal key={c.title} delay={i * 70} pop className="h-full">
              <DashboardCard
                title={c.title}
                description={c.desc}
                href={c.href}
                disabledNote={c.note}
                badge={c.badge}
              />
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
