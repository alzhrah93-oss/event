import { getTranslations } from "next-intl/server";
import BackLink from "@/components/ui/BackLink";
import Reveal from "@/components/ui/Reveal";
import { AddAdminForm, AdminCard, type AdminRow } from "@/components/admin/AdminManager";
import { requireUser } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

export default async function AdminsPage() {
  const me = await requireUser(["super_admin"]);
  const t = await getTranslations("admins");
  const supabase = await createClient();

  const { data: admins } = await supabase
    .from("profiles")
    .select("id, full_name, email, permissions")
    .eq("role", "admin")
    .order("created_at", { ascending: true });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-4xl px-4 py-12">
          <BackLink href="/admin" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("title")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <p className="mt-4 text-gray-600">{t("intro")}</p>
        </div>
      </section>

      <section className="mx-auto grid max-w-4xl gap-6 px-4 py-10">
        <Reveal pop>
          <AddAdminForm />
        </Reveal>

        <h2 className="mt-2 text-lg font-bold text-iau-green">
          {t("listTitle")}
        </h2>
        <div className="rounded-xl border border-gray-200 bg-white p-5 text-sm text-gray-500 shadow-sm">
          {me.fullName} — {t("you")}
        </div>
        {(admins as AdminRow[] | null)?.map((a, i) => (
          <Reveal key={a.id} delay={i * 60} pop>
            <AdminCard admin={a} />
          </Reveal>
        ))}
      </section>
    </main>
  );
}
