import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import { requireUser } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

export default async function AdminCancelledPage() {
  await requireUser(["admin", "super_admin"]);
  const t = await getTranslations("admin");
  const locale = await getLocale();
  const supabase = await createClient();

  const { data: requests } = await supabase
    .from("event_requests")
    .select("id, request_number, title, applicant_name, cancelled_at")
    .eq("status", "cancelled")
    .order("cancelled_at", { ascending: false });

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/admin" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("cancelled.title")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10">
        {!requests || requests.length === 0 ? (
          <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("cancelled.empty")}
          </p>
        ) : (
          <div className="grid gap-3">
            {requests.map((r, i) => (
              <Link
                key={r.id}
                href={`/admin/requests/${r.id}`}
                style={{ "--row-delay": `${i * 40}ms` } as React.CSSProperties}
                className="row-in card-lift press flex flex-wrap items-center justify-between gap-2 rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
              >
                <div>
                  <span className="font-semibold text-iau-green" dir="ltr">
                    {r.request_number}
                  </span>
                  <span className="ms-3 text-gray-800">{r.title}</span>
                  <p className="mt-1 text-sm text-gray-500">{r.applicant_name}</p>
                </div>
                <span className="text-sm text-gray-400">
                  {t("cancelled.cancelledOn", {
                    date: r.cancelled_at
                      ? fmt.format(new Date(r.cancelled_at))
                      : "—",
                  })}
                </span>
              </Link>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
