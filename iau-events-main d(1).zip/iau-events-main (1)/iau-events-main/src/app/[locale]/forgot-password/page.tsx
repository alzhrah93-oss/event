import AuthShell from "@/components/auth/AuthShell";
import { ForgotPasswordForm } from "@/components/auth/PasswordForms";

export default function ForgotPasswordPage() {
  return (
    <AuthShell backHref="/login">
      <ForgotPasswordForm />
    </AuthShell>
  );
}
