import type { Metadata } from "next";
import { Inter, Cairo } from "next/font/google";
import { NextIntlClientProvider, hasLocale } from "next-intl";
import { setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { routing } from "@/i18n/routing";
import SiteHeader, { type HeaderUser } from "@/components/layout/SiteHeader";
import SiteFooter from "@/components/layout/SiteFooter";
import { getSessionProfile } from "@/lib/auth/guard";
import "../globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans-en",
});

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-sans-ar",
});

export const metadata: Metadata = {
  title: "IAU | Institute of Innovation and Entrepreneurship",
  description:
    "Event management platform for the Institute of Innovation and Entrepreneurship at Imam Abdulrahman Bin Faisal University",
};

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) notFound();
  setRequestLocale(locale);

  const profile = await getSessionProfile();
  const headerUser: HeaderUser | null = profile
    ? {
        name: profile.fullName || profile.email,
        dashboardHref:
          profile.role === "organizer"
            ? "/dashboard"
            : profile.role === "entity_head"
              ? "/entity"
              : "/admin",
      }
    : null;

  return (
    <html
      lang={locale}
      dir={locale === "ar" ? "rtl" : "ltr"}
      className={`${inter.variable} ${cairo.variable}`}
    >
      <body className="min-h-screen font-sans antialiased">
        <NextIntlClientProvider>
          <SiteHeader user={headerUser} />
          {children}
          <SiteFooter />
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
