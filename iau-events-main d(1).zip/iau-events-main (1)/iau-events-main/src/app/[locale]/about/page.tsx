import { getLocale, getTranslations } from "next-intl/server";
import DashboardBackLink from "@/components/ui/DashboardBackLink";
import Reveal from "@/components/ui/Reveal";
import { ABOUT_PLATFORM } from "@/lib/content";

/**
 * About the Platform — description, objectives, and target audience of the
 * governance platform (content provided by the Institute, bilingual).
 */
export default async function AboutPage() {
  const t = await getTranslations("about");
  const locale = (await getLocale()) as "en" | "ar";

  return (
    <main>
      {/* Hero */}
      <section className="border-b border-iau-green-light bg-gradient-to-b from-iau-green-light/70 via-iau-green-light/30 to-white">
        <div className="mx-auto max-w-7xl px-4 py-14 text-center">
          <div className="text-start">
            <DashboardBackLink />
          </div>
          <h1 className="hero-stagger text-4xl font-bold text-iau-green">
            {t("title")}
          </h1>
          <div className="mx-auto mt-4 h-1 w-16 rounded bg-iau-gold" />
        </div>
      </section>

      {/* Description */}
      <section className="mx-auto max-w-4xl px-4 py-14">
        <Reveal>
          <div className="rounded-xl border-s-4 border-iau-gold bg-white p-8 shadow-sm ring-1 ring-gray-100">
            <h2 className="text-xl font-bold text-iau-green">
              {t("descriptionTitle")}
            </h2>
            <p className="mt-4 text-lg leading-9 text-gray-700">
              {ABOUT_PLATFORM.description[locale]}
            </p>
          </div>
        </Reveal>
      </section>

      {/* Objectives */}
      <section className="bg-iau-section">
        <div className="mx-auto max-w-5xl px-4 py-14">
          <Reveal>
            <h2 className="text-center text-2xl font-bold text-iau-green">
              {t("goalsTitle")}
            </h2>
            <div className="mx-auto mt-3 h-1 w-12 rounded bg-iau-gold" />
          </Reveal>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {ABOUT_PLATFORM.goals.map((g, i) => (
              <Reveal key={g.en} delay={i * 60} className="h-full">
                <div className="flex h-full items-start gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-iau-green-light text-sm font-bold text-iau-green">
                    {new Intl.NumberFormat(
                      locale === "ar" ? "ar-SA" : "en-GB",
                    ).format(i + 1)}
                  </span>
                  <p className="leading-7 text-gray-700">{g[locale]}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Target audience */}
      <section className="mx-auto max-w-5xl px-4 py-14">
        <Reveal>
          <h2 className="text-center text-2xl font-bold text-iau-green">
            {t("audienceTitle")}
          </h2>
          <div className="mx-auto mt-3 h-1 w-12 rounded bg-iau-gold" />
          <p className="mx-auto mt-5 max-w-2xl text-center leading-7 text-gray-600">
            {t("audienceIntro")}
          </p>
        </Reveal>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ABOUT_PLATFORM.audience.map((a, i) => (
            <Reveal key={a.en} delay={i * 60} pop className="h-full">
              <div className="card-lift flex h-full items-center gap-3 rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                <span
                  aria-hidden
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-iau-gold/15 text-iau-green"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                </span>
                <p className="font-semibold text-gray-800">{a[locale]}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
