import { getTranslations } from "next-intl/server";
import DashboardCard from "@/components/dashboard/DashboardCard";
import CountUp from "@/components/ui/CountUp";
import Reveal from "@/components/ui/Reveal";
import { requireUser } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

export default async function OrganizerDashboardPage() {
  const profile = await requireUser(["organizer"]);
  const t = await getTranslations("dashboard");
  const supabase = await createClient();

  const { data: statuses } = await supabase
    .from("event_requests")
    .select("status")
    .eq("organizer_id", profile.id);
  const total = statuses?.length ?? 0;
  const underReview =
    statuses?.filter(
      (r) =>
        r.status === "under_review" ||
        r.status === "new" ||
        r.status === "awaiting_final",
    ).length ?? 0;
  const approved =
    statuses?.filter((r) => r.status === "approved").length ?? 0;

  const stats = [
    { label: t("stats.total"), value: total },
    { label: t("stats.underReview"), value: underReview },
    { label: t("stats.approved"), value: approved },
  ];

  const cards = [
    { title: t("cards.newRequest"), desc: t("cards.newRequestDesc"), href: "/request" },
    { title: t("cards.requestStatus"), desc: t("cards.requestStatusDesc"), href: "/dashboard/requests" },
    { title: t("cards.cancelRequest"), desc: t("cards.cancelRequestDesc"), href: "/dashboard/cancel" },
    { title: t("cards.finalReport"), desc: t("cards.finalReportDesc"), href: "/dashboard/reports" },
  ];

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="hero-stagger">
            <h1 className="text-3xl font-bold text-iau-green">
              {t("organizerTitle")}
            </h1>
            <p className="mt-2 text-gray-600">
              {t("welcome", { name: profile.fullName || profile.email })}
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              {stats.map((s) => (
                <div
                  key={s.label}
                  className="flex items-baseline gap-2 rounded-full border border-gray-200 bg-iau-section px-4 py-1.5"
                >
                  <span className="text-lg font-bold text-iau-green">
                    <CountUp value={s.value} />
                  </span>
                  <span className="text-xs font-medium text-gray-500">
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c, i) => (
            <Reveal key={c.title} delay={i * 70} pop className="h-full">
              <DashboardCard
                title={c.title}
                description={c.desc}
                href={c.href}
              />
            </Reveal>
          ))}
        </div>
      </section>
    </main>
  );
}
