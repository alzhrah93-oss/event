import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import { requireUser } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";

/**
 * Submit Event Final Report — lists the organizer's APPROVED events without
 * a report yet. Ended events link straight to the report form; upcoming ones
 * are shown disabled until the activity date passes.
 */
export default async function FinalReportPickerPage() {
  const profile = await requireUser(["organizer"]);
  const t = await getTranslations("myRequests.report");
  const locale = await getLocale();
  const supabase = await createClient();
  const today = new Date().toISOString().slice(0, 10);

  const { data: approved } = await supabase
    .from("event_requests")
    .select("id, request_number, title, activity_date")
    .eq("organizer_id", profile.id)
    .eq("status", "approved")
    .order("activity_date", { ascending: false });

  // Requests that already have a report are status 'closed', so every row
  // here is reportable once its activity date has passed.
  const ended = (approved ?? []).filter((r) => r.activity_date < today);
  const upcoming = (approved ?? []).filter((r) => r.activity_date >= today);

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/dashboard" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("pickTitle")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <p className="mt-4 text-gray-600">{t("pickIntro")}</p>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl gap-4 px-4 py-10">
        {ended.length === 0 && upcoming.length === 0 ? (
          <p className="rounded-lg border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("pickEmpty")}
          </p>
        ) : (
          <>
            {ended.map((r, i) => (
              <Link
                key={r.id}
                href={`/dashboard/requests/${r.id}/report`}
                style={{ "--row-delay": `${i * 45}ms` } as React.CSSProperties}
                className="row-in card-lift press flex flex-wrap items-center justify-between gap-3 rounded-xl border-2 border-iau-gold/60 bg-white p-5 shadow-sm"
              >
                <div>
                  <span className="font-semibold text-iau-green" dir="ltr">
                    {r.request_number}
                  </span>
                  <span className="ms-3 text-gray-800">{r.title}</span>
                  <p className="mt-1 text-sm text-gray-500">
                    {fmt.format(new Date(`${r.activity_date}T00:00:00`))}
                  </p>
                </div>
                <span className="rounded-md bg-iau-green px-4 py-2 text-sm font-semibold text-white">
                  {t("cta")}
                </span>
              </Link>
            ))}
            {upcoming.map((r, i) => (
              <div
                key={r.id}
                style={{
                  "--row-delay": `${(ended.length + i) * 45}ms`,
                } as React.CSSProperties}
                className="row-in flex flex-wrap items-center justify-between gap-3 rounded-xl border border-gray-200 bg-white/70 p-5"
              >
                <div>
                  <span className="font-semibold text-gray-500" dir="ltr">
                    {r.request_number}
                  </span>
                  <span className="ms-3 text-gray-600">{r.title}</span>
                  <p className="mt-1 text-sm text-gray-400">
                    {fmt.format(new Date(`${r.activity_date}T00:00:00`))}
                  </p>
                </div>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-500">
                  {t("notEnded")}
                </span>
              </div>
            ))}
          </>
        )}
      </section>
    </main>
  );
}
