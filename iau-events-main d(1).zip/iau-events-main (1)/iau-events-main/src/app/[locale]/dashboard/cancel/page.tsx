import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import CancelButton from "@/components/requests/CancelButton";
import StatusBadge from "@/components/requests/StatusBadge";
import { requireUser } from "@/lib/auth/guard";
import type { RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";

/**
 * Cancel Request — lists only the organizer's requests that are still in
 * review (cancellable). Decided, closed and cancelled requests never appear.
 */
export default async function CancelRequestPage() {
  const profile = await requireUser(["organizer"]);
  const t = await getTranslations("myRequests");
  const locale = await getLocale();
  const supabase = await createClient();

  const { data: requests } = await supabase
    .from("event_requests")
    .select("id, request_number, title, activity_date, status")
    .eq("organizer_id", profile.id)
    .in("status", ["entity_review", "new", "pending_completion", "under_review", "awaiting_final"])
    .order("submitted_at", { ascending: false });

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/dashboard" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("cancelPage.title")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <p className="mt-4 text-gray-600">{t("cancelPage.intro")}</p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10">
        {!requests || requests.length === 0 ? (
          <p className="rounded-lg border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("cancelPage.empty")}
          </p>
        ) : (
          <div className="grid gap-4">
            {requests.map((r, i) => (
              <div
                key={r.id}
                style={{ "--row-delay": `${i * 45}ms` } as React.CSSProperties}
                className="row-in rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <Link
                      href={`/dashboard/requests/${r.id}`}
                      className="font-semibold text-iau-green hover:underline"
                      dir="ltr"
                    >
                      {r.request_number}
                    </Link>
                    <span className="ms-3 text-gray-800">{r.title}</span>
                    <p className="mt-1 text-sm text-gray-500">
                      {fmt.format(new Date(`${r.activity_date}T00:00:00`))}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <StatusBadge status={r.status as RequestStatus} />
                    <CancelButton
                      requestId={r.id}
                      requestNumber={r.request_number}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
