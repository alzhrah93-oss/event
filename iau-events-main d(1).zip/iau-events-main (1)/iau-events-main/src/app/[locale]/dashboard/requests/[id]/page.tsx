import { getLocale, getTranslations } from "next-intl/server";
import { notFound } from "next/navigation";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import ProgressTracker from "@/components/requests/ProgressTracker";
import StatusBadge from "@/components/requests/StatusBadge";
import { requireUser } from "@/lib/auth/guard";
import { canSubmitReport, type RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";

export default async function RequestDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const profile = await requireUser(["organizer"]);
  const { id } = await params;
  const t = await getTranslations("myRequests");
  const locale = await getLocale();
  const supabase = await createClient();

  const { data: r } = await supabase
    .from("event_requests")
    .select(
      "id, request_number, title, activity_date, start_time, end_time, status, submitted_at, decision_reason, entity_decision_reason, institute_notes, cancelled_at, organizing_entity, venue",
    )
    .eq("id", id)
    .eq("organizer_id", profile.id)
    .single();
  if (!r) notFound();

  const { data: report } = await supabase
    .from("final_reports")
    .select("id, submitted_at")
    .eq("request_id", id)
    .maybeSingle();

  const status = r.status as RequestStatus;
  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const showReportCta = canSubmitReport(status, r.activity_date, !!report);

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-4xl px-4 py-12">
          <BackLink href="/dashboard/requests" />
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-iau-green" dir="ltr">
                {t("detailTitle", { number: r.request_number })}
              </h1>
              <p className="mt-1 text-gray-600">{r.title}</p>
              <p className="mt-1 text-sm text-gray-400">
                {t("submittedOn", {
                  date: fmt.format(new Date(r.submitted_at)),
                })}
              </p>
            </div>
            <StatusBadge status={status} />
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-4xl gap-6 px-4 py-10">
        {/* Tracker or cancelled notice */}
        <div className="goal-item rounded-xl border border-gray-200 bg-white p-7 shadow-sm">
          {status === "cancelled" ? (
            <p className="text-center text-gray-500">
              {t("cancelledOn", {
                date: r.cancelled_at ? fmt.format(new Date(r.cancelled_at)) : "—",
              })}
            </p>
          ) : (
            <ProgressTracker status={status} />
          )}
        </div>

        {/* Decision reason (rejection — by the Institute or the organizing entity) */}
        {status === "not_approved" && r.decision_reason && (
          <div className="goal-item rounded-xl border-s-4 border-red-400 bg-white p-6 shadow-sm">
            <h2 className="font-bold text-red-600">{t("decisionReason")}</h2>
            <p className="mt-2 leading-7 text-gray-700">{r.decision_reason}</p>
          </div>
        )}
        {status === "entity_rejected" && r.entity_decision_reason && (
          <div className="goal-item rounded-xl border-s-4 border-red-400 bg-white p-6 shadow-sm">
            <h2 className="font-bold text-red-600">{t("entityDecisionReason")}</h2>
            <p className="mt-2 leading-7 text-gray-700">
              {r.entity_decision_reason}
            </p>
          </div>
        )}
        {r.institute_notes && (
          <div className="goal-item rounded-xl border-s-4 border-iau-gold bg-white p-6 shadow-sm">
            <h2 className="font-bold text-iau-green">{t("instituteNotes")}</h2>
            <p className="mt-2 leading-7 text-gray-700">{r.institute_notes}</p>
          </div>
        )}

        {/* Report CTA */}
        {showReportCta && (
          <div className="goal-item rounded-xl border-2 border-iau-gold bg-white p-6 shadow-sm">
            <p className="text-sm text-gray-600">{t("report.due")}</p>
            <Link
              href={`/dashboard/requests/${r.id}/report`}
              className="press mt-3 inline-block rounded-md bg-iau-green px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark"
            >
              {t("report.cta")}
            </Link>
          </div>
        )}
      </section>
    </main>
  );
}
