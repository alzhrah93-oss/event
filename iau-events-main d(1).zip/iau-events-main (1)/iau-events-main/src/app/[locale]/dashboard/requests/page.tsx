import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import BackLink from "@/components/ui/BackLink";
import StatusBadge from "@/components/requests/StatusBadge";
import { MiniTracker } from "@/components/requests/ProgressTracker";
import { requireUser } from "@/lib/auth/guard";
import type { RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";

export default async function MyRequestsPage() {
  const profile = await requireUser(["organizer"]);
  const t = await getTranslations("myRequests");
  const locale = await getLocale();
  const supabase = await createClient();

  const { data: requests } = await supabase
    .from("event_requests")
    .select("id, request_number, title, activity_date, status")
    .eq("organizer_id", profile.id)
    .order("submitted_at", { ascending: false });

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-5xl px-4 py-12">
          <BackLink href="/dashboard" />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">
            {t("title")}
          </h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10">
        {!requests || requests.length === 0 ? (
          <p className="rounded-lg border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("empty")}
          </p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 bg-iau-section text-start text-xs uppercase tracking-wide text-gray-500">
                  <th className="px-4 py-3 text-start">{t("listHeaders.number")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.titleCol")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.date")}</th>
                  <th className="px-4 py-3 text-start">{t("listHeaders.status")}</th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r, i) => (
                  <tr
                    key={r.id}
                    style={{ "--row-delay": `${i * 45}ms` } as React.CSSProperties}
                    className="row-in border-b border-gray-100 transition-colors last:border-0 hover:bg-iau-green-light/30"
                  >
                    <td className="px-4 py-3 font-semibold text-iau-green" dir="ltr">
                      <Link href={`/dashboard/requests/${r.id}`} className="hover:underline">
                        {r.request_number}
                      </Link>
                    </td>
                    <td className="max-w-64 truncate px-4 py-3 text-gray-800">
                      <Link href={`/dashboard/requests/${r.id}`} className="hover:underline">
                        {r.title}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-gray-600">
                      {fmt.format(new Date(`${r.activity_date}T00:00:00`))}
                    </td>
                    <td className="px-4 py-3">
                      <div className="grid justify-items-start gap-1.5">
                        <MiniTracker status={r.status as RequestStatus} />
                        <StatusBadge status={r.status as RequestStatus} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}
