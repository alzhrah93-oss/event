import { getTranslations } from "next-intl/server";
import { notFound, redirect } from "next/navigation";
import BackLink from "@/components/ui/BackLink";
import FinalReportForm from "@/components/requests/FinalReportForm";
import { requireUser } from "@/lib/auth/guard";
import { canSubmitReport, type RequestStatus } from "@/lib/requests/status";
import { createClient } from "@/lib/supabase/server";
import { getLocale } from "next-intl/server";

export default async function FinalReportPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const profile = await requireUser(["organizer"]);
  const { id } = await params;
  const t = await getTranslations("myRequests.report");
  const locale = await getLocale();
  const supabase = await createClient();

  const { data: r } = await supabase
    .from("event_requests")
    .select("id, request_number, title, activity_date, status")
    .eq("id", id)
    .eq("organizer_id", profile.id)
    .single();
  if (!r) notFound();

  const { data: report } = await supabase
    .from("final_reports")
    .select("id")
    .eq("request_id", id)
    .maybeSingle();

  if (!canSubmitReport(r.status as RequestStatus, r.activity_date, !!report)) {
    redirect(`/${locale}/dashboard/requests/${id}`);
  }

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-3xl px-4 py-12">
          <BackLink href={`/dashboard/requests/${id}`} />
          <h1 className="mt-3 text-3xl font-bold text-iau-green">{t("title")}</h1>
          <div className="mt-3 h-1 w-16 rounded bg-iau-gold" />
          <p className="mt-4 text-gray-600">
            <span dir="ltr">{r.request_number}</span> — {r.title}
          </p>
          <p className="mt-1 text-sm text-gray-500">{t("intro")}</p>
        </div>
      </section>
      <section className="mx-auto max-w-3xl px-4 py-10">
        <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
          <FinalReportForm requestId={r.id} />
        </div>
      </section>
    </main>
  );
}
