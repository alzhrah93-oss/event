import { getLocale, getTranslations } from "next-intl/server";
import { Link } from "@/i18n/navigation";
import { eventTone } from "@/lib/event-colors";
import { getPublicEvents } from "@/lib/requests/events-server";
import { cn } from "@/lib/utils";

/** Site pages searchable by their localized nav titles (both languages). */
const PAGES = [
  { href: "/", key: "home" },
  { href: "/about", key: "about" },
  { href: "/strategic-plan", key: "strategicPlan" },
  { href: "/requirements", key: "requirements" },
  { href: "/calendar", key: "calendar" },
  { href: "/login", key: "login" },
] as const;

/**
 * Search results: matches the query (in either language) against the site's
 * pages and the public events shown on the calendar/marquee.
 */
export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const query = q.trim();
  const locale = (await getLocale()) as "en" | "ar";
  const t = await getTranslations("search");
  const tc = await getTranslations("common");
  const tn = await getTranslations("nav");
  const [navEn, navAr] = await Promise.all([
    getTranslations({ locale: "en", namespace: "nav" }),
    getTranslations({ locale: "ar", namespace: "nav" }),
  ]);

  const nq = query.toLowerCase();
  const match = (...fields: string[]) =>
    nq.length > 0 && fields.some((f) => f.toLowerCase().includes(nq));

  const pageKey = (k: (typeof PAGES)[number]["key"]) =>
    k as Parameters<typeof tn>[0];
  const pages = query
    ? PAGES.filter((p) => match(navEn(pageKey(p.key)), navAr(pageKey(p.key))))
    : [];
  const events = query
    ? (await getPublicEvents()).filter((e) =>
        match(
          e.name.en,
          e.name.ar,
          e.place.en,
          e.place.ar,
          e.college.en,
          e.college.ar,
          e.type.en,
          e.type.ar,
        ),
      )
    : [];
  const total = pages.length + events.length;

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <main className="min-h-[60vh] bg-iau-section">
      <section className="border-b border-iau-green-light bg-gradient-to-b from-iau-green-light/70 via-iau-green-light/30 to-iau-section">
        <div className="mx-auto max-w-3xl px-4 py-12 text-center">
          <h1 className="text-3xl font-bold text-iau-green">{t("title")}</h1>
          <div className="mx-auto mt-4 h-1 w-16 rounded bg-iau-gold" />
          <form
            action={`/${locale}/search`}
            method="get"
            role="search"
            className="mx-auto mt-8 flex max-w-xl items-stretch"
          >
            <input
              type="search"
              name="q"
              defaultValue={query}
              placeholder={tc("searchPlaceholder")}
              aria-label={tc("search")}
              className="h-11 w-full rounded-s-md border border-gray-300 bg-white px-4 text-sm text-gray-800 outline-none transition-shadow placeholder:text-gray-500 focus:ring-2 focus:ring-iau-green"
            />
            <button
              type="submit"
              className="press rounded-e-md bg-iau-green px-6 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark"
            >
              {tc("search")}
            </button>
          </form>
        </div>
      </section>

      <section className="mx-auto grid max-w-3xl gap-8 px-4 py-10">
        {!query ? (
          <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("prompt")}
          </p>
        ) : total === 0 ? (
          <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
            {t("empty", { q: query })}
          </p>
        ) : (
          <>
            <p className="text-sm text-gray-500">
              {t("resultsCount", { count: total, q: query })}
            </p>

            {pages.length > 0 && (
              <div>
                <h2 className="mb-3 text-lg font-bold text-iau-green">
                  {t("pagesSection")}
                </h2>
                <div className="grid gap-3">
                  {pages.map((p, i) => (
                    <Link
                      key={p.href}
                      href={p.href}
                      style={{ "--row-delay": `${i * 40}ms` } as React.CSSProperties}
                      className="row-in card-lift press flex items-center justify-between gap-3 rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                    >
                      <span className="font-semibold text-gray-800">
                        {tn(pageKey(p.key))}
                      </span>
                      <span aria-hidden className="text-iau-green rtl:rotate-180">
                        →
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {events.length > 0 && (
              <div>
                <h2 className="mb-3 text-lg font-bold text-iau-green">
                  {t("eventsSection")}
                </h2>
                <div className="grid gap-3">
                  {events.map((e, i) => {
                    const tone = eventTone(e.type.en);
                    return (
                      <Link
                        key={e.id}
                        href="/calendar"
                        style={{ "--row-delay": `${(pages.length + i) * 40}ms` } as React.CSSProperties}
                        className="row-in card-lift press rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-bold text-gray-900">
                            {e.name[locale]}
                          </span>
                          <span
                            className={cn(
                              "rounded-full px-2.5 py-0.5 text-xs font-semibold",
                              tone.chip,
                            )}
                          >
                            {e.type[locale]}
                          </span>
                        </div>
                        <p className="mt-2 text-sm text-gray-600">
                          {fmt.format(new Date(`${e.date}T00:00:00`))} —{" "}
                          {e.place[locale]}
                        </p>
                        <p className="mt-0.5 text-sm text-gray-500">
                          {e.college[locale]}
                        </p>
                      </Link>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </section>
    </main>
  );
}
