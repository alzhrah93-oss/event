import { getTranslations } from "next-intl/server";
import MonthCalendar from "@/components/events/MonthCalendar";
import EventsMarquee from "@/components/events/EventsMarquee";
import DashboardBackLink from "@/components/ui/DashboardBackLink";
import { getOngoingAndUpcoming } from "@/lib/events-data";
import { getPublicEvents } from "@/lib/requests/events-server";

export default async function CalendarPage() {
  const t = await getTranslations("calendar");
  const tp = await getTranslations("pages");
  const th = await getTranslations("home");
  const events = await getPublicEvents();

  return (
    <main>
      {/* Soft green tint so the white calendar card stands off the hero */}
      <section className="border-b border-iau-green-light bg-gradient-to-b from-iau-green-light/70 via-iau-green-light/30 to-iau-section">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center">
          <div className="text-start">
            <DashboardBackLink />
          </div>
          <h1 className="text-4xl font-bold text-iau-green">
            {tp("calendarTitle")}
          </h1>
          <div className="mx-auto mt-4 h-1 w-16 rounded bg-iau-gold" />
          <p className="mx-auto mt-5 max-w-2xl leading-7 text-gray-600">
            {t("intro")}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <MonthCalendar events={events} />
      </section>

      <section className="bg-iau-section">
        <div className="mx-auto max-w-7xl px-4 py-14">
          <h2 className="mb-8 text-center text-3xl font-bold text-iau-green">
            {th("eventsTitle")}
          </h2>
          <EventsMarquee events={getOngoingAndUpcoming(events)} />
        </div>
      </section>
    </main>
  );
}
