import { useLocale, useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { GOV_PRINCIPLES, PRE_SUBMISSION_REQUIREMENTS } from "@/lib/content";
import DashboardBackLink from "@/components/ui/DashboardBackLink";
import Reveal from "@/components/ui/Reveal";

export default function RequirementsPage() {
  const t = useTranslations("requirements");
  const tp = useTranslations("pages");
  const locale = useLocale() as "en" | "ar";

  return (
    <main>
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12 text-center">
          <div className="text-start">
            <DashboardBackLink />
          </div>
          <h1 className="text-4xl font-bold text-iau-green">
            {tp("requirementsTitle")}
          </h1>
          <div className="mx-auto mt-4 h-1 w-16 rounded bg-iau-gold" />
          <p className="mx-auto mt-5 max-w-2xl leading-7 text-gray-600">
            {t("intro")}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-14">
        <h2 className="mb-6 text-2xl font-bold text-iau-green">
          {t("preTitle")}
        </h2>
        <ol className="space-y-3">
          {PRE_SUBMISSION_REQUIREMENTS.map((req, i) => (
            <Reveal
              key={req.en}
              as="li"
              delay={i * 50}
              className="flex gap-4 rounded-xl border border-gray-200 bg-white p-5"
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-iau-green text-sm font-bold text-white">
                {i + 1}
              </span>
              <p className="leading-7 text-gray-700">{req[locale]}</p>
            </Reveal>
          ))}
        </ol>
      </section>

      <section className="bg-iau-section">
        <div className="mx-auto max-w-4xl px-4 py-14">
          <h2 className="mb-6 text-2xl font-bold text-iau-green">
            {t("principlesTitle")}
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {GOV_PRINCIPLES.map((p, i) => (
              <Reveal
                key={p.title.en}
                delay={i * 60}
                pop
                className="card-lift rounded-xl border-s-4 border-iau-gold bg-white p-6"
              >
                <h3 className="mb-2 font-bold text-iau-green">
                  {p.title[locale]}
                </h3>
                <p className="text-sm leading-6 text-gray-600">
                  {p.detail[locale]}
                </p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-14">
        <div className="rounded-lg border-2 border-iau-gold bg-white p-8 text-center shadow-sm">
          <h2 className="text-xl font-bold text-iau-green">
            {t("calloutTitle")}
          </h2>
          <p className="mx-auto mt-3 max-w-2xl leading-7 text-gray-600">
            {t("calloutText")}
          </p>
          <Link
            href="/request"
            className="press mt-6 inline-block rounded-md bg-iau-green px-6 py-3 font-semibold text-white transition-colors hover:bg-iau-green-dark"
          >
            {t("cta")}
          </Link>
        </div>
      </section>
    </main>
  );
}
