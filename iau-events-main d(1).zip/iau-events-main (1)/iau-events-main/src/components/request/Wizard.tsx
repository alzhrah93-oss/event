"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import {
  TOTAL_STEPS,
  validateRequestFull,
  validateRequestStep,
  type RequestErrors,
} from "@/lib/requests/validate";
import { MAX_FILE_MB } from "@/lib/requests/options";
import { submitRequest } from "@/lib/requests/actions";
import { cn } from "@/lib/utils";
import { useRequestForm } from "./useRequestForm";
import {
  StepActivity,
  StepApplicant,
  StepParticipants,
  StepVenue,
} from "./StepsA";
import { StepAlignment, StepBudget, StepIp } from "./StepsB";

export default function Wizard({ userId }: { userId: string }) {
  const t = useTranslations("request");
  const { data, set, hydrated, clearDraft } = useRequestForm(userId);
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState<RequestErrors>({});
  const [letterFile, setLetterFile] = useState<File | undefined>();
  const [fileError, setFileError] = useState<string | undefined>();
  const [submitError, setSubmitError] = useState<string | undefined>();
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  if (!hydrated) return null;

  /**
   * After a failed validation, move the page to the first invalid field so
   * the applicant immediately sees what is missing. Runs on the next frame
   * so the error markup has rendered.
   */
  const scrollToFirstError = () => {
    setTimeout(() => {
      const target = document.querySelector<HTMLElement>(
        '#wizard-step [aria-invalid="true"], #wizard-step [role="alert"]',
      );
      if (!target) return;
      target.scrollIntoView({ behavior: "smooth", block: "center" });
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target instanceof HTMLSelectElement
      ) {
        target.focus({ preventScroll: true });
      }
    }, 80);
  };

  const goNext = () => {
    const e = validateRequestStep(step, data);
    setErrors(e);
    // The approved letter lives on step 1 — block advancing without it
    const filesOk = step !== 1 || checkFiles();
    if (Object.keys(e).length === 0 && filesOk && step < TOTAL_STEPS) {
      setStep(step + 1);
      window.scrollTo({ top: 0 });
    } else if (Object.keys(e).length > 0 || !filesOk) {
      scrollToFirstError();
    }
  };

  const goPrev = () => {
    setErrors({});
    if (step > 1) {
      setStep(step - 1);
      window.scrollTo({ top: 0 });
    }
  };

  const goTo = (s: number) => {
    // allow jumping back to any earlier (already validated) step
    if (s < step) {
      setErrors({});
      setStep(s);
    }
  };

  const checkFiles = (): boolean => {
    if (!letterFile) {
      setFileError("attachmentRequired");
      return false;
    }
    if (letterFile.size > MAX_FILE_MB * 1024 * 1024) {
      setFileError("fileTooLarge");
      return false;
    }
    setFileError(undefined);
    return true;
  };

  const onSubmit = () => {
    const e = validateRequestFull(data);
    setErrors(e);
    if (!checkFiles()) {
      setStep(1); // the letter upload lives on step 1
      scrollToFirstError();
      return;
    }
    if (Object.keys(e).length > 0) {
      scrollToFirstError();
      return;
    }

    const fd = new FormData();
    fd.set("payload", JSON.stringify(data));
    if (letterFile) fd.set("file_approved_letter", letterFile);

    startTransition(async () => {
      const result = await submitRequest(fd);
      if (result?.error) {
        setSubmitError(result.error);
        return;
      }
      clearDraft();
      router.push(`/request/success?rn=${result.requestNumber}`);
    });
  };

  const steps = Array.from({ length: TOTAL_STEPS }, (_, i) => i + 1);
  const stepProps = { d: data, set, errors };

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      {/* Step indicator */}
      <nav aria-label={t("stepOf", { current: step, total: TOTAL_STEPS })}>
        <p className="mb-3 text-sm font-semibold text-iau-green">
          {t("stepOf", { current: step, total: TOTAL_STEPS })} —{" "}
          {t(`steps.${step}` as Parameters<typeof t>[0])}
        </p>
        <ol className="mb-8 flex flex-wrap gap-1.5">
          {steps.map((s) => (
            <li key={s} className="flex-1 min-w-8">
              <button
                type="button"
                onClick={() => goTo(s)}
                disabled={s > step}
                aria-current={s === step ? "step" : undefined}
                title={t(`steps.${s}` as Parameters<typeof t>[0])}
                className={cn(
                  "h-1.5 w-full rounded-full transition-colors",
                  s < step && "cursor-pointer bg-iau-green",
                  s === step && "bg-iau-gold",
                  s > step && "bg-gray-200",
                )}
              />
            </li>
          ))}
        </ol>
      </nav>

      {/* Error summary */}
      {Object.keys(errors).length > 0 && (
        <p role="alert" className="mb-6 rounded-md bg-red-50 px-4 py-3 text-sm text-red-700">
          {t("errors.stepErrors")}
        </p>
      )}
      {submitError && (
        <p role="alert" className="mb-6 rounded-md bg-red-50 px-4 py-3 text-sm text-red-700">
          {t("errors.submitFailed")}
        </p>
      )}

      {/* Active step (keyed so entrance animation replays) */}
      <div key={step} id="wizard-step" className="goal-item">
        {step === 1 && (
          <StepApplicant
            {...stepProps}
            letterFile={letterFile}
            onLetterFile={(f) => {
              setLetterFile(f);
              if (f) setFileError(undefined);
            }}
            fileError={fileError}
          />
        )}
        {step === 2 && <StepActivity {...stepProps} />}
        {step === 3 && <StepVenue {...stepProps} />}
        {step === 4 && <StepParticipants {...stepProps} />}
        {step === 5 && <StepAlignment {...stepProps} />}
        {step === 6 && <StepIp {...stepProps} />}
        {step === 7 && <StepBudget {...stepProps} />}
      </div>

      {/* Controls */}
      <div className="mt-10 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={goPrev}
          disabled={step === 1 || pending}
          className="press rounded-md border border-iau-green px-6 py-2.5 font-semibold text-iau-green transition-colors hover:bg-iau-green-light disabled:opacity-40"
        >
          {t("previous")}
        </button>
        <p className="text-xs text-gray-400">{t("draftSaved")}</p>
        {step < TOTAL_STEPS ? (
          <button
            type="button"
            onClick={goNext}
            className="press rounded-md bg-iau-green px-8 py-2.5 font-semibold text-white transition-colors hover:bg-iau-green-dark"
          >
            {t("next")}
          </button>
        ) : (
          <button
            type="button"
            onClick={onSubmit}
            disabled={pending || !data.declaration}
            className="press rounded-md bg-iau-gold px-8 py-2.5 font-semibold text-white transition-colors hover:bg-iau-gold/90 disabled:opacity-50"
          >
            {pending ? t("submitting") : t("submit")}
          </button>
        )}
      </div>
    </div>
  );
}
