"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { EMPTY_REQUEST, type RequestFormData } from "@/lib/requests/types";

const DRAFT_KEY = (userId: string) => `iau-request-draft-${userId}`;

/**
 * Wizard form state with localStorage draft autosave (long governance form —
 * protect the applicant from losing work).
 */
export function useRequestForm(userId: string) {
  const [data, setData] = useState<RequestFormData>(EMPTY_REQUEST);
  const [hydrated, setHydrated] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Hydrate draft once on mount (client-only localStorage read; SSR renders
  // nothing until hydrated, so a one-time set here cannot loop or mismatch)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY(userId));
      // eslint-disable-next-line react-hooks/set-state-in-effect
      if (raw) setData({ ...EMPTY_REQUEST, ...JSON.parse(raw) });
    } catch {
      // corrupt draft — start clean
    }
    setHydrated(true);
  }, [userId]);

  // Debounced autosave
  useEffect(() => {
    if (!hydrated) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      try {
        localStorage.setItem(DRAFT_KEY(userId), JSON.stringify(data));
      } catch {
        // storage full/unavailable — draft is best-effort
      }
    }, 600);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [data, hydrated, userId]);

  const set = useCallback(
    <K extends keyof RequestFormData>(key: K, value: RequestFormData[K]) =>
      setData((d) => ({ ...d, [key]: value })),
    [],
  );

  const clearDraft = useCallback(() => {
    try {
      localStorage.removeItem(DRAFT_KEY(userId));
    } catch {
      // ignore
    }
  }, [userId]);

  return { data, set, hydrated, clearDraft };
}
