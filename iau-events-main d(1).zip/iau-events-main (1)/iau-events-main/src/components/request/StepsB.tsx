"use client";

import { useLocale, useTranslations } from "next-intl";
import { challengesForArea, FOCUS_AREAS } from "@/lib/content";
import type {
  AlignmentSelection,
  BudgetItem,
  RequestFormData,
} from "@/lib/requests/types";
import { OTHER_OPTION } from "@/lib/requests/types";
import {
  EXPECTED_OUTPUTS,
  FOLLOWUP_PATHWAYS,
  FUNDING_SOURCES,
  SDGS,
  type Option,
} from "@/lib/requests/options";
import type { StepProps } from "./StepsA";
import {
  ErrorText,
  MultiSelect,
  Segmented,
  SelectField,
  TextArea,
  TextField,
  YesNo,
} from "./inputs";

type Loc = "en" | "ar";

const OTHER_LABEL = { en: "Other", ar: "أخرى" };

export function StepAlignment({ d, set, errors }: StepProps) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const locale = useLocale() as Loc;
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;

  const areaOptions: Option[] = FOCUS_AREAS.map((a) => ({
    value: a.id,
    label: a.name,
  }));

  // Keep panel order stable (FOCUS_AREAS order); drafts saved before the
  // grand-challenges field default to no challenges.
  const setAreas = (ids: string[]) =>
    set(
      "alignment",
      FOCUS_AREAS.filter((a) => ids.includes(a.id)).map(
        (a): AlignmentSelection =>
          d.alignment.find((s) => s.focusAreaId === a.id) ?? {
            focusAreaId: a.id,
            goals: [],
            challenges: [],
          },
      ),
    );

  const patchArea = (id: string, patch: Partial<AlignmentSelection>) =>
    set(
      "alignment",
      d.alignment.map((a) => (a.focusAreaId === id ? { ...a, ...patch } : a)),
    );

  return (
    <div className="grid gap-6">
      <div className="grid gap-4">
        <MultiSelect
          label={t("focusAreas")}
          name="focusAreas"
          values={d.alignment.map((a) => a.focusAreaId)}
          onChange={setAreas}
          options={areaOptions}
          error={err(errors.alignment)}
          hint={t("focusAreasHint")}
          required
        />
        {d.alignment.map((sel) => {
          const area = FOCUS_AREAS.find((a) => a.id === sel.focusAreaId);
          if (!area) return null;
          const challenges = challengesForArea(area.id);
          return (
            <div
              key={area.id}
              className="goal-item grid gap-4 rounded-lg border border-iau-green-light bg-iau-green-light/40 p-4"
            >
              <p className="text-sm font-bold text-iau-green">
                {area.name[locale]}
              </p>
              <MultiSelect
                label={t("areaGoals")}
                name={`goals-${area.id}`}
                values={sel.goals}
                onChange={(v) => patchArea(area.id, { goals: v })}
                options={[
                  ...area.goals.map((g) => ({ value: g.en, label: g })),
                  { value: OTHER_OPTION, label: OTHER_LABEL },
                ]}
                required
              />
              {sel.goals.includes(OTHER_OPTION) && (
                <TextField
                  label={t("otherGoal")}
                  name={`otherGoal-${area.id}`}
                  value={sel.otherGoal ?? ""}
                  onChange={(v) => patchArea(area.id, { otherGoal: v })}
                  error={
                    errors.alignment === "otherGoalRequired" &&
                    !(sel.otherGoal ?? "").trim()
                      ? te("required")
                      : undefined
                  }
                  required
                />
              )}
              {challenges.length > 0 && (
                <>
                  <MultiSelect
                    label={t("grandChallenges")}
                    name={`challenges-${area.id}`}
                    values={sel.challenges ?? []}
                    onChange={(v) => patchArea(area.id, { challenges: v })}
                    options={[
                      ...challenges.map((c) => ({
                        value: c.id,
                        label: c.text,
                      })),
                      { value: OTHER_OPTION, label: OTHER_LABEL },
                    ]}
                    hint={t("grandChallengesHint")}
                  />
                  {(sel.challenges ?? []).includes(OTHER_OPTION) && (
                    <TextField
                      label={t("otherChallenge")}
                      name={`otherChallenge-${area.id}`}
                      value={sel.otherChallenge ?? ""}
                      onChange={(v) =>
                        patchArea(area.id, { otherChallenge: v })
                      }
                    />
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>

      <MultiSelect
        label={t("sdgs")}
        name="sdgs"
        values={d.sdgs}
        onChange={(v) => set("sdgs", v)}
        options={SDGS}
      />
      <MultiSelect
        label={t("expectedOutputs")}
        name="expectedOutputs"
        values={d.expectedOutputs}
        onChange={(v) => set("expectedOutputs", v)}
        options={EXPECTED_OUTPUTS}
        error={err(errors.expectedOutputs)}
        required
      />
      <MultiSelect
        label={t("followupPathways")}
        name="followupPathways"
        values={d.followupPathways}
        onChange={(v) => set("followupPathways", v)}
        options={FOLLOWUP_PATHWAYS.map((o) =>
          o.value === "other" ? { value: OTHER_OPTION, label: o.label } : o,
        )}
      />
      {d.followupPathways.includes(OTHER_OPTION) && (
        <TextField
          label={t("otherFollowup")}
          name="followupOther"
          value={d.followupOther}
          onChange={(v) => set("followupOther", v)}
          error={err(errors.followupOther)}
          required
        />
      )}
    </div>
  );
}

export function StepIp({ d, set, errors }: StepProps) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;
  const showDetails = d.presentsIp === "yes" || d.presentsIp === "unsure";

  return (
    <div className="grid gap-6">
      <Segmented
        label={t("presentsIp")}
        name="presentsIp"
        value={d.presentsIp}
        onChange={(v) => set("presentsIp", v as RequestFormData["presentsIp"])}
        options={[
          { value: "yes", label: t("yes") },
          { value: "no", label: t("no") },
        ]}
        error={err(errors.presentsIp)}
        required
      />
      {showDetails && (
        <div className="goal-item grid gap-6 rounded-lg border border-iau-green-light bg-iau-green-light/40 p-5">
          <YesNo
            label={t("ipDisclosed")}
            name="ipDisclosed"
            value={d.ipDisclosed}
            onChange={(v) => set("ipDisclosed", v)}
            yesLabel={t("yes")}
            noLabel={t("no")}
            error={err(errors.ipDisclosed)}
          />
          <YesNo
            label={t("ipPrototype")}
            name="ipPrototype"
            value={d.ipPrototype}
            onChange={(v) => set("ipPrototype", v)}
            yesLabel={t("yes")}
            noLabel={t("no")}
            error={err(errors.ipPrototype)}
          />
          <Segmented
            label={t("ipPatent")}
            name="ipPatent"
            value={d.ipPatent}
            onChange={(v) => set("ipPatent", v as RequestFormData["ipPatent"])}
            options={[
              { value: "yes", label: t("yes") },
              { value: "no", label: t("no") },
              { value: "in_progress", label: t("inProgress") },
            ]}
            error={err(errors.ipPatent)}
            required
          />
          <YesNo
            label={t("ipUnpublished")}
            name="ipUnpublished"
            value={d.ipUnpublished}
            onChange={(v) => set("ipUnpublished", v)}
            yesLabel={t("yes")}
            noLabel={t("no")}
            error={err(errors.ipUnpublished)}
          />
          <Segmented
            label={t("ipNda")}
            name="ipNda"
            value={d.ipNda}
            onChange={(v) => set("ipNda", v as RequestFormData["ipNda"])}
            options={[
              { value: "yes", label: t("yes") },
              { value: "no", label: t("no") },
            ]}
            error={err(errors.ipNda)}
            required
          />
        </div>
      )}
    </div>
  );
}

const EMPTY_BUDGET: BudgetItem = {
  item: "",
  description: "",
  cost: "",
  source: "",
  justification: "",
};

export function StepBudget({ d, set, errors }: StepProps) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;

  const setItem = (i: number, patch: Partial<BudgetItem>) =>
    set(
      "budgetItems",
      d.budgetItems.map((b, j) => (j === i ? { ...b, ...patch } : b)),
    );

  return (
    <div className="grid gap-6">
      <YesNo
        label={t("needsFunding")}
        name="needsFunding"
        value={d.needsFunding}
        onChange={(v) => {
          set("needsFunding", v);
          if (v && d.budgetItems.length === 0)
            set("budgetItems", [{ ...EMPTY_BUDGET }]);
        }}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.needsFunding)}
      />
      {d.needsFunding && (
        <div className="goal-item grid gap-4 rounded-lg border border-iau-green-light bg-iau-green-light/40 p-5">
          <SelectField
            label={t("fundingSource")}
            name="fundingSource"
            value={d.fundingSource}
            onChange={(v) => set("fundingSource", v)}
            options={FUNDING_SOURCES}
            error={err(errors.fundingSource)}
            required
          />
          <p className="text-sm font-semibold text-gray-800">
            {t("budgetItems")} <span className="text-red-500">*</span>
          </p>
          <ErrorText id="budgetItems-error" message={err(errors.budgetItems)} />
          {d.budgetItems.map((b, i) => (
            <div key={i} className="grid gap-3 rounded-md bg-white p-4 sm:grid-cols-2">
              <TextField
                label={t("budgetItem")}
                name={`budgetItem-${i}`}
                value={b.item}
                onChange={(v) => setItem(i, { item: v })}
                required
              />
              <TextField
                label={t("budgetCost")}
                name={`budgetCost-${i}`}
                type="number"
                dir="ltr"
                value={b.cost}
                onChange={(v) => setItem(i, { cost: v })}
                required
              />
              <TextField
                label={t("budgetDescription")}
                name={`budgetDescription-${i}`}
                value={b.description}
                onChange={(v) => setItem(i, { description: v })}
              />
              <TextField
                label={t("budgetJustification")}
                name={`budgetJustification-${i}`}
                value={b.justification}
                onChange={(v) => setItem(i, { justification: v })}
              />
              <button
                type="button"
                onClick={() =>
                  set(
                    "budgetItems",
                    d.budgetItems.filter((_, j) => j !== i),
                  )
                }
                className="press w-fit text-sm font-semibold text-red-600 hover:underline"
              >
                {t("removePartner")}
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() =>
              set("budgetItems", [...d.budgetItems, { ...EMPTY_BUDGET }])
            }
            className="press w-fit rounded-md border border-iau-green px-4 py-2 text-sm font-semibold text-iau-green hover:bg-iau-green-light"
          >
            + {t("addBudgetItem")}
          </button>
        </div>
      )}

      <YesNo
        label={t("needsLabs")}
        name="needsLabs"
        value={d.needsLabs}
        onChange={(v) => set("needsLabs", v)}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.needsLabs)}
      />
      {d.needsLabs && (
        <div className="goal-item">
          <TextArea
            label={t("labsDetails")}
            name="labsDetails"
            rows={3}
            value={d.labsDetails}
            onChange={(v) => set("labsDetails", v)}
            error={err(errors.labsDetails)}
            required
          />
        </div>
      )}

      <YesNo
        label={t("needsMaterials")}
        name="needsMaterials"
        value={d.needsMaterials}
        onChange={(v) => set("needsMaterials", v)}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.needsMaterials)}
      />
      {d.needsMaterials && (
        <div className="goal-item">
          <TextArea
            label={t("materialsDetails")}
            name="materialsDetails"
            rows={3}
            value={d.materialsDetails}
            onChange={(v) => set("materialsDetails", v)}
            error={err(errors.materialsDetails)}
            required
          />
        </div>
      )}

      <YesNo
        label={t("needsMedia")}
        name="needsMedia"
        value={d.needsMedia}
        onChange={(v) => set("needsMedia", v)}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.needsMedia)}
      />

      {/* Declaration closes the final step — required before submitting */}
      <div className="rounded-lg border-s-4 border-iau-gold bg-iau-section p-5">
        <h3 className="mb-2 text-lg font-bold text-iau-green">
          {t("declaration")} <span className="text-red-500">*</span>
        </h3>
        <label className="flex cursor-pointer items-start gap-3">
          <input
            type="checkbox"
            checked={d.declaration}
            onChange={(e) => set("declaration", e.target.checked)}
            className="mt-1 h-5 w-5 shrink-0 accent-iau-green"
          />
          <span className="text-sm leading-6 text-gray-700">
            {t("declarationText")}
          </span>
        </label>
        <ErrorText id="declaration-error" message={err(errors.declaration)} />
      </div>
    </div>
  );
}
