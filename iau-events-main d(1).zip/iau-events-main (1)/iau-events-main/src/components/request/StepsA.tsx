"use client";

import { useTranslations } from "next-intl";
import type { RequestFormData, PartnerEntry } from "@/lib/requests/types";
import type { RequestErrors } from "@/lib/requests/validate";
import {
  ACCEPTED_FILE_TYPES,
  ACTIVITY_FORMATS,
  COLLEGE_GROUPS,
  ENTITY_DETAIL_LISTS,
  EXTERNAL_PARTICIPATION_TYPES,
  MAX_FILE_MB,
  ORGANIZING_ENTITIES,
  PARTNERSHIP_TYPES,
  REQUEST_TYPES,
  TARGET_AUDIENCE,
  VENUES,
} from "@/lib/requests/options";
import {
  addWorkingDays,
  MIN_LEAD_WORKING_DAYS,
} from "@/lib/requests/working-days";
import {
  ErrorText,
  GroupedSelectField,
  MultiSelect,
  Segmented,
  SelectField,
  TextArea,
  TextField,
  YesNo,
} from "./inputs";

export type StepProps = {
  d: RequestFormData;
  set: <K extends keyof RequestFormData>(k: K, v: RequestFormData[K]) => void;
  errors: RequestErrors;
};

export function StepApplicant({
  d,
  set,
  errors,
  letterFile,
  onLetterFile,
  fileError,
}: StepProps & {
  letterFile?: File;
  onLetterFile: (file: File | undefined) => void;
  fileError?: string;
}) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;

  return (
    <div className="grid gap-5 sm:grid-cols-2">
      <SelectField
        label={t("organizingEntity")}
        name="organizingEntity"
        value={d.organizingEntity}
        onChange={(v) => {
          set("organizingEntity", v);
          set("entityDetail", ""); // entity changed — its detail no longer applies
        }}
        options={ORGANIZING_ENTITIES}
        error={err(errors.organizingEntity)}
        required
      />
      {d.organizingEntity === "college" ? (
        <GroupedSelectField
          label={t("collegeName")}
          name="entityDetail"
          value={d.entityDetail}
          onChange={(v) => set("entityDetail", v)}
          groups={COLLEGE_GROUPS}
          error={err(errors.entityDetail)}
          required
        />
      ) : ENTITY_DETAIL_LISTS[d.organizingEntity] ? (
        <SelectField
          label={t(
            `entityDetail_${d.organizingEntity}` as Parameters<typeof t>[0],
          )}
          name="entityDetail"
          value={d.entityDetail}
          onChange={(v) => set("entityDetail", v)}
          options={ENTITY_DETAIL_LISTS[d.organizingEntity]}
          error={err(errors.entityDetail)}
          required
        />
      ) : d.organizingEntity === "other" ? (
        <TextField
          label={t("entityDetail_other")}
          name="entityDetail"
          value={d.entityDetail}
          onChange={(v) => set("entityDetail", v)}
          error={err(errors.entityDetail)}
          required
        />
      ) : null}
      <TextField
        label={t("applicantName")}
        name="applicantName"
        value={d.applicantName}
        onChange={(v) => set("applicantName", v)}
        error={err(errors.applicantName)}
        required
      />
      <TextField
        label={t("jobTitle")}
        name="jobTitle"
        value={d.jobTitle}
        onChange={(v) => set("jobTitle", v)}
        error={err(errors.jobTitle)}
        required
      />
      <TextField
        label={t("universityEmail")}
        name="universityEmail"
        type="email"
        dir="ltr"
        value={d.universityEmail}
        onChange={(v) => set("universityEmail", v)}
        error={err(errors.universityEmail)}
        required
      />
      <TextField
        label={t("mobile")}
        name="mobile"
        type="tel"
        dir="ltr"
        value={d.mobile}
        onChange={(v) => set("mobile", v)}
        error={err(errors.mobile)}
        required
      />
      <TextField
        label={t("altCoordinator")}
        name="altCoordinator"
        value={d.altCoordinator}
        onChange={(v) => set("altCoordinator", v)}
        error={err(errors.altCoordinator)}
        required
      />
      <TextField
        label={t("altCoordinatorPhone")}
        name="altCoordinatorPhone"
        type="tel"
        dir="ltr"
        value={d.altCoordinatorPhone}
        onChange={(v) => set("altCoordinatorPhone", v)}
        error={err(errors.altCoordinatorPhone)}
        required
      />
      <TextField
        label={t("altCoordinatorEmail")}
        name="altCoordinatorEmail"
        type="email"
        dir="ltr"
        value={d.altCoordinatorEmail}
        onChange={(v) => set("altCoordinatorEmail", v)}
        error={err(errors.altCoordinatorEmail)}
        required
      />

      {/* Approved letter from the organizing entity (only attachment on the form) */}
      <div className="rounded-lg border border-gray-200 bg-white p-4 sm:col-span-2">
        <label
          htmlFor="file-approved_letter"
          className="mb-2 block text-sm font-semibold text-gray-800"
        >
          {t("attachment_approved_letter")}
          <span className="text-red-500"> *</span>
        </label>
        <p className="mb-2 text-xs text-gray-500">{t("attachmentHint")}</p>
        <ErrorText id="attachments-error" message={err(fileError)} />
        <input
          id="file-approved_letter"
          type="file"
          accept={ACCEPTED_FILE_TYPES}
          onChange={(e) => onLetterFile(e.target.files?.[0])}
          className="block w-full text-sm text-gray-600 file:me-4 file:rounded-md file:border-0 file:bg-iau-green file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-iau-green-dark"
        />
        {letterFile && (
          <p className="mt-2 text-xs text-gray-500" dir="ltr">
            {letterFile.name} — {(letterFile.size / (1024 * 1024)).toFixed(1)}{" "}
            MB
            {letterFile.size > MAX_FILE_MB * 1024 * 1024 && (
              <span className="font-semibold text-red-600">
                {" "}
                ({te("fileTooLarge")})
              </span>
            )}
          </p>
        )}
      </div>
    </div>
  );
}

export function StepActivity({ d, set, errors }: StepProps) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;
  const minDate = addWorkingDays(
    new Date().toISOString().slice(0, 10),
    MIN_LEAD_WORKING_DAYS,
  );

  return (
    <div className="grid gap-5">
      <MultiSelect
        label={t("requestTypes")}
        name="requestTypes"
        values={d.requestTypes}
        onChange={(v) => set("requestTypes", v)}
        options={REQUEST_TYPES}
        error={err(errors.requestTypes)}
        required
      />
      <div className="grid gap-5 sm:grid-cols-2">
        <TextField
          label={t("titleField")}
          name="title"
          value={d.title}
          onChange={(v) => set("title", v)}
          error={err(errors.title)}
          required
        />
        <TextField
          label={t("activityDate")}
          name="activityDate"
          type="date"
          dir="ltr"
          value={d.activityDate}
          onChange={(v) => set("activityDate", v)}
          error={err(errors.activityDate)}
          hint={t("activityDateHint", { date: minDate })}
          required
        />
        <TextField
          label={t("startTime")}
          name="startTime"
          type="time"
          dir="ltr"
          value={d.startTime}
          onChange={(v) => set("startTime", v)}
          error={err(errors.startTime)}
          required
        />
        <TextField
          label={t("endTime")}
          name="endTime"
          type="time"
          dir="ltr"
          value={d.endTime}
          onChange={(v) => set("endTime", v)}
          error={err(errors.endTime)}
          required
        />
      </div>
      <TextArea
        label={t("description")}
        name="description"
        value={d.description}
        onChange={(v) => set("description", v)}
        error={err(errors.description)}
        required
      />
      <MultiSelect
        label={t("targetAudience")}
        name="targetAudience"
        values={d.targetAudience}
        onChange={(v) => set("targetAudience", v)}
        options={TARGET_AUDIENCE}
        error={err(errors.targetAudience)}
        required
      />
      <div className="grid gap-5 sm:grid-cols-2">
        <TextField
          label={t("expectedAttendance")}
          name="expectedAttendance"
          type="number"
          dir="ltr"
          value={d.expectedAttendance}
          onChange={(v) => set("expectedAttendance", v)}
          error={err(errors.expectedAttendance)}
          required
        />
        <SelectField
          label={t("activityFormat")}
          name="activityFormat"
          value={d.activityFormat}
          onChange={(v) => set("activityFormat", v)}
          options={ACTIVITY_FORMATS}
          error={err(errors.activityFormat)}
          required
        />
      </div>
    </div>
  );
}

export function StepVenue({ d, set, errors }: StepProps) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;

  return (
    <div className="grid gap-5">
      <SelectField
        label={t("venue")}
        name="venue"
        value={d.venue}
        onChange={(v) => set("venue", v)}
        options={VENUES}
        error={err(errors.venue)}
        required
      />
      {d.venue === "off_campus" && (
        <div className="goal-item grid gap-5 rounded-lg border border-iau-green-light bg-iau-green-light/40 p-5 sm:grid-cols-2">
          <TextField
            label={t("externalHost")}
            name="externalHost"
            value={d.externalHost}
            onChange={(v) => set("externalHost", v)}
            error={err(errors.externalHost)}
            required
          />
          <TextField
            label={t("cityCountry")}
            name="cityCountry"
            value={d.cityCountry}
            onChange={(v) => set("cityCountry", v)}
            error={err(errors.cityCountry)}
            required
          />
          <TextField
            label={t("locationDetails")}
            name="locationDetails"
            value={d.locationDetails}
            onChange={(v) => set("locationDetails", v)}
          />
          <SelectField
            label={t("externalParticipationType")}
            name="externalParticipationType"
            value={d.externalParticipationType}
            onChange={(v) => set("externalParticipationType", v)}
            options={EXTERNAL_PARTICIPATION_TYPES}
            error={err(errors.externalParticipationType)}
            required
          />
        </div>
      )}
      {d.venue && d.venue !== "off_campus" && (
        <TextField
          label={t("locationDetails")}
          name="locationDetails"
          value={d.locationDetails}
          onChange={(v) => set("locationDetails", v)}
        />
      )}
    </div>
  );
}

const EMPTY_PARTNER: PartnerEntry = {
  name: "",
  type: "",
  hasMou: false,
  mouRef: "",
  hasObligation: false,
  obligationNote: "",
};

export function StepParticipants({ d, set, errors }: StepProps) {
  const t = useTranslations("request.fields");
  const te = useTranslations("request.errors");
  const err = (c?: string) =>
    c ? te(c as Parameters<typeof te>[0]) : undefined;

  const setPartner = (i: number, patch: Partial<PartnerEntry>) =>
    set(
      "partners",
      d.partners.map((p, j) => (j === i ? { ...p, ...patch } : p)),
    );

  return (
    <div className="grid gap-6">
      <YesNo
        label={t("hasStudents")}
        name="hasStudents"
        value={d.hasStudents}
        onChange={(v) => set("hasStudents", v)}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.hasStudents)}
      />
      {d.hasStudents && (
        <div className="goal-item max-w-xs">
          <TextField
            label={t("studentCount")}
            name="studentCount"
            type="number"
            dir="ltr"
            value={d.studentCount}
            onChange={(v) => set("studentCount", v)}
            error={err(errors.studentCount)}
            required
          />
        </div>
      )}

      <YesNo
        label={t("hasFaculty")}
        name="hasFaculty"
        value={d.hasFaculty}
        onChange={(v) => set("hasFaculty", v)}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.hasFaculty)}
      />
      {d.hasFaculty && (
        <div className="goal-item max-w-xs">
          <TextField
            label={t("facultyCount")}
            name="facultyCount"
            type="number"
            dir="ltr"
            value={d.facultyCount}
            onChange={(v) => set("facultyCount", v)}
            error={err(errors.facultyCount)}
            required
          />
        </div>
      )}

      <YesNo
        label={t("hasPartners")}
        name="hasPartners"
        value={d.hasPartners}
        onChange={(v) => {
          set("hasPartners", v);
          if (v && d.partners.length === 0)
            set("partners", [{ ...EMPTY_PARTNER }]);
        }}
        yesLabel={t("yes")}
        noLabel={t("no")}
        error={err(errors.hasPartners)}
      />
      {d.hasPartners && (
        <div className="grid gap-4">
          <ErrorText id="partners-error" message={err(errors.partners)} />
          {d.partners.map((p, i) => (
            <div
              key={i}
              className="goal-item grid gap-4 rounded-lg border border-iau-green-light bg-iau-green-light/40 p-5 sm:grid-cols-2"
            >
              <TextField
                label={t("partnerName")}
                name={`partnerName-${i}`}
                value={p.name}
                onChange={(v) => setPartner(i, { name: v })}
                required
              />
              <SelectField
                label={t("partnerType")}
                name={`partnerType-${i}`}
                value={p.type}
                onChange={(v) => setPartner(i, { type: v })}
                options={PARTNERSHIP_TYPES}
                required
              />
              <Segmented
                label={t("partnerMou")}
                name={`partnerMou-${i}`}
                value={p.hasMou ? "yes" : "no"}
                onChange={(v) => setPartner(i, { hasMou: v === "yes" })}
                options={[
                  { value: "yes", label: t("yes") },
                  { value: "no", label: t("no") },
                ]}
              />
              {p.hasMou && (
                <TextField
                  label={t("partnerMouRef")}
                  name={`partnerMouRef-${i}`}
                  value={p.mouRef}
                  onChange={(v) => setPartner(i, { mouRef: v })}
                />
              )}
              <Segmented
                label={t("partnerObligation")}
                name={`partnerObligation-${i}`}
                value={p.hasObligation ? "yes" : "no"}
                onChange={(v) => setPartner(i, { hasObligation: v === "yes" })}
                options={[
                  { value: "yes", label: t("yes") },
                  { value: "no", label: t("no") },
                ]}
              />
              {p.hasObligation && (
                <TextField
                  label={t("partnerObligationNote")}
                  name={`partnerObligationNote-${i}`}
                  value={p.obligationNote}
                  onChange={(v) => setPartner(i, { obligationNote: v })}
                />
              )}
              <div className="sm:col-span-2">
                <button
                  type="button"
                  onClick={() =>
                    set(
                      "partners",
                      d.partners.filter((_, j) => j !== i),
                    )
                  }
                  className="press text-sm font-semibold text-red-600 hover:underline"
                >
                  {t("removePartner")}
                </button>
              </div>
            </div>
          ))}
          <button
            type="button"
            onClick={() => set("partners", [...d.partners, { ...EMPTY_PARTNER }])}
            className="press w-fit rounded-md border border-iau-green px-4 py-2 text-sm font-semibold text-iau-green hover:bg-iau-green-light"
          >
            + {t("addPartner")}
          </button>
        </div>
      )}
    </div>
  );
}
