"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useLocale } from "next-intl";
import type { CollegeGroup, Option } from "@/lib/requests/options";
import { cn } from "@/lib/utils";

type Loc = "en" | "ar";

export function ErrorText({ id, message }: { id: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} role="alert" className="mt-1.5 text-sm text-red-600">
      {message}
    </p>
  );
}

function LabelRow({
  label,
  required,
  htmlFor,
}: {
  label: string;
  required?: boolean;
  htmlFor?: string;
}) {
  return (
    <label
      htmlFor={htmlFor}
      className="mb-1.5 block text-sm font-semibold text-gray-800"
    >
      {label}
      {required && <span className="text-red-500"> *</span>}
    </label>
  );
}

const inputCls = (error?: string) =>
  cn(
    "w-full rounded-md border bg-white px-3.5 py-2.5 text-gray-900 outline-none transition-shadow",
    "focus:ring-2 focus:ring-iau-green",
    error ? "border-red-400" : "border-gray-300",
  );

/**
 * type="number" inputs natively accept e/E/+/- (exponent and sign notation);
 * our numeric fields are plain counts and amounts, so block those keys.
 */
export const blockNonNumericKeys = (
  e: React.KeyboardEvent<HTMLInputElement>,
) => {
  if (["e", "E", "+", "-"].includes(e.key)) e.preventDefault();
};

export function TextField({
  label,
  name,
  value,
  onChange,
  onBlur,
  error,
  required,
  type = "text",
  dir,
  hint,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  error?: string;
  required?: boolean;
  type?: string;
  dir?: "ltr" | "rtl";
  hint?: string;
}) {
  return (
    <div>
      <LabelRow label={label} required={required} htmlFor={name} />
      <input
        id={name}
        name={name}
        type={type}
        dir={dir}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onBlur}
        onKeyDown={type === "number" ? blockNonNumericKeys : undefined}
        inputMode={type === "number" ? "numeric" : undefined}
        aria-invalid={!!error}
        aria-describedby={error ? `${name}-error` : undefined}
        className={inputCls(error)}
      />
      {hint && <p className="mt-1 text-xs text-gray-500">{hint}</p>}
      <ErrorText id={`${name}-error`} message={error} />
    </div>
  );
}

export function TextArea({
  label,
  name,
  value,
  onChange,
  onBlur,
  error,
  required,
  rows = 5,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  error?: string;
  required?: boolean;
  rows?: number;
}) {
  return (
    <div>
      <LabelRow label={label} required={required} htmlFor={name} />
      <textarea
        id={name}
        name={name}
        rows={rows}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onBlur}
        aria-invalid={!!error}
        aria-describedby={error ? `${name}-error` : undefined}
        className={inputCls(error)}
      />
      <ErrorText id={`${name}-error`} message={error} />
    </div>
  );
}

export function SelectField({
  label,
  name,
  value,
  onChange,
  options,
  error,
  required,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (v: string) => void;
  options: Option[];
  error?: string;
  required?: boolean;
}) {
  const locale = useLocale() as Loc;
  return (
    <div>
      <LabelRow label={label} required={required} htmlFor={name} />
      <select
        id={name}
        name={name}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-invalid={!!error}
        aria-describedby={error ? `${name}-error` : undefined}
        className={inputCls(error)}
      >
        <option value="" disabled hidden />
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label[locale]}
          </option>
        ))}
      </select>
      <ErrorText id={`${name}-error`} message={error} />
    </div>
  );
}

/** Native select with optgroup sections (e.g. colleges grouped by track). */
export function GroupedSelectField({
  label,
  name,
  value,
  onChange,
  groups,
  error,
  required,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (v: string) => void;
  groups: CollegeGroup[];
  error?: string;
  required?: boolean;
}) {
  const locale = useLocale() as Loc;
  return (
    <div>
      <LabelRow label={label} required={required} htmlFor={name} />
      <select
        id={name}
        name={name}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-invalid={!!error}
        aria-describedby={error ? `${name}-error` : undefined}
        className={inputCls(error)}
      >
        <option value="" disabled hidden />
        {groups.map((g) => (
          <optgroup key={g.group.en} label={g.group[locale]}>
            {g.colleges.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label[locale]}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
      <ErrorText id={`${name}-error`} message={error} />
    </div>
  );
}

/**
 * Dropdown multi select — a select-like trigger that opens a checkbox list.
 * Selected values render as removable tags under the trigger, keeping long
 * option catalogs (request types, SDGs…) compact instead of a wall of chips.
 */
export function MultiSelect({
  label,
  name,
  values,
  onChange,
  options,
  error,
  required,
  hint,
}: {
  label: string;
  name: string;
  values: string[];
  onChange: (v: string[]) => void;
  options: Option[];
  error?: string;
  required?: boolean;
  hint?: string;
}) {
  const locale = useLocale() as Loc;
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const listId = useId();

  // Close on outside click / Escape
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const toggle = (v: string) =>
    onChange(
      values.includes(v) ? values.filter((x) => x !== v) : [...values, v],
    );

  const placeholder = locale === "ar" ? "اختر من القائمة…" : "Select…";
  const summary =
    values.length === 0
      ? placeholder
      : locale === "ar"
        ? `تم اختيار ${values.length}`
        : `${values.length} selected`;

  return (
    // z-30 while open so the panel paints above later fields, whose entrance
    // animations (`.goal-item`, fill-mode both) keep their own stacking
    // contexts alive; globals.css lifts animated ancestors the same way.
    <div ref={rootRef} className={cn("relative", open && "z-30")}>
      <LabelRow label={label} required={required} htmlFor={name} />
      <button
        id={name}
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listId}
        aria-describedby={error ? `${name}-error` : undefined}
        className={cn(
          inputCls(error),
          "flex items-center justify-between gap-2 text-start",
          values.length === 0 && "text-gray-400",
        )}
      >
        <span className="truncate">{summary}</span>
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          aria-hidden
          className={cn(
            "shrink-0 text-gray-400 transition-transform duration-200",
            open && "rotate-180",
          )}
        >
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>

      {open && (
        <div
          id={listId}
          role="listbox"
          aria-multiselectable
          className="goal-item absolute inset-x-0 top-full z-20 mt-1.5 max-h-72 overflow-y-auto rounded-lg border border-gray-200 bg-white p-1.5 shadow-lg"
        >
          {options.map((o) => {
            const on = values.includes(o.value);
            return (
              <button
                key={o.value}
                type="button"
                role="option"
                aria-selected={on}
                onClick={() => toggle(o.value)}
                className={cn(
                  "flex w-full items-start gap-2.5 rounded-md px-3 py-2 text-start text-sm transition-colors",
                  on
                    ? "bg-iau-green-light/60 font-semibold text-iau-green"
                    : "text-gray-700 hover:bg-iau-section",
                )}
              >
                <span
                  aria-hidden
                  className={cn(
                    "mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded border transition-colors",
                    on
                      ? "border-iau-green bg-iau-green text-white"
                      : "border-gray-300 bg-white",
                  )}
                >
                  {on && (
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </span>
                <span className="leading-5">{o.label[locale]}</span>
              </button>
            );
          })}
        </div>
      )}

      {values.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {values.map((v) => {
            const o = options.find((x) => x.value === v);
            if (!o) return null;
            return (
              <span
                key={v}
                className="goal-item inline-flex max-w-full items-center gap-1.5 rounded-full bg-iau-green-light px-3 py-1 text-xs font-semibold text-iau-green"
              >
                <span className="truncate">{o.label[locale]}</span>
                <button
                  type="button"
                  onClick={() => toggle(v)}
                  aria-label={
                    locale === "ar"
                      ? `إزالة ${o.label.ar}`
                      : `Remove ${o.label.en}`
                  }
                  className="press -me-0.5 rounded-full p-0.5 text-iau-green/60 transition-colors hover:bg-iau-green hover:text-white"
                >
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden>
                    <path d="M6 6l12 12M18 6L6 18" />
                  </svg>
                </button>
              </span>
            );
          })}
        </div>
      )}
      {hint && <p className="mt-1 text-xs text-gray-500">{hint}</p>}
      <ErrorText id={`${name}-error`} message={error} />
    </div>
  );
}

/** Segmented yes/no (or custom option list) */
export function Segmented({
  label,
  name,
  value,
  onChange,
  options,
  error,
  required,
  hint,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  error?: string;
  required?: boolean;
  hint?: string;
}) {
  return (
    <fieldset aria-describedby={error ? `${name}-error` : undefined}>
      <legend className="mb-1.5 text-sm font-semibold text-gray-800">
        {label}
        {required && <span className="text-red-500"> *</span>}
      </legend>
      <div className="inline-flex overflow-hidden rounded-md border border-gray-300">
        {options.map((o, i) => (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            aria-pressed={value === o.value}
            className={cn(
              "press px-5 py-2 text-sm font-medium transition-colors",
              i > 0 && "border-s border-gray-300",
              value === o.value
                ? "bg-iau-green text-white"
                : "bg-white text-gray-700 hover:bg-iau-green-light",
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
      {hint && <p className="mt-1 text-xs text-gray-500">{hint}</p>}
      <ErrorText id={`${name}-error`} message={error} />
    </fieldset>
  );
}

/** Yes/No helper bound to boolean|null model values */
export function YesNo({
  label,
  name,
  value,
  onChange,
  yesLabel,
  noLabel,
  error,
  required = true,
  hint,
}: {
  label: string;
  name: string;
  value: boolean | null;
  onChange: (v: boolean) => void;
  yesLabel: string;
  noLabel: string;
  error?: string;
  required?: boolean;
  hint?: string;
}) {
  return (
    <Segmented
      label={label}
      name={name}
      value={value === null ? "" : value ? "yes" : "no"}
      onChange={(v) => onChange(v === "yes")}
      options={[
        { value: "yes", label: yesLabel },
        { value: "no", label: noLabel },
      ]}
      error={error}
      required={required}
      hint={hint}
    />
  );
}
