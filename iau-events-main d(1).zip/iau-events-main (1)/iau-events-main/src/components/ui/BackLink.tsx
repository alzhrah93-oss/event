import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { cn } from "@/lib/utils";

/**
 * Top-corner back navigation for nested pages. Uses an explicit parent
 * destination (predictable back) rather than browser history. The arrow
 * mirrors automatically in RTL. `light` renders a photo-friendly variant.
 */
export default function BackLink({
  href,
  label,
  light = false,
}: {
  href: string;
  /** Override the default localized "Back" label with a destination name */
  label?: string;
  /** Light styling for placement over photos/dark surfaces */
  light?: boolean;
}) {
  const t = useTranslations("common");
  return (
    <Link
      href={href}
      className={cn(
        "press inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-sm font-semibold transition-colors",
        light
          ? "bg-black/25 text-white backdrop-blur-sm hover:bg-black/40"
          : "text-gray-500 hover:bg-iau-green-light hover:text-iau-green",
      )}
    >
      <span aria-hidden className="inline-block rtl:rotate-180">←</span>
      {label ?? t("back")}
    </Link>
  );
}
