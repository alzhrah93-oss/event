import BackLink from "./BackLink";
import { getSessionProfile } from "@/lib/auth/guard";

/**
 * Back-to-dashboard link for public pages (calendar, requirements, …):
 * renders only when someone is signed in, pointing at their own dashboard
 * so organizers and admins always have a way back.
 */
export default async function DashboardBackLink() {
  const profile = await getSessionProfile();
  if (!profile) return null;
  return (
    <BackLink
      href={profile.role === "organizer" ? "/dashboard" : "/admin"}
    />
  );
}
