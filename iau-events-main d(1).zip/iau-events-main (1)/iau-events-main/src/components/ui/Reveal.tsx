"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

/**
 * Fade-and-rise scroll reveal. Fires once when the element enters the
 * viewport. Motion styles live in globals.css (`.reveal`), which also
 * handles prefers-reduced-motion.
 */
export default function Reveal({
  children,
  delay = 0,
  className,
  as: Tag = "div",
  pop = false,
}: {
  children: React.ReactNode;
  /** Stagger delay in ms */
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li" | "span";
  /** Card-grid variant: slight scale with a gentle overshoot (never for tables) */
  pop?: boolean;
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "-60px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <Tag
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ref={ref as any}
      data-shown={shown}
      style={{ "--reveal-delay": `${delay}ms` } as React.CSSProperties}
      className={cn(pop ? "reveal-pop" : "reveal", className)}
    >
      {children}
    </Tag>
  );
}
