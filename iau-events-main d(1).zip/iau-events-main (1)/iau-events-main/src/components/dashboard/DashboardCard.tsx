import { Link } from "@/i18n/navigation";
import CountUp from "@/components/ui/CountUp";
import { cn } from "@/lib/utils";

export default function DashboardCard({
  title,
  description,
  href,
  disabledNote,
  badge,
}: {
  title: string;
  description: string;
  /** Omit while the feature's phase isn't built yet */
  href?: string;
  disabledNote?: string;
  /** Count of items waiting inside — shown as a gold pill next to the title */
  badge?: number;
}) {
  const inner = (
    <>
      <div className="flex items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-lg font-bold text-iau-green transition-colors group-hover:text-iau-green-dark">
          {title}
          {badge !== undefined && badge > 0 && (
            <span className="goal-item inline-flex h-6 min-w-6 items-center justify-center rounded-full bg-iau-gold px-1.5 text-xs font-bold text-white">
              <CountUp value={badge} />
            </span>
          )}
        </h3>
        {href && (
          <span
            aria-hidden
            className="text-iau-green opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100 -translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-0 rtl:translate-x-1"
          >
            →
          </span>
        )}
      </div>
      <p className="mt-1.5 text-sm leading-6 text-gray-600">{description}</p>
      {disabledNote && (
        <p className="mt-3 inline-block rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-500">
          {disabledNote}
        </p>
      )}
    </>
  );

  // h-full + fixed min height keeps every card identical in both dashboards
  // and both languages regardless of text length.
  const base =
    "flex h-full min-h-40 flex-col rounded-xl border border-gray-200 bg-white p-6 shadow-sm";

  return href ? (
    <Link href={href} className={cn(base, "card-lift press group")}>
      {inner}
    </Link>
  ) : (
    <div className={cn(base, "opacity-80")}>{inner}</div>
  );
}
