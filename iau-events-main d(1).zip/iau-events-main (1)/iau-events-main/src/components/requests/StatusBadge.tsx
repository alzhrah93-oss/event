import { useTranslations } from "next-intl";
import { STATUS_META, type RequestStatus } from "@/lib/requests/status";
import { cn } from "@/lib/utils";

export default function StatusBadge({ status }: { status: RequestStatus }) {
  const t = useTranslations("status");
  const meta = STATUS_META[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold",
        meta.badge,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} aria-hidden />
      {t(status)}
    </span>
  );
}
