"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { cancelRequest } from "@/lib/requests/actions";

export default function CancelButton({
  requestId,
  requestNumber,
}: {
  requestId: string;
  requestNumber: string;
}) {
  const t = useTranslations("myRequests.cancel");
  const [confirming, setConfirming] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  if (!confirming) {
    return (
      <button
        type="button"
        onClick={() => setConfirming(true)}
        className="press rounded-md border border-red-300 px-5 py-2.5 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50"
      >
        {t("button")}
      </button>
    );
  }

  return (
    <div
      role="alertdialog"
      aria-labelledby="cancel-title"
      className="goal-item rounded-lg border border-red-200 bg-red-50 p-5"
    >
      <p id="cancel-title" className="font-bold text-red-700">
        {t("confirmTitle")}
      </p>
      <p className="mt-1 text-sm text-red-600">
        {t("confirmBody", { number: requestNumber })}
      </p>
      <div className="mt-4 flex gap-3">
        <button
          type="button"
          disabled={pending}
          onClick={() =>
            startTransition(async () => {
              const res = await cancelRequest(requestId);
              if (res.ok) router.refresh();
            })
          }
          className="press rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-red-700 disabled:opacity-60"
        >
          {t("confirmYes")}
        </button>
        <button
          type="button"
          disabled={pending}
          onClick={() => setConfirming(false)}
          className="press rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 transition-colors hover:bg-gray-50"
        >
          {t("confirmNo")}
        </button>
      </div>
    </div>
  );
}
