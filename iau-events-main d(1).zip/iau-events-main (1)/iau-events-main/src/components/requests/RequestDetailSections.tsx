import { getLocale, getTranslations } from "next-intl/server";
import { FOCUS_AREAS, GRAND_CHALLENGES } from "@/lib/content";
import {
  formatDate,
  formatTime,
  labelsFor,
  optionLabel,
} from "@/lib/requests/display";
import {
  ACTIVITY_FORMATS,
  ALL_ENTITY_DETAILS,
  EXPECTED_OUTPUTS,
  EXTERNAL_PARTICIPATION_TYPES,
  FOLLOWUP_PATHWAYS,
  FUNDING_SOURCES,
  ORGANIZING_ENTITIES,
  OTHER_PREFIX,
  PARTNERSHIP_TYPES,
  REQUEST_TYPES,
  SDGS,
  TARGET_AUDIENCE,
  VENUES,
} from "@/lib/requests/options";
import type { RequestStatus } from "@/lib/requests/status";

type Loc = "en" | "ar";

export function Row({
  label,
  value,
}: {
  label: string;
  value?: string | number | null;
}) {
  const v =
    value === null || value === undefined || value === "" ? "—" : String(value);
  return (
    <div className="grid gap-1 py-2.5 sm:grid-cols-3 sm:gap-4">
      <dt className="text-sm font-semibold text-gray-500">{label}</dt>
      <dd className="text-sm leading-6 text-gray-800 sm:col-span-2">{v}</dd>
    </div>
  );
}

export function Section({
  title,
  children,
  delay = 0,
}: {
  title: string;
  children: React.ReactNode;
  delay?: number;
}) {
  return (
    <section
      style={{ animationDelay: `${delay}ms` }}
      className="goal-item rounded-xl border border-gray-200 bg-white p-6 shadow-sm"
    >
      <h2 className="mb-3 border-b border-gray-100 pb-3 text-lg font-bold text-iau-green">
        {title}
      </h2>
      <dl className="divide-y divide-gray-50">{children}</dl>
    </section>
  );
}

/* eslint-disable @typescript-eslint/no-explicit-any -- rows come straight from Supabase */
type AnyRow = Record<string, any>;

/**
 * The full read-only view of a request (applicant → history), shared between
 * the IIE admin detail page and the entity-head detail page. Attachment rows
 * must arrive with their signed URLs already created by the caller.
 */
export default async function RequestDetailSections({
  r,
  alignment,
  attachments,
  signed,
  history,
}: {
  r: AnyRow;
  alignment: AnyRow[];
  attachments: AnyRow[];
  signed: Map<string, string>;
  history: AnyRow[];
}) {
  const t = await getTranslations("admin");
  const tr = await getTranslations("request.fields");
  const ts = await getTranslations("status");
  const locale = (await getLocale()) as Loc;

  const yn = (v: boolean | null) =>
    v === null ? "—" : v ? tr("yes") : tr("no");
  const goalLabel = (areaId: string, goalEn: string) => {
    if (goalEn.startsWith(OTHER_PREFIX))
      return goalEn.slice(OTHER_PREFIX.length);
    const area = FOCUS_AREAS.find((a) => a.id === areaId);
    const goal = area?.goals.find((g) => g.en === goalEn);
    return goal ? goal[locale] : goalEn;
  };
  const dtFmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const entityDetailLabel =
    r.organizing_entity === "college"
      ? tr("collegeName")
      : ["deanship", "institute", "center", "hospital"].includes(
            r.organizing_entity,
          )
        ? tr(`entityDetail_${r.organizing_entity}` as Parameters<typeof tr>[0])
        : tr("entityDetailLabel");

  return (
    <>
      <Section title={t("detail.sections.applicant")} delay={40}>
        <Row
          label={tr("organizingEntity")}
          value={optionLabel(ORGANIZING_ENTITIES, r.organizing_entity, locale)}
        />
        {r.entity_detail && (
          <Row
            label={entityDetailLabel}
            // Catalogued slugs resolve to localized names; free text passes through
            value={optionLabel(ALL_ENTITY_DETAILS, r.entity_detail, locale)}
          />
        )}
        <Row label={tr("applicantName")} value={r.applicant_name} />
        <Row label={tr("jobTitle")} value={r.job_title} />
        <Row label={tr("universityEmail")} value={r.university_email} />
        <Row label={tr("mobile")} value={r.mobile} />
        <Row label={tr("altCoordinator")} value={r.alt_coordinator} />
        <Row
          label={tr("altCoordinatorPhone")}
          value={r.alt_coordinator_phone}
        />
        <Row
          label={tr("altCoordinatorEmail")}
          value={r.alt_coordinator_email}
        />
      </Section>

      <Section title={t("detail.sections.activity")} delay={80}>
        <Row
          label={tr("requestTypes")}
          value={labelsFor(REQUEST_TYPES, r.request_types, locale)}
        />
        <Row label={tr("titleField")} value={r.title} />
        <Row label={tr("description")} value={r.description} />
        <Row
          label={tr("activityDate")}
          value={formatDate(r.activity_date, locale)}
        />
        <Row
          label={`${tr("startTime")} – ${tr("endTime")}`}
          value={`${formatTime(r.start_time)} – ${formatTime(r.end_time)}`}
        />
        <Row
          label={tr("targetAudience")}
          value={labelsFor(TARGET_AUDIENCE, r.target_audience, locale)}
        />
        <Row label={tr("expectedAttendance")} value={r.expected_attendance} />
        <Row
          label={tr("activityFormat")}
          value={optionLabel(ACTIVITY_FORMATS, r.activity_format, locale)}
        />
      </Section>

      <Section title={t("detail.sections.venue")} delay={120}>
        <Row label={tr("venue")} value={optionLabel(VENUES, r.venue, locale)} />
        {r.venue === "off_campus" && (
          <>
            <Row label={tr("externalHost")} value={r.external_host} />
            <Row label={tr("cityCountry")} value={r.city_country} />
            <Row
              label={tr("externalParticipationType")}
              value={
                r.external_participation_type
                  ? optionLabel(
                      EXTERNAL_PARTICIPATION_TYPES,
                      r.external_participation_type,
                      locale,
                    )
                  : null
              }
            />
          </>
        )}
        <Row label={tr("locationDetails")} value={r.location_details} />
      </Section>

      <Section title={t("detail.sections.participants")} delay={160}>
        <Row label={tr("hasStudents")} value={yn(r.has_students)} />
        {r.has_students && (
          <Row label={tr("studentCount")} value={r.student_count} />
        )}
        <Row label={tr("hasFaculty")} value={yn(r.has_faculty)} />
        {r.has_faculty && (
          <Row label={tr("facultyCount")} value={r.faculty_count} />
        )}
        <Row label={tr("hasPartners")} value={yn(r.has_partners)} />
        {r.has_partners &&
          (Array.isArray(r.partners) && r.partners.length > 0 ? (
            r.partners.map(
              (
                p: {
                  name: string;
                  type: string;
                  hasMou: boolean;
                  mouRef: string;
                },
                i: number,
              ) => (
                <Row
                  key={i}
                  label={`${tr("partnerName")} ${i + 1}`}
                  value={`${p.name} — ${optionLabel(PARTNERSHIP_TYPES, p.type, locale)}${p.hasMou ? ` (${tr("partnerMou")}: ${p.mouRef || tr("yes")})` : ""}`}
                />
              ),
            )
          ) : (
            <Row label={tr("hasPartners")} value={t("detail.partnersNone")} />
          ))}
      </Section>

      <Section title={t("detail.sections.alignment")} delay={200}>
        {alignment.map((a) => {
          const area = FOCUS_AREAS.find((f) => f.id === a.focus_area_id);
          const challenges = ((a.grand_challenges ?? []) as string[])
            .map((c) =>
              c.startsWith(OTHER_PREFIX)
                ? c.slice(OTHER_PREFIX.length)
                : (GRAND_CHALLENGES.find((gc) => gc.id === c)?.text[locale] ??
                  c),
            )
            .join(locale === "ar" ? "؛ " : "; ");
          return (
            <div key={a.id}>
              <Row
                label={area ? area.name[locale] : a.focus_area_id}
                value={(a.goals as string[])
                  .map((g) => goalLabel(a.focus_area_id, g))
                  .join(locale === "ar" ? "، " : ", ")}
              />
              {challenges && (
                <Row label={tr("grandChallenges")} value={challenges} />
              )}
            </div>
          );
        })}
        <Row label={tr("sdgs")} value={labelsFor(SDGS, r.sdgs, locale)} />
        <Row
          label={tr("expectedOutputs")}
          value={labelsFor(EXPECTED_OUTPUTS, r.expected_outputs, locale)}
        />
        {r.impact_indicators && (
          <Row label={tr("impactIndicators")} value={r.impact_indicators} />
        )}
        <Row
          label={tr("followupPathways")}
          value={labelsFor(FOLLOWUP_PATHWAYS, r.followup_pathways, locale)}
        />
      </Section>

      <Section title={t("detail.sections.ip")} delay={240}>
        <Row
          label={tr("presentsIp")}
          value={
            r.presents_ip === "yes"
              ? tr("yes")
              : r.presents_ip === "no"
                ? tr("no")
                : tr("unsure")
          }
        />
        {r.presents_ip !== "no" && (
          <>
            <Row label={tr("ipDisclosed")} value={yn(r.ip_disclosed)} />
            <Row label={tr("ipPrototype")} value={yn(r.ip_prototype)} />
            <Row label={tr("ipPatent")} value={r.ip_patent} />
            <Row label={tr("ipUnpublished")} value={yn(r.ip_unpublished)} />
            <Row label={tr("ipNda")} value={r.ip_nda} />
          </>
        )}
      </Section>

      <Section title={t("detail.sections.budget")} delay={280}>
        <Row label={tr("needsFunding")} value={yn(r.needs_funding)} />
        {r.needs_funding ? (
          <>
            <Row
              label={tr("fundingSource")}
              value={
                r.funding_source
                  ? optionLabel(FUNDING_SOURCES, r.funding_source, locale)
                  : null
              }
            />
            {(r.budget_items as { item: string; cost: string }[]).map(
              (b, i) => (
                <Row
                  key={i}
                  label={`${tr("budgetItem")} ${i + 1}`}
                  value={`${b.item} — ${b.cost} SAR`}
                />
              ),
            )}
          </>
        ) : (
          <Row label={tr("budgetItems")} value={t("detail.budgetNone")} />
        )}
        <Row label={tr("needsLabs")} value={yn(r.needs_labs)} />
        {r.needs_labs && (
          <Row label={tr("labsDetails")} value={r.labs_details} />
        )}
        <Row label={tr("needsMaterials")} value={yn(r.needs_materials)} />
        {r.needs_materials && (
          <Row label={tr("materialsDetails")} value={r.materials_details} />
        )}
        <Row label={tr("needsMedia")} value={yn(r.needs_media)} />
      </Section>

      <Section title={t("detail.sections.attachments")} delay={320}>
        {attachments.length === 0 ? (
          <p className="py-2 text-sm text-gray-500">
            {t("detail.noAttachments")}
          </p>
        ) : (
          attachments.map((a) => (
            <div
              key={a.id}
              className="flex items-center justify-between gap-3 py-2.5"
            >
              <span className="text-sm text-gray-800">
                {tr(`attachment_${a.kind}` as Parameters<typeof tr>[0])}
                <span className="ms-2 text-xs text-gray-400" dir="ltr">
                  {a.file_name}
                </span>
              </span>
              {signed.get(a.id) && (
                <a
                  href={signed.get(a.id)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="press rounded-md border border-iau-green px-3 py-1.5 text-xs font-semibold text-iau-green transition-colors hover:bg-iau-green-light"
                >
                  {t("detail.download")}
                </a>
              )}
            </div>
          ))
        )}
      </Section>

      <Section title={t("detail.sections.history")} delay={360}>
        {history.map((h) => (
          <div key={h.id} className="flex items-center gap-3 py-2.5 text-sm">
            <span className="text-gray-400">
              {dtFmt.format(new Date(h.created_at))}
            </span>
            <span className="font-medium text-gray-700">
              {h.from_status && (
                <>
                  {ts(h.from_status as RequestStatus)}
                  <span
                    aria-hidden
                    className="mx-1 inline-block rtl:rotate-180"
                  >
                    →
                  </span>
                </>
              )}
              {ts(h.to_status as RequestStatus)}
            </span>
            {h.note && <span className="text-gray-500">— {h.note}</span>}
          </div>
        ))}
      </Section>
    </>
  );
}
