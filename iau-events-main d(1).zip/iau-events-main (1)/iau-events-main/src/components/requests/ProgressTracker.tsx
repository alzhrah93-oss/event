import { useTranslations } from "next-intl";
import { progressStage, type RequestStatus } from "@/lib/requests/status";
import { cn } from "@/lib/utils";

/**
 * One distinct color per step, matching the status-badge language:
 * submitted (blue) → entity approval (cyan) → institute review (indigo) →
 * decision (green, red when rejected) → closed (deep brand green).
 */
const STEP_STYLES = [
  {
    seg: "bg-blue-500",
    node: "border-blue-500 bg-blue-500",
    text: "text-blue-600",
    ring: "ring-blue-500/20",
  },
  {
    seg: "bg-cyan-500",
    node: "border-cyan-500 bg-cyan-500",
    text: "text-cyan-600",
    ring: "ring-cyan-500/20",
  },
  {
    seg: "bg-indigo-500",
    node: "border-indigo-500 bg-indigo-500",
    text: "text-indigo-600",
    ring: "ring-indigo-500/20",
  },
  {
    seg: "bg-emerald-500",
    node: "border-emerald-500 bg-emerald-500",
    text: "text-emerald-600",
    ring: "ring-emerald-500/20",
  },
  {
    seg: "bg-iau-green",
    node: "border-iau-green bg-iau-green",
    text: "text-iau-green",
    ring: "ring-iau-green/20",
  },
] as const;

const MINI_SEGS = [
  "bg-blue-500",
  "bg-cyan-500",
  "bg-indigo-500",
  "bg-emerald-500",
  "bg-iau-green",
] as const;

const isRejected = (status: RequestStatus) =>
  status === "not_approved" || status === "entity_rejected";

/**
 * Compact 5-segment progress bar for list rows — same stage mapping as the
 * full tracker, with the same per-step shades. Cancelled shows a muted full
 * bar; rejection turns the decision segments red.
 */
export function MiniTracker({ status }: { status: RequestStatus }) {
  const stage = progressStage(status);
  const rejected = isRejected(status);
  return (
    <div className="flex w-24 gap-1" aria-hidden>
      {[1, 2, 3, 4, 5].map((n) => (
        <span
          key={n}
          className={cn(
            "h-1.5 flex-1 rounded-full",
            status === "cancelled"
              ? "bg-gray-300"
              : stage >= n
                ? rejected && n >= 4
                  ? "bg-red-400"
                  : MINI_SEGS[n - 1]
                : "bg-gray-200",
          )}
        />
      ))}
    </div>
  );
}

/**
 * 5-stage process line: Submitted → Entity Approval → Institute Review →
 * Decision → Closed. Reached segments draw in sequence and nodes pop in
 * after them (globals.css `.track-seg` / `.track-node`). Each step carries
 * its own brand shade; once decided, the decision step is labelled with the
 * actual outcome (Approved / Not approved / Rejected by entity) and turns
 * red on rejection. Mirrors correctly in RTL.
 */
export default function ProgressTracker({
  status,
}: {
  status: RequestStatus;
}) {
  const t = useTranslations("status.track");
  const ts = useTranslations("status");
  const stage = progressStage(status);
  if (stage === 0) return null; // cancelled — caller shows a notice instead

  const rejected = isRejected(status);
  const decided = stage >= 4;
  const decisionLabel = !decided
    ? t("decision")
    : rejected
      ? ts(status as "not_approved" | "entity_rejected")
      : ts("approved");

  const steps = [
    { label: t("submitted"), n: 1 },
    { label: t("entity"), n: 2 },
    { label: t("review"), n: 3 },
    { label: decisionLabel, n: 4 },
    { label: t("closed"), n: 5 },
  ] as const;

  const delay = (n: number, offset = 0) =>
    ({ "--track-delay": `${n * 200 + offset}ms` }) as React.CSSProperties;

  return (
    <ol className="flex w-full items-start">
      {steps.map((s, i) => {
        const reached = stage >= s.n;
        const isCurrent = stage === s.n;
        const failNode = rejected && s.n === 4;
        const style = STEP_STYLES[i];
        const nextStyle = STEP_STYLES[Math.min(i + 1, 4)];
        return (
          <li key={s.n} className="flex flex-1 flex-col items-center">
            <div className="flex w-full items-center">
              <div
                style={reached ? delay(i) : undefined}
                className={cn(
                  "h-1 flex-1 rounded",
                  i === 0
                    ? "bg-transparent"
                    : stage >= s.n
                      ? cn("track-seg", failNode ? "bg-red-400" : style.seg)
                      : "bg-gray-200",
                )}
              />
              <div
                style={reached ? delay(i, 140) : undefined}
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-xs font-bold",
                  reached && "track-node",
                  failNode
                    ? "border-red-500 bg-red-500 text-white"
                    : reached
                      ? cn(style.node, "text-white")
                      : "border-gray-300 bg-white text-gray-400",
                  isCurrent && !failNode && cn("ring-4", style.ring),
                  isCurrent && failNode && "ring-4 ring-red-100",
                )}
              >
                {reached ? (
                  failNode ? (
                    "✕"
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden>
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  )
                ) : (
                  s.n
                )}
              </div>
              <div
                style={stage > s.n ? delay(i, 70) : undefined}
                className={cn(
                  "h-1 flex-1 rounded",
                  i === steps.length - 1
                    ? "bg-transparent"
                    : stage > s.n
                      ? cn(
                          "track-seg",
                          rejected && s.n + 1 === 4
                            ? "bg-red-400"
                            : nextStyle.seg,
                        )
                      : "bg-gray-200",
                )}
              />
            </div>
            <span
              className={cn(
                "mt-2.5 text-center text-xs font-medium",
                reached
                  ? failNode
                    ? "text-red-600"
                    : style.text
                  : "text-gray-400",
              )}
            >
              {s.label}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
