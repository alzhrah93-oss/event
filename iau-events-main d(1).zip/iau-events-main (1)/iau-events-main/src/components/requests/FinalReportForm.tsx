"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { blockNonNumericKeys } from "@/components/request/inputs";
import { submitFinalReport } from "@/lib/requests/actions";
import { ACCEPTED_FILE_TYPES, MAX_FILE_MB } from "@/lib/requests/options";

const inputCls =
  "w-full rounded-md border border-gray-300 bg-white px-3.5 py-2.5 text-gray-900 outline-none transition-shadow focus:ring-2 focus:ring-iau-green";

function Input({
  label,
  name,
  type = "text",
  required,
  rows,
  min,
  max,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  rows?: number;
  min?: number;
  max?: number;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-1.5 block text-sm font-semibold text-gray-800">
        {label}
        {required && <span className="text-red-500"> *</span>}
      </label>
      {rows ? (
        <textarea id={name} name={name} rows={rows} required={required} className={inputCls} />
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          required={required}
          min={min}
          max={max}
          onKeyDown={type === "number" ? blockNonNumericKeys : undefined}
          inputMode={type === "number" ? "numeric" : undefined}
          dir={type === "number" || type === "date" ? "ltr" : undefined}
          className={inputCls}
        />
      )}
    </div>
  );
}

/**
 * Required choice for the free-text follow-up fields: the organizer must pick
 * "Nothing" (nothing to report) or "Other" and write the answer.
 */
function ChoiceOrText({ label, name }: { label: string; name: string }) {
  const t = useTranslations("myRequests.report");
  const [mode, setMode] = useState<"" | "nothing" | "other">("");

  return (
    <div>
      <p className="mb-1.5 text-sm font-semibold text-gray-800">
        {label}
        <span className="text-red-500"> *</span>
      </p>
      <div className="flex flex-wrap gap-4">
        {(["nothing", "other"] as const).map((m) => (
          <label key={m} className="flex cursor-pointer items-center gap-2 text-sm text-gray-700">
            <input
              type="radio"
              name={`${name}Mode`}
              value={m}
              required
              checked={mode === m}
              onChange={() => setMode(m)}
              className="h-4 w-4 accent-iau-green"
            />
            {m === "nothing" ? t("nothing") : t("other")}
          </label>
        ))}
      </div>
      {mode === "other" && (
        <textarea
          name={name}
          rows={2}
          required
          aria-label={label}
          className={`${inputCls} goal-item mt-2`}
        />
      )}
    </div>
  );
}

type BudgetRow = { item: string; approved: string; spent: string; notes: string };
const EMPTY_ROW: BudgetRow = { item: "", approved: "", spent: "", notes: "" };

export default function FinalReportForm({ requestId }: { requestId: string }) {
  const t = useTranslations("myRequests.report");
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [budget, setBudget] = useState<BudgetRow[]>([]);
  const router = useRouter();

  const setRow = (i: number, patch: Partial<BudgetRow>) =>
    setBudget((rows) => rows.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const variance = (r: BudgetRow) => {
    const a = Number(r.approved);
    const s = Number(r.spent);
    if (!r.approved || !r.spent || !Number.isFinite(a) || !Number.isFinite(s))
      return "—";
    return (a - s).toLocaleString();
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);

    // Evidence attachments are mandatory: the event's report with pictures
    // and media-coverage links. Size-check before uploading (server action
    // requests are capped at ~4MB total).
    const files = fd
      .getAll("evidence")
      .filter((f): f is File => f instanceof File && f.size > 0);
    if (files.length === 0) {
      setError("evidenceRequired");
      return;
    }
    const totalMb = files.reduce((a, f) => a + f.size, 0) / (1024 * 1024);
    if (files.some((f) => f.size > MAX_FILE_MB * 1024 * 1024) || totalMb > 3.5) {
      setError("filesTooLarge");
      return;
    }

    fd.set(
      "actualBudget",
      JSON.stringify(
        budget
          .filter((r) => r.item.trim())
          .map((r) => ({
            item: r.item.trim(),
            approved: Number(r.approved) || 0,
            spent: Number(r.spent) || 0,
            notes: r.notes.trim(),
          })),
      ),
    );
    setError(null);
    startTransition(async () => {
      const res = await submitFinalReport(requestId, fd);
      if (!res.ok) {
        setError("failed");
        return;
      }
      router.push(`/dashboard/requests/${requestId}`);
      router.refresh();
    });
  };

  return (
    <form onSubmit={onSubmit} className="grid gap-5">
      {error && (
        <p role="alert" className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-700">
          {t(error as "failed" | "evidenceRequired" | "filesTooLarge")}
        </p>
      )}
      <Input label={t("summary")} name="summary" rows={5} required />
      <div className="grid gap-5 sm:grid-cols-2">
        <Input label={t("actualDate")} name="actualDate" type="date" required />
        <Input label={t("actualLocation")} name="actualLocation" required />
        <Input label={t("actualAttendance")} name="actualAttendance" type="number" min={0} required />
        <Input label={t("studentCount")} name="studentCount" type="number" min={0} required />
        <Input label={t("ideasReceived")} name="ideasReceived" type="number" min={0} required />
        <Input label={t("projectsNominated")} name="projectsNominated" type="number" min={0} required />
      </div>
      <ChoiceOrText label={t("projectsNominatedDesc")} name="projectsNominatedDesc" />
      <ChoiceOrText label={t("partnerships")} name="partnerships" />
      <div className="grid gap-5 sm:grid-cols-2">
        <Input
          label={t("satisfactionPct")}
          name="satisfactionPct"
          type="number"
          min={0}
          max={100}
          required
        />
      </div>

      {/* Actual budget table — approved vs spent with computed variance */}
      <div className="rounded-lg border border-iau-green-light bg-iau-green-light/30 p-4">
        <p className="text-sm font-semibold text-gray-800">{t("budgetTitle")}</p>
        <p className="mb-3 mt-0.5 text-xs text-gray-500">{t("budgetHint")}</p>
        <div className="grid gap-3">
          {budget.map((r, i) => (
            <div
              key={i}
              className="goal-item grid gap-3 rounded-md bg-white p-4 sm:grid-cols-2"
            >
              <div>
                <label htmlFor={`b-item-${i}`} className="mb-1.5 block text-sm font-semibold text-gray-800">
                  {t("budgetItem")}
                </label>
                <input
                  id={`b-item-${i}`}
                  value={r.item}
                  onChange={(e) => setRow(i, { item: e.target.value })}
                  className={inputCls}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor={`b-approved-${i}`} className="mb-1.5 block text-sm font-semibold text-gray-800">
                    {t("budgetApproved")}
                  </label>
                  <input
                    id={`b-approved-${i}`}
                    type="number"
                    min={0}
                    dir="ltr"
                    value={r.approved}
                    onChange={(e) => setRow(i, { approved: e.target.value })}
                    onKeyDown={blockNonNumericKeys}
                    inputMode="numeric"
                    className={inputCls}
                  />
                </div>
                <div>
                  <label htmlFor={`b-spent-${i}`} className="mb-1.5 block text-sm font-semibold text-gray-800">
                    {t("budgetSpent")}
                  </label>
                  <input
                    id={`b-spent-${i}`}
                    type="number"
                    min={0}
                    dir="ltr"
                    value={r.spent}
                    onChange={(e) => setRow(i, { spent: e.target.value })}
                    onKeyDown={blockNonNumericKeys}
                    inputMode="numeric"
                    className={inputCls}
                  />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label htmlFor={`b-notes-${i}`} className="mb-1.5 block text-sm font-semibold text-gray-800">
                  {t("budgetNotes")}
                </label>
                <input
                  id={`b-notes-${i}`}
                  value={r.notes}
                  onChange={(e) => setRow(i, { notes: e.target.value })}
                  className={inputCls}
                />
              </div>
              <div className="flex items-center justify-between sm:col-span-2">
                <p className="text-sm text-gray-600">
                  {t("budgetVariance")}:{" "}
                  <span className="font-semibold text-iau-green" dir="ltr">
                    {variance(r)}
                  </span>
                </p>
                <button
                  type="button"
                  onClick={() => setBudget((rows) => rows.filter((_, j) => j !== i))}
                  className="press text-sm font-semibold text-red-600 hover:underline"
                >
                  {t("budgetRemoveRow")}
                </button>
              </div>
            </div>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setBudget((rows) => [...rows, { ...EMPTY_ROW }])}
          className="press mt-3 w-fit rounded-md border border-iau-green px-4 py-2 text-sm font-semibold text-iau-green transition-colors hover:bg-iau-green-light"
        >
          + {t("budgetAddRow")}
        </button>
      </div>

      <div>
        <label htmlFor="evidence" className="mb-1.5 block text-sm font-semibold text-gray-800">
          {t("evidence")}
          <span className="text-red-500"> *</span>
        </label>
        <p className="mb-2 text-xs font-medium text-amber-700">
          {t("evidenceHint")}
        </p>
        <input
          id="evidence"
          name="evidence"
          type="file"
          multiple
          required
          accept={ACCEPTED_FILE_TYPES}
          className="block w-full text-sm text-gray-600 file:me-4 file:rounded-md file:border-0 file:bg-iau-green file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-iau-green-dark"
        />
      </div>

      <button
        type="submit"
        disabled={pending}
        className="press w-fit rounded-md bg-iau-gold px-8 py-3 font-semibold text-white transition-colors hover:bg-iau-gold/90 disabled:opacity-60"
      >
        {pending ? t("submitting") : t("submit")}
      </button>
    </form>
  );
}
