"use client";

import { useEffect, useRef, useState } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { cn } from "@/lib/utils";

/**
 * Inline header search: the magnifier icon expands a compact input right
 * beside it (the surrounding flex row makes room — no dropdown panel).
 * Enter or the gold icon submits to /search?q=…; Escape or clicking
 * elsewhere collapses it. Open/close state lives in SiteHeader so it can
 * tuck the logo/name away while the input is open.
 */
export default function HeaderSearch({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const t = useTranslations("common");
  const [q, setQ] = useState("");
  const rootRef = useRef<HTMLFormElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) onOpenChange(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open, onOpenChange]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    if (!query) {
      inputRef.current?.focus();
      return;
    }
    onOpenChange(false);
    setQ("");
    router.push(`/search?q=${encodeURIComponent(query)}`);
  };

  return (
    <form
      ref={rootRef}
      role="search"
      onSubmit={submit}
      className="flex items-center"
    >
      {/* Mounted only while open: a compact fixed-width input beside the
          icon — the header row makes room because the logo tucks away. */}
      {open && (
        <input
          ref={inputRef}
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t("searchPlaceholder")}
          aria-label={t("search")}
          style={{ width: "min(11rem, 45vw)" }}
          className="menu-in h-9 rounded-s-md bg-white/95 px-3 text-sm text-gray-800 outline-none placeholder:text-gray-500"
        />
      )}
      <button
        type={open ? "submit" : "button"}
        onClick={open ? undefined : () => onOpenChange(true)}
        aria-label={t("search")}
        aria-expanded={open}
        className={cn(
          "press p-2 text-white transition-colors",
          open
            ? "h-9 rounded-e-md bg-iau-gold hover:bg-iau-gold/90"
            : "rounded hover:bg-white/15",
        )}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-4.35-4.35" />
        </svg>
      </button>
    </form>
  );
}
