import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";

export default function SiteFooter() {
  const t = useTranslations("footer");
  const tn = useTranslations("nav");
  const tc = useTranslations("common");
  const year = new Date().getFullYear();

  return (
    <footer className="bg-iau-green-bright text-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-3">
        <div>
          <h3 className="mb-3 border-b border-iau-gold pb-2 text-base font-bold">
            {t("about")}
          </h3>
          <p className="text-sm leading-6 opacity-90">{t("aboutText")}</p>
        </div>
        <div>
          <h3 className="mb-3 border-b border-iau-gold pb-2 text-base font-bold">
            {t("quickLinks")}
          </h3>
          <ul className="space-y-2 text-sm">
            <li>
              <Link className="hover:text-iau-gold" href="/">
                {tn("home")}
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="mb-3 border-b border-iau-gold pb-2 text-base font-bold">
            {t("contact")}
          </h3>
          <ul className="space-y-2 text-sm opacity-90">
            <li>{tc("university")}</li>
            <li>{t("location")}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/15">
        <p className="mx-auto max-w-7xl px-4 py-4 text-center text-xs opacity-80">
          {t("copyright", { year })} — {t("rights")}
        </p>
      </div>
    </footer>
  );
}
