"use client";

import { useLocale, useTranslations } from "next-intl";
import { usePathname, useRouter } from "@/i18n/navigation";

export default function LanguageSwitcher() {
  const locale = useLocale();
  const pathname = usePathname();
  const router = useRouter();
  const t = useTranslations("common");

  const toggle = () => {
    router.replace(pathname, { locale: locale === "en" ? "ar" : "en" });
  };

  return (
    <button
      type="button"
      onClick={toggle}
      className="rounded px-2 py-1 text-sm font-semibold text-white transition-colors hover:bg-white/20"
    >
      {t("language")}
    </button>
  );
}
