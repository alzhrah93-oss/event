"use client";

import { useState } from "react";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";
import { signOut } from "@/lib/auth/actions";
import { cn } from "@/lib/utils";
import HeaderSearch from "./HeaderSearch";
import LanguageSwitcher from "./LanguageSwitcher";
import NotificationsBell from "./NotificationsBell";

const PUBLIC_ITEMS = [
  { key: "home", href: "/" },
  { key: "login", href: "/login" },
  { key: "strategicPlan", href: "/strategic-plan" },
  { key: "requirements", href: "/requirements" },
  { key: "calendar", href: "/calendar" },
  { key: "about", href: "/about" },
] as const;

const USER_ITEMS = [
  { key: "home", href: "/" },
  { key: "strategicPlan", href: "/strategic-plan" },
  { key: "requirements", href: "/requirements" },
  { key: "calendar", href: "/calendar" },
  { key: "about", href: "/about" },
] as const;

export type HeaderUser = {
  name: string;
  dashboardHref: "/dashboard" | "/admin" | "/entity";
};

export default function SiteHeader({ user }: { user: HeaderUser | null }) {
  const t = useTranslations("nav");
  const tc = useTranslations("common");
  const ta = useTranslations("auth");
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const NAV_ITEMS = user ? USER_ITEMS : PUBLIC_ITEMS;

  return (
    <header className="sticky top-0 z-50 shadow">
      {/* One single-line bar: logo, then the nav right beside it, search +
          language at the end. Compact wordmark (no institute-name text) so
          everything fits side by side on one row. */}
      <div className="bg-iau-green">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-4 sm:py-5">
          <Link
            href="/"
            className={cn(
              "flex shrink-0 items-center text-white",
              // While the search input is open it borrows the logo's room —
              // the row has no other free space with the full nav visible.
              searchOpen && "hidden",
            )}
          >
            {/* Full IAU wordmark (wide lockup) rendered white on the green bar */}
            <Image
              src="/images/big_iau_Logo.svg"
              alt="IAU"
              width={230}
              height={44}
              priority
              className="h-9 w-auto shrink-0 brightness-0 invert sm:h-11"
            />
          </Link>

          {/* Desktop nav — sits directly beside the logo */}
          <nav className="hidden min-w-0 items-center gap-1 xl:flex">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.key}
                href={item.href}
                data-active={pathname === item.href}
                className={cn(
                  "nav-underline whitespace-nowrap rounded px-2 py-2 text-sm font-medium text-white transition-colors hover:bg-white/10",
                  pathname === item.href && "bg-white/15",
                )}
              >
                {t(item.key)}
              </Link>
            ))}
            {user && (
              <>
                <NotificationsBell />
                <Link
                  href={user.dashboardHref}
                  className={cn(
                    "whitespace-nowrap rounded bg-iau-gold/90 px-2.5 py-2 text-sm font-semibold text-white transition-colors hover:bg-iau-gold",
                    pathname.startsWith(user.dashboardHref) && "bg-iau-gold",
                  )}
                >
                  {t("dashboard")}
                </Link>
                <form action={signOut}>
                  <button
                    type="submit"
                    className="press whitespace-nowrap rounded px-2.5 py-2 text-sm font-medium text-white/85 hover:bg-white/15"
                  >
                    {ta("logout")}
                  </button>
                </form>
              </>
            )}
          </nav>

          {/* Right cluster: inline search + language switch (+ hamburger on mobile) */}
          <div
            className={cn(
              "ms-auto flex shrink-0 items-center gap-1",
              searchOpen && "min-w-0 flex-1 justify-end",
            )}
          >
            <HeaderSearch open={searchOpen} onOpenChange={setSearchOpen} />
            <LanguageSwitcher />

            {/* Mobile hamburger */}
            <button
              type="button"
              className="p-1 text-white xl:hidden"
              aria-label={tc("menu")}
              aria-expanded={open}
              onClick={() => setOpen(!open)}
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                {open ? (
                  <path d="M6 6l12 12M18 6L6 18" />
                ) : (
                  <path d="M3 6h18M3 12h18M3 18h18" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {open && (
          <nav className="menu-in border-t border-white/20 xl:hidden">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.key}
                href={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "block px-6 py-3 text-sm font-medium text-white hover:bg-white/15",
                  pathname === item.href && "bg-white/20",
                )}
              >
                {t(item.key)}
              </Link>
            ))}
            {user && (
              <>
                <Link
                  href={user.dashboardHref}
                  onClick={() => setOpen(false)}
                  className="block px-6 py-3 text-sm font-semibold text-iau-gold hover:bg-white/15"
                >
                  {t("dashboard")}
                </Link>
                <form action={signOut}>
                  <button
                    type="submit"
                    className="block w-full px-6 py-3 text-start text-sm font-medium text-white/85 hover:bg-white/15"
                  >
                    {ta("logout")}
                  </button>
                </form>
              </>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
