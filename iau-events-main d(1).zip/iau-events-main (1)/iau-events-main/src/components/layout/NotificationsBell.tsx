"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

type Notification = {
  id: string;
  type: string;
  data: { requestNumber?: string; title?: string; reason?: string };
  read: boolean;
  created_at: string;
};

export default function NotificationsBell() {
  const t = useTranslations("notifications");
  const locale = useLocale();
  const [items, setItems] = useState<Notification[]>([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    const supabase = createClient();
    const [{ data }, { count }] = await Promise.all([
      supabase
        .from("notifications")
        .select("id, type, data, read, created_at")
        .order("created_at", { ascending: false })
        .limit(15),
      supabase
        .from("notifications")
        .select("id", { count: "exact", head: true })
        .eq("read", false),
    ]);
    setItems((data as Notification[]) ?? []);
    setUnread(count ?? 0);
  }, []);

  useEffect(() => {
    // async fetch — state lands after the network round-trip, not synchronously
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load();
  }, [load]);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (!panelRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const toggle = async () => {
    const next = !open;
    setOpen(next);
    if (next && unread > 0) {
      const supabase = createClient();
      await supabase
        .from("notifications")
        .update({ read: true })
        .eq("read", false);
      setItems((xs) => xs.map((n) => ({ ...n, read: true })));
      setUnread(0);
    }
  };

  const message = (n: Notification) =>
    t(`types.${n.type}` as Parameters<typeof t>[0], {
      number: n.data.requestNumber ?? "",
      reason: n.data.reason ?? "",
    });

  const fmt = new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div ref={panelRef} className="relative">
      <button
        type="button"
        onClick={toggle}
        aria-label={t("bell")}
        aria-expanded={open}
        className="press relative rounded-md p-2 text-white transition-colors hover:bg-white/15"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
          <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.7 21a2 2 0 0 1-3.4 0" />
        </svg>
        {unread > 0 && (
          <span
            aria-label={t("unread", { count: unread })}
            className="goal-item absolute -end-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-iau-gold px-1 text-[10px] font-bold text-white"
          >
            {unread}
          </span>
        )}
      </button>

      {open && (
        <div className="menu-in absolute end-0 top-full z-50 mt-2 w-80 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-lg">
          <p className="border-b border-gray-100 px-4 py-2.5 text-sm font-bold text-iau-green">
            {t("bell")}
          </p>
          {items.length === 0 ? (
            <p className="px-4 py-6 text-center text-sm text-gray-500">
              {t("empty")}
            </p>
          ) : (
            <ul className="max-h-80 overflow-y-auto">
              {items.map((n) => (
                <li
                  key={n.id}
                  className={cn(
                    "border-b border-gray-50 px-4 py-3 text-sm leading-6 last:border-0",
                    n.read ? "text-gray-600" : "bg-iau-green-light/40 text-gray-800",
                  )}
                >
                  {message(n)}
                  <span className="mt-0.5 block text-xs text-gray-400">
                    {fmt.format(new Date(n.created_at))}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
