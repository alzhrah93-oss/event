"use client";

import { useMemo, useRef, useState, useTransition } from "react";
import { useLocale, useTranslations } from "next-intl";
import { downloadAnalyticsPdf } from "./export-pdf";
import FiltersBar from "./FiltersBar";
import {
  DecisionBars,
  GroupedBars,
  MonthBars,
  RankBars,
} from "./Charts";
import { FOCUS_AREAS, GRAND_CHALLENGES } from "@/lib/content";
import {
  applyFilters,
  attendanceOf,
  EMPTY_FILTERS,
  type AnalyticsRow,
  type EventFilters,
} from "@/lib/analytics/filters";
import { rankBy, reportCompliance } from "@/lib/analytics/aggregate";
import { optionLabel } from "@/lib/requests/display";
import {
  ACTIVITY_FORMATS,
  ORGANIZING_ENTITIES,
  REQUEST_TYPES,
  VENUES,
} from "@/lib/requests/options";
import type { RequestStatus } from "@/lib/requests/status";

type Loc = "en" | "ar";

/** One accessible hue per chart so the dashboard reads at a glance. */
const CHART_COLORS = {
  eventsPerMonth: "#1b8354", // brand green
  requestsPerMonth: "#4f46e5", // indigo
  byEntity: "#0e7490", // cyan
  byStatus: "#7c3aed", // violet
  byType: "#b45309", // amber
  byFormat: "#be185d", // pink
  byVenue: "#0f766e", // teal
  byFocus: "#a16207", // gold
  byChallenge: "#0369a1", // sky
} as const;


function Tile({
  value,
  label,
  hint,
}: {
  value: string;
  label: string;
  hint?: string;
}) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
      <p className="text-2xl font-bold text-iau-green" dir="ltr">
        {value}
      </p>
      <p className="mt-1 text-sm font-medium text-gray-600">{label}</p>
      {hint && <p className="mt-0.5 text-xs text-gray-400">{hint}</p>}
    </div>
  );
}

function Card({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div
      data-pdf-block
      className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm print:break-inside-avoid"
    >
      <h2 className="mb-4 text-base font-bold text-iau-green">{title}</h2>
      {children}
    </div>
  );
}

export default function AnalyticsExplorer({ rows }: { rows: AnalyticsRow[] }) {
  const t = useTranslations("analytics");
  const ts = useTranslations("status");
  const locale = useLocale() as Loc;
  const [filters, setFilters] = useState<EventFilters>(EMPTY_FILTERS);
  const resultsRef = useRef<HTMLDivElement>(null);
  const [exporting, startExport] = useTransition();

  const exportPdf = () =>
    startExport(async () => {
      if (!resultsRef.current) return;
      await downloadAnalyticsPdf(
        resultsRef.current,
        `iau-analytics-${new Date().toISOString().slice(0, 10)}.pdf`,
      );
    });

  const filtered = useMemo(() => applyFilters(rows, filters), [rows, filters]);

  const monthName = (i: number) =>
    new Intl.DateTimeFormat(locale === "ar" ? "ar" : "en", { month: "short" })
      .format(new Date(2026, i, 1));

  const stats = useMemo(() => {
    const events = filtered.filter(
      (r) => r.status === "approved" || r.status === "closed",
    );
    const decided = filtered.filter((r) =>
      ["approved", "closed", "not_approved"].includes(r.status),
    );
    const approved = decided.filter((r) => r.status !== "not_approved").length;
    const withReports = filtered.filter((r) => r.has_report);
    const totalAttendance = events.reduce((a, r) => a + attendanceOf(r), 0);

    // Monthly series
    const byMonth = (
      pick: (r: AnalyticsRow) => string | null,
      subset: AnalyticsRow[],
    ) => {
      const out = Array(12).fill(0) as number[];
      for (const r of subset) {
        const d = pick(r);
        if (d) out[Number(d.slice(5, 7)) - 1]++;
      }
      return out.map((value, i) => ({ label: monthName(i), value }));
    };
    const eventsPerMonth = byMonth((r) => r.activity_date, events);
    const requestsPerMonth = byMonth((r) => r.submitted_at, filtered);

    const decisions = Array.from({ length: 12 }, (_, i) => ({
      label: monthName(i),
      approved: 0,
      notApproved: 0,
    }));
    for (const r of filtered) {
      if (!r.decided_at) continue;
      const m = Number(r.decided_at.slice(5, 7)) - 1;
      if (r.status === "approved" || r.status === "closed")
        decisions[m].approved++;
      else if (r.status === "not_approved") decisions[m].notApproved++;
    }

    const attendance = Array.from({ length: 12 }, (_, i) => ({
      label: monthName(i),
      a: 0,
      b: 0,
    }));
    for (const r of events) {
      const m = Number(r.activity_date.slice(5, 7)) - 1;
      attendance[m].a += r.expected_attendance;
      attendance[m].b += r.actual_attendance ?? 0;
    }

    const ranked = (fn: (r: AnalyticsRow) => string, subset: AnalyticsRow[], list?: typeof VENUES) =>
      rankBy(subset, fn).map((e) => ({
        label: list ? optionLabel(list, e.key, locale) : e.key,
        value: e.count,
      }));

    const byFocus = rankBy(
      filtered.flatMap((r) => r.focus_areas.map((fa) => ({ fa }))),
      (x) => x.fa,
    ).map((f) => ({
      label: FOCUS_AREAS.find((fa) => fa.id === f.key)?.name[locale] ?? f.key,
      value: f.count,
    }));

    const byType = rankBy(
      filtered.flatMap((r) => r.request_types.map((ty) => ({ ty }))),
      (x) => x.ty,
    ).map((e) => ({
      label: optionLabel(REQUEST_TYPES, e.key, locale),
      value: e.count,
    }));

    const byChallenge = rankBy(
      filtered.flatMap((r) => r.grand_challenges.map((gc) => ({ gc }))),
      (x) => x.gc,
    ).map((e) => ({
      label:
        GRAND_CHALLENGES.find((gc) => gc.id === e.key)?.short[locale] ?? e.key,
      value: e.count,
    }));

    return {
      requests: filtered.length,
      events: events.length,
      approvalRate:
        decided.length === 0 ? 100 : Math.round((approved / decided.length) * 100),
      compliance: reportCompliance(filtered),
      totalAttendance,
      students: withReports.reduce((a, r) => a + (r.student_count ?? 0), 0),
      ideas: withReports.reduce((a, r) => a + (r.ideas_received ?? 0), 0),
      projects: withReports.reduce((a, r) => a + (r.projects_nominated ?? 0), 0),
      eventsPerMonth,
      requestsPerMonth,
      decisions,
      attendance,
      byEntity: ranked((r) => r.organizing_entity, events, ORGANIZING_ENTITIES),
      byStatus: rankBy(filtered, (r) => r.status).map((s) => ({
        label: ts(s.key as RequestStatus),
        value: s.count,
      })),
      byFormat: ranked((r) => r.activity_format, events, ACTIVITY_FORMATS),
      byVenue: ranked((r) => r.venue, events, VENUES),
      byFocus,
      byType,
      byChallenge,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtered, locale]);

  return (
    <div className="grid gap-6">
      {/* Toolbar — direct PDF file download (Excel export lives on /admin/data) */}
      <div className="flex flex-wrap justify-end gap-3 print:hidden">
        <button
          type="button"
          onClick={exportPdf}
          disabled={exporting || stats.requests === 0}
          className="press inline-flex items-center gap-2 rounded-md bg-iau-green px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-60"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
            <path d="M12 3v12M7 10l5 5 5-5" />
            <path d="M4 19h16" />
          </svg>
          {exporting ? t("exporting") : t("downloadPdf")}
        </button>
      </div>

      <FiltersBar
        rows={rows}
        filters={filters}
        setFilters={setFilters}
        matching={stats.requests}
      />

      {stats.requests === 0 ? (
        <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
          {t("empty")}
        </p>
      ) : (
        <div ref={resultsRef} className="grid gap-6">
          {/* Stat tiles */}
          <div
            key={JSON.stringify(filters)}
            data-pdf-block
            className="grid gap-4 sm:grid-cols-3 lg:grid-cols-5"
          >
            <Tile value={String(stats.requests)} label={t("tiles.requests")} />
            <Tile value={String(stats.events)} label={t("tiles.events")} />
            <Tile value={`${stats.approvalRate}%`} label={t("tiles.approvalRate")} />
            <Tile
              value={`${stats.compliance.rate}%`}
              label={t("tiles.compliance")}
              hint={`${stats.compliance.submitted}/${stats.compliance.due}`}
            />
            <Tile
              value={stats.totalAttendance.toLocaleString()}
              label={t("tiles.totalAttendance")}
              hint={t("tiles.attendanceHint")}
            />
            <Tile
              value={String(stats.students)}
              label={t("tiles.students")}
              hint={t("tiles.reportsHint")}
            />
            <Tile
              value={String(stats.ideas)}
              label={t("tiles.ideas")}
              hint={t("tiles.reportsHint")}
            />
            <Tile
              value={String(stats.projects)}
              label={t("tiles.projects")}
              hint={t("tiles.reportsHint")}
            />
          </div>

          {/* Time charts */}
          <div className="grid gap-6 lg:grid-cols-2">
            <Card title={t("charts.eventsPerMonth")}>
              <MonthBars
                data={stats.eventsPerMonth}
                valueName={t("charts.count")}
                color={CHART_COLORS.eventsPerMonth}
              />
            </Card>
            <Card title={t("charts.requestsPerMonth")}>
              <MonthBars
                data={stats.requestsPerMonth}
                valueName={t("charts.count")}
                color={CHART_COLORS.requestsPerMonth}
              />
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card title={t("charts.decisions")}>
              <DecisionBars
                data={stats.decisions}
                approvedName={t("charts.approved")}
                notApprovedName={t("charts.notApproved")}
              />
            </Card>
            <Card title={t("charts.attendance")}>
              <GroupedBars
                data={stats.attendance}
                aName={t("charts.expected")}
                bName={t("charts.actual")}
              />
            </Card>
          </div>

          {/* Rankings */}
          <div className="grid gap-6 lg:grid-cols-2">
            <Card title={t("charts.byEntity")}>
              <RankBars data={stats.byEntity} valueName={t("charts.count")} color={CHART_COLORS.byEntity} />
            </Card>
            <Card title={t("charts.byStatus")}>
              <RankBars data={stats.byStatus} valueName={t("charts.count")} color={CHART_COLORS.byStatus} />
            </Card>
            <Card title={t("charts.byType")}>
              <RankBars data={stats.byType} valueName={t("charts.count")} color={CHART_COLORS.byType} />
            </Card>
            <Card title={t("charts.byFormat")}>
              <RankBars data={stats.byFormat} valueName={t("charts.count")} color={CHART_COLORS.byFormat} />
            </Card>
            <Card title={t("charts.byVenue")}>
              <RankBars data={stats.byVenue} valueName={t("charts.count")} color={CHART_COLORS.byVenue} />
            </Card>
            {stats.byFocus.length > 0 && (
              <Card title={t("charts.byFocus")}>
                <RankBars data={stats.byFocus} valueName={t("charts.count")} color={CHART_COLORS.byFocus} />
              </Card>
            )}
            {stats.byChallenge.length > 0 && (
              <Card title={t("charts.byChallenge")}>
                <RankBars data={stats.byChallenge} valueName={t("charts.count")} color={CHART_COLORS.byChallenge} />
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
