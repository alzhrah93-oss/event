import { jsPDF } from "jspdf";
import { toPng } from "html-to-image";

/**
 * Build and download the analytics report as a real PDF file — no print
 * dialog. Every element marked [data-pdf-block] (stat tiles, each chart
 * card) is rasterized in-browser (so Arabic text and chart SVGs render
 * exactly as on screen) and stacked onto A4 pages, breaking to a new page
 * when a block doesn't fit.
 */
export async function downloadAnalyticsPdf(
  root: HTMLElement,
  fileName: string,
): Promise<void> {
  const blocks = Array.from(
    root.querySelectorAll<HTMLElement>("[data-pdf-block]"),
  );
  if (blocks.length === 0) return;

  const pdf = new jsPDF({ unit: "pt", format: "a4" });
  const margin = 28;
  const pageW = pdf.internal.pageSize.getWidth() - margin * 2;
  const pageH = pdf.internal.pageSize.getHeight() - margin * 2;
  let y = margin;

  for (const el of blocks) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    const png = await toPng(el, {
      pixelRatio: 2,
      backgroundColor: "#ffffff",
      style: { margin: "0" },
    });
    let drawW = pageW;
    let drawH = (rect.height * pageW) / rect.width;
    if (drawH > pageH) {
      // A single oversized block is scaled down to fit one page
      drawW = (drawW * pageH) / drawH;
      drawH = pageH;
    }
    if (y > margin && y + drawH > margin + pageH) {
      pdf.addPage();
      y = margin;
    }
    pdf.addImage(png, "PNG", margin, y, drawW, drawH);
    y += drawH + 14;
  }

  pdf.save(fileName);
}
