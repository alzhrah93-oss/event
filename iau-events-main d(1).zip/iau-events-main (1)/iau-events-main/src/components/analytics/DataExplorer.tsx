"use client";

import { useMemo, useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import FiltersBar from "./FiltersBar";
import { FOCUS_AREAS, GRAND_CHALLENGES } from "@/lib/content";
import {
  applyFilters,
  EMPTY_FILTERS,
  type DataRow,
  type EventFilters,
} from "@/lib/analytics/filters";
import { labelsFor, optionLabel } from "@/lib/requests/display";
import {
  ACTIVITY_FORMATS,
  ALL_ENTITY_DETAILS,
  ORGANIZING_ENTITIES,
  REQUEST_TYPES,
  VENUES,
} from "@/lib/requests/options";
import type { RequestStatus } from "@/lib/requests/status";
import { cn } from "@/lib/utils";

type Loc = "en" | "ar";
type SortDir = "asc" | "desc";

/**
 * Excel-like sheet of every request with its alignment and final-report
 * outputs: the shared analytics filter bar on top, a sortable sticky-header
 * table underneath, and the Excel export alongside. Fully bilingual.
 */
export default function DataExplorer({ rows }: { rows: DataRow[] }) {
  const t = useTranslations("dataPage");
  const ta = useTranslations("analytics");
  const ts = useTranslations("status");
  const locale = useLocale() as Loc;
  const [filters, setFilters] = useState<EventFilters>(EMPTY_FILTERS);
  const [sortKey, setSortKey] = useState<string>("date");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const sep = locale === "ar" ? "، " : ", ";
  const focusLabels = (ids: string[]) =>
    ids
      .map((id) => FOCUS_AREAS.find((f) => f.id === id)?.name[locale] ?? id)
      .join(sep) || "—";
  const challengeLabels = (ids: string[]) =>
    ids
      .map((id) => GRAND_CHALLENGES.find((g) => g.id === id)?.short[locale] ?? id)
      .join(sep) || "—";

  // One definition per column: header label, cell value (display), and the
  // value used for sorting. All columns are sortable.
  const columns = useMemo(
    () =>
      [
        {
          key: "number",
          cell: (r: DataRow) => r.request_number,
          sort: (r: DataRow) => r.request_number,
          ltr: true,
        },
        {
          key: "status",
          cell: (r: DataRow) => ts(r.status as RequestStatus),
          sort: (r: DataRow) => r.status,
        },
        {
          key: "entityType",
          cell: (r: DataRow) =>
            optionLabel(ORGANIZING_ENTITIES, r.organizing_entity, locale),
          sort: (r: DataRow) => r.organizing_entity,
        },
        {
          key: "entityName",
          cell: (r: DataRow) =>
            r.entity_detail
              ? optionLabel(ALL_ENTITY_DETAILS, r.entity_detail, locale)
              : "—",
          sort: (r: DataRow) => r.entity_detail ?? "",
        },
        {
          key: "applicant",
          cell: (r: DataRow) => r.applicant_name,
          sort: (r: DataRow) => r.applicant_name,
        },
        {
          key: "title",
          cell: (r: DataRow) => r.title,
          sort: (r: DataRow) => r.title,
        },
        {
          key: "date",
          cell: (r: DataRow) => r.activity_date,
          sort: (r: DataRow) => r.activity_date,
          ltr: true,
        },
        {
          key: "types",
          cell: (r: DataRow) => labelsFor(REQUEST_TYPES, r.request_types, locale),
          sort: (r: DataRow) => r.request_types.join(","),
        },
        {
          key: "format",
          cell: (r: DataRow) =>
            optionLabel(ACTIVITY_FORMATS, r.activity_format, locale),
          sort: (r: DataRow) => r.activity_format,
        },
        {
          key: "venue",
          cell: (r: DataRow) => optionLabel(VENUES, r.venue, locale),
          sort: (r: DataRow) => r.venue,
        },
        {
          key: "expected",
          cell: (r: DataRow) => String(r.expected_attendance),
          sort: (r: DataRow) => r.expected_attendance,
          ltr: true,
        },
        {
          key: "focus",
          cell: (r: DataRow) => focusLabels(r.focus_areas),
          sort: (r: DataRow) => r.focus_areas.join(","),
        },
        {
          key: "challenges",
          cell: (r: DataRow) => challengeLabels(r.grand_challenges),
          sort: (r: DataRow) => r.grand_challenges.join(","),
        },
        {
          key: "report",
          cell: (r: DataRow) => (r.has_report ? t("reportYes") : t("reportNo")),
          sort: (r: DataRow) => (r.has_report ? 1 : 0),
        },
        {
          key: "actual",
          cell: (r: DataRow) =>
            r.actual_attendance === null ? "—" : String(r.actual_attendance),
          sort: (r: DataRow) => r.actual_attendance ?? -1,
          ltr: true,
        },
        {
          key: "students",
          cell: (r: DataRow) =>
            r.student_count === null ? "—" : String(r.student_count),
          sort: (r: DataRow) => r.student_count ?? -1,
          ltr: true,
        },
        {
          key: "ideas",
          cell: (r: DataRow) =>
            r.ideas_received === null ? "—" : String(r.ideas_received),
          sort: (r: DataRow) => r.ideas_received ?? -1,
          ltr: true,
        },
        {
          key: "projects",
          cell: (r: DataRow) =>
            r.projects_nominated === null ? "—" : String(r.projects_nominated),
          sort: (r: DataRow) => r.projects_nominated ?? -1,
          ltr: true,
        },
      ] as const,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [locale, t, ts],
  );

  const filtered = useMemo(
    () => applyFilters(rows, filters) as DataRow[],
    [rows, filters],
  );

  const sorted = useMemo(() => {
    const col = columns.find((c) => c.key === sortKey) ?? columns[6];
    const dir = sortDir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      const va = col.sort(a);
      const vb = col.sort(b);
      if (typeof va === "number" && typeof vb === "number")
        return (va - vb) * dir;
      return String(va).localeCompare(String(vb)) * dir;
    });
  }, [filtered, columns, sortKey, sortDir]);

  const toggleSort = (key: string) => {
    if (key === sortKey) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  return (
    // grid-cols-1 = minmax(0,1fr): caps the track at the container width so
    // the wide table can never stretch the page — it scrolls in its card.
    <div className="grid grid-cols-1 gap-6">
      {/* Toolbar — the full-data Excel export lives here */}
      <div className="flex flex-wrap justify-end gap-3">
        <a
          href="/api/admin/export"
          download
          className="press inline-flex items-center gap-2 rounded-md bg-iau-green px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <path d="M3 9h18M9 3v18" />
          </svg>
          {t("openExcel")}
        </a>
      </div>

      <FiltersBar
        rows={rows}
        filters={filters}
        setFilters={setFilters}
        matching={filtered.length}
      />

      {sorted.length === 0 ? (
        <p className="rounded-xl border border-gray-200 bg-white p-10 text-center text-gray-500">
          {ta("empty")}
        </p>
      ) : (
        /* min-w-0 + the grid's minmax(0,1fr) track let this card shrink below
           the table's intrinsic width — otherwise the 1700px table blows the
           whole page out sideways and breaks the header/footer layout. */
        <div className="min-w-0 max-w-full overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
          <p className="border-b border-gray-100 px-4 py-3 text-xs text-gray-500">
            {t("sortHint")}
          </p>
          {/* The sheet scrolls inside its own container — the page never does */}
          <div className="max-h-[70vh] overflow-auto">
            <table className="w-full min-w-[1700px] text-sm">
              <thead className="sticky top-0 z-10">
                <tr className="bg-iau-section text-xs uppercase tracking-wide text-gray-600">
                  {columns.map((c) => {
                    const active = sortKey === c.key;
                    return (
                      <th
                        key={c.key}
                        scope="col"
                        aria-sort={
                          active
                            ? sortDir === "asc"
                              ? "ascending"
                              : "descending"
                            : undefined
                        }
                        className="border-b border-gray-200 p-0 text-start"
                      >
                        <button
                          type="button"
                          onClick={() => toggleSort(c.key)}
                          className={cn(
                            "flex w-full items-center gap-1 px-3 py-3 text-start font-bold transition-colors hover:bg-iau-green-light hover:text-iau-green",
                            active && "text-iau-green",
                          )}
                        >
                          {t(`columns.${c.key}` as Parameters<typeof t>[0])}
                          <span aria-hidden className="text-[10px]">
                            {active ? (sortDir === "asc" ? "▲" : "▼") : "↕"}
                          </span>
                        </button>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {sorted.map((r, i) => (
                  <tr
                    key={r.id}
                    className={cn(
                      "border-b border-gray-100 transition-colors last:border-0 hover:bg-iau-green-light/30",
                      i % 2 === 1 && "bg-iau-section/60",
                    )}
                  >
                    {columns.map((c) => (
                      <td
                        key={c.key}
                        dir={"ltr" in c && c.ltr ? "ltr" : undefined}
                        className={cn(
                          "max-w-72 truncate px-3 py-2.5 text-gray-700",
                          c.key === "number" && "font-semibold text-iau-green",
                        )}
                        title={c.cell(r)}
                      >
                        {c.cell(r)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
