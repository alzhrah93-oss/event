"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

/**
 * Chart palette validated with the dataviz skill's validator (light surface):
 * single-series green #1B8354; status pair green/#DC2626 (ΔE 15.7 protan).
 * Marks: thin bars, 4px rounded data ends, recessive grid, tooltips everywhere.
 */
const GREEN = "#1b8354";
const RED = "#dc2626";
const GRID = "#f3f4f6";
const INK_MUTED = "#6b7280";

const tooltipStyle = {
  borderRadius: 8,
  border: "1px solid #e5e7eb",
  boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  fontSize: 13,
};

export type MonthDatum = { label: string; value: number };

export function MonthBars({
  data,
  valueName,
  color = GREEN,
}: {
  data: MonthDatum[];
  valueName: string;
  color?: string;
}) {
  return (
    <div dir="ltr" className="h-64 w-full">
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke={GRID} />
          <XAxis
            dataKey="label"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <YAxis
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(27,131,84,0.06)" }} />
          <Bar
            dataKey="value"
            name={valueName}
            fill={color}
            radius={[4, 4, 0, 0]}
            maxBarSize={26}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export type DecisionDatum = {
  label: string;
  approved: number;
  notApproved: number;
};

export function DecisionBars({
  data,
  approvedName,
  notApprovedName,
}: {
  data: DecisionDatum[];
  approvedName: string;
  notApprovedName: string;
}) {
  return (
    <div dir="ltr" className="h-64 w-full">
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }} barGap={2}>
          <CartesianGrid vertical={false} stroke={GRID} />
          <XAxis
            dataKey="label"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <YAxis
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(27,131,84,0.06)" }} />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" iconSize={9} />
          <Bar
            dataKey="approved"
            name={approvedName}
            fill={GREEN}
            radius={[4, 4, 0, 0]}
            maxBarSize={18}
          />
          <Bar
            dataKey="notApproved"
            name={notApprovedName}
            fill={RED}
            radius={[4, 4, 0, 0]}
            maxBarSize={18}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export type PairDatum = { label: string; a: number; b: number };

/**
 * Generic two-series grouped bars (validated pair: green #1B8354 + indigo
 * #4F46E5, ΔE 95.8 deutan). Used for expected vs actual attendance.
 */
export function GroupedBars({
  data,
  aName,
  bName,
}: {
  data: PairDatum[];
  aName: string;
  bName: string;
}) {
  return (
    <div dir="ltr" className="h-64 w-full">
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }} barGap={2}>
          <CartesianGrid vertical={false} stroke={GRID} />
          <XAxis
            dataKey="label"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <YAxis
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(27,131,84,0.06)" }} />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" iconSize={9} />
          <Bar dataKey="a" name={aName} fill={GREEN} radius={[4, 4, 0, 0]} maxBarSize={18} />
          <Bar dataKey="b" name={bName} fill="#4f46e5" radius={[4, 4, 0, 0]} maxBarSize={18} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export type RankDatum = { label: string; value: number };

export function RankBars({
  data,
  valueName,
  color = GREEN,
}: {
  data: RankDatum[];
  valueName: string;
  color?: string;
}) {
  const height = Math.max(160, data.length * 44);
  return (
    <div dir="ltr" className="w-full" style={{ height }}>
      <ResponsiveContainer>
        <BarChart
          data={data}
          layout="vertical"
          margin={{ top: 4, right: 24, left: 8, bottom: 0 }}
        >
          <CartesianGrid horizontal={false} stroke={GRID} />
          <XAxis
            type="number"
            allowDecimals={false}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: INK_MUTED }}
          />
          <YAxis
            type="category"
            dataKey="label"
            width={150}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 12, fill: "#374151" }}
          />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(27,131,84,0.06)" }} />
          <Bar
            dataKey="value"
            name={valueName}
            fill={color}
            radius={[0, 4, 4, 0]}
            maxBarSize={20}
            label={{ position: "right", fontSize: 12, fill: INK_MUTED }}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
