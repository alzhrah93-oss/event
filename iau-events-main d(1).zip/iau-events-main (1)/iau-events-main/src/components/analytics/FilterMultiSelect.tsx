"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useTranslations } from "next-intl";
import { cn } from "@/lib/utils";

/**
 * Multi-select filter dropdown: a select-like trigger opening a checkbox
 * list. Empty selection means "All"; any combination of values can be
 * checked (e.g. focus area Health + Energy). Values are generic strings —
 * callers pass localized labels.
 */
export default function FilterMultiSelect({
  label,
  values,
  onChange,
  options,
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
  options: { value: string; label: string }[];
}) {
  const t = useTranslations("analytics");
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const listId = useId();
  const triggerId = useId();

  // Close on outside click / Escape
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const toggle = (v: string) =>
    onChange(
      values.includes(v) ? values.filter((x) => x !== v) : [...values, v],
    );

  const summary =
    values.length === 0
      ? t("all")
      : values.length === 1
        ? (options.find((o) => o.value === values[0])?.label ?? values[0])
        : t("selectedCount", { count: values.length });

  return (
    <div ref={rootRef} className={cn("relative", open && "z-30")}>
      <label
        htmlFor={triggerId}
        className="mb-1 block text-xs font-bold uppercase tracking-wide text-iau-green"
      >
        {label}
      </label>
      <button
        id={triggerId}
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={listId}
        className={cn(
          "flex w-full cursor-pointer items-center justify-between gap-2 rounded-md border bg-white px-3 py-2 text-start text-sm text-gray-800 outline-none transition-shadow focus:ring-2 focus:ring-iau-green",
          values.length > 0
            ? "border-iau-green bg-iau-green-light/40 font-semibold"
            : "border-gray-300",
        )}
      >
        <span className="truncate">{summary}</span>
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          aria-hidden
          className={cn(
            "shrink-0 text-gray-400 transition-transform duration-200",
            open && "rotate-180",
          )}
        >
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>

      {open && (
        <div
          id={listId}
          role="listbox"
          aria-multiselectable
          // Tall enough that a 12-item list (months) fits without scrolling —
          // a 256px cap used to cut the list right at August, which read as
          // "August is missing". Longer lists (colleges) still scroll.
          className="goal-item absolute inset-x-0 top-full z-20 mt-1.5 max-h-[min(70vh,26rem)] min-w-full overflow-y-auto rounded-lg border border-gray-200 bg-white p-1.5 shadow-lg"
        >
          {values.length > 0 && (
            <button
              type="button"
              onClick={() => onChange([])}
              className="mb-1 w-full rounded-md border-b border-gray-100 px-3 py-2 text-start text-xs font-semibold text-iau-green hover:bg-iau-section"
            >
              {t("clear")}
            </button>
          )}
          {options.map((o) => {
            const on = values.includes(o.value);
            return (
              <button
                key={o.value}
                type="button"
                role="option"
                aria-selected={on}
                onClick={() => toggle(o.value)}
                className={cn(
                  "flex w-full items-start gap-2.5 rounded-md px-3 py-1.5 text-start text-sm transition-colors",
                  on
                    ? "bg-iau-green-light/60 font-semibold text-iau-green"
                    : "text-gray-700 hover:bg-iau-section",
                )}
              >
                <span
                  aria-hidden
                  className={cn(
                    "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                    on
                      ? "border-iau-green bg-iau-green text-white"
                      : "border-gray-300 bg-white",
                  )}
                >
                  {on && (
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </span>
                <span className="leading-5">{o.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
