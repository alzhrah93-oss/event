"use client";

import { useMemo } from "react";
import { useLocale, useTranslations } from "next-intl";
import FilterMultiSelect from "./FilterMultiSelect";
import { FOCUS_AREAS, GRAND_CHALLENGES } from "@/lib/content";
import type { AnalyticsRow, AttendanceBucket, EventFilters } from "@/lib/analytics/filters";
import { EMPTY_FILTERS } from "@/lib/analytics/filters";
import {
  ACTIVITY_FORMATS,
  CENTERS,
  COLLEGES,
  DEANSHIPS,
  INSTITUTES,
  ORGANIZING_ENTITIES,
  REQUEST_TYPES,
  TARGET_AUDIENCE,
  VENUES,
  type Option,
} from "@/lib/requests/options";
import type { RequestStatus } from "@/lib/requests/status";

type Loc = "en" | "ar";

const BUCKETS: AttendanceBucket[] = ["lt50", "b50_100", "b100_500", "gte500"];
const STATUSES: RequestStatus[] = [
  "entity_review",
  "new",
  "pending_completion",
  "under_review",
  "awaiting_final",
  "approved",
  "not_approved",
  "entity_rejected",
  "cancelled",
  "closed",
];

/**
 * The filter grid shared by the analytics dashboard and the all-the-data
 * sheet. Every dimension is a multi-select offering the FULL catalog of
 * values (choose one, several, or none = all); values combine as OR inside
 * a dimension and AND across dimensions.
 */
export default function FiltersBar({
  rows,
  filters,
  setFilters,
  matching,
}: {
  rows: AnalyticsRow[];
  filters: EventFilters;
  setFilters: React.Dispatch<React.SetStateAction<EventFilters>>;
  matching: number;
}) {
  const t = useTranslations("analytics");
  const ts = useTranslations("status");
  const locale = useLocale() as Loc;

  const set = <K extends keyof EventFilters>(k: K, v: EventFilters[K]) =>
    setFilters((f) => ({ ...f, [k]: v }));

  const opt = (list: Option[]) =>
    list.map((o) => ({ value: o.value, label: o.label[locale] }));

  const monthName = (i: number) =>
    new Intl.DateTimeFormat(locale === "ar" ? "ar" : "en", { month: "short" })
      .format(new Date(2026, i, 1));

  const years = useMemo(() => {
    const fromData = rows.map((r) => Number(r.activity_date.slice(0, 4)));
    const range = Array.from({ length: 2036 - 2026 + 1 }, (_, i) => 2026 + i);
    return [...new Set([...fromData, ...range])].sort((a, b) => a - b);
  }, [rows]);

  const hasFilters = Object.values(filters).some((v) => v.length > 0);

  return (
    <div className="grid gap-4 rounded-xl border border-gray-200 bg-white p-5 shadow-sm print:hidden">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <FilterMultiSelect
          label={t("filters.year")}
          values={filters.year.map(String)}
          onChange={(v) => set("year", v.map(Number))}
          options={years.map((y) => ({ value: String(y), label: String(y) }))}
        />
        <FilterMultiSelect
          label={t("filters.month")}
          values={filters.month.map(String)}
          onChange={(v) => set("month", v.map(Number))}
          options={Array.from({ length: 12 }, (_, i) => ({
            value: String(i + 1),
            label: monthName(i),
          }))}
        />
        <FilterMultiSelect
          label={t("filters.entity")}
          values={filters.entity}
          onChange={(v) => set("entity", v)}
          options={opt(ORGANIZING_ENTITIES)}
        />
        <FilterMultiSelect
          label={t("filters.college")}
          values={filters.college}
          onChange={(v) => set("college", v)}
          options={opt(COLLEGES)}
        />
        <FilterMultiSelect
          label={t("filters.deanship")}
          values={filters.deanship}
          onChange={(v) => set("deanship", v)}
          options={opt(DEANSHIPS)}
        />
        <FilterMultiSelect
          label={t("filters.institute")}
          values={filters.institute}
          onChange={(v) => set("institute", v)}
          options={opt(INSTITUTES)}
        />
        <FilterMultiSelect
          label={t("filters.center")}
          values={filters.center}
          onChange={(v) => set("center", v)}
          options={opt(CENTERS)}
        />
        <FilterMultiSelect
          label={t("filters.outcome")}
          values={filters.status}
          onChange={(v) => set("status", v)}
          options={STATUSES.map((s) => ({ value: s, label: ts(s) }))}
        />
        <FilterMultiSelect
          label={t("filters.attendance")}
          values={filters.attendance}
          onChange={(v) => set("attendance", v as AttendanceBucket[])}
          options={BUCKETS.map((b) => ({
            value: b,
            label: t(`attendanceBuckets.${b}`),
          }))}
        />
        <FilterMultiSelect
          label={t("filters.type")}
          values={filters.type}
          onChange={(v) => set("type", v)}
          options={opt(REQUEST_TYPES)}
        />
        <FilterMultiSelect
          label={t("filters.format")}
          values={filters.format}
          onChange={(v) => set("format", v)}
          options={opt(ACTIVITY_FORMATS)}
        />
        <FilterMultiSelect
          label={t("filters.venue")}
          values={filters.venue}
          onChange={(v) => set("venue", v)}
          options={opt(VENUES)}
        />
        <FilterMultiSelect
          label={t("filters.audience")}
          values={filters.audience}
          onChange={(v) => set("audience", v)}
          options={opt(TARGET_AUDIENCE)}
        />
        <FilterMultiSelect
          label={t("filters.focusArea")}
          values={filters.focusArea}
          onChange={(v) => set("focusArea", v)}
          options={FOCUS_AREAS.map((fa) => ({
            value: fa.id,
            label: fa.name[locale],
          }))}
        />
        <FilterMultiSelect
          label={t("filters.grandChallenge")}
          values={filters.grandChallenge}
          onChange={(v) => set("grandChallenge", v)}
          options={GRAND_CHALLENGES.map((gc) => ({
            value: gc.id,
            label: gc.short[locale],
          }))}
        />
        <FilterMultiSelect
          label={t("filters.report")}
          values={filters.report}
          onChange={(v) => set("report", v as EventFilters["report"])}
          options={[
            { value: "submitted", label: t("reportValues.submitted") },
            { value: "missing", label: t("reportValues.missing") },
          ]}
        />
      </div>
      <div className="flex items-center justify-between border-t border-gray-100 pt-3">
        <p className="text-sm text-gray-500">{t("matching", { count: matching })}</p>
        {hasFilters && (
          <button
            type="button"
            onClick={() => setFilters(EMPTY_FILTERS)}
            className="press text-sm font-semibold text-iau-green hover:underline"
          >
            {t("clear")}
          </button>
        )}
      </div>
    </div>
  );
}
