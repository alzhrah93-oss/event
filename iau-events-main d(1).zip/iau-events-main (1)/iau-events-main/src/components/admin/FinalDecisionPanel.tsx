"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import {
  finalDecision,
  type RecommendationDecision,
} from "@/lib/requests/admin-actions";
import { cn } from "@/lib/utils";

/**
 * Super admin, stage 3: the final decision, taken after reading the
 * assigned admin's recommendation. Rendered under the request details.
 */
export default function FinalDecisionPanel({
  requestId,
}: {
  requestId: string;
}) {
  const t = useTranslations("admin.workflow");
  const [decision, setDecision] = useState<RecommendationDecision | null>(null);
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const choices: { key: RecommendationDecision; label: string; style: string }[] = [
    {
      key: "approve",
      label: t("approve"),
      style:
        "border-emerald-300 text-emerald-700 aria-pressed:bg-emerald-600 aria-pressed:text-white aria-pressed:border-emerald-600",
    },
    {
      key: "not_approve",
      label: t("notApprove"),
      style:
        "border-red-300 text-red-700 aria-pressed:bg-red-600 aria-pressed:text-white aria-pressed:border-red-600",
    },
  ];

  const submit = () => {
    if (!decision) return;
    if (decision === "not_approve" && !reason.trim()) {
      setError(t("reasonRequired"));
      return;
    }
    setError(null);
    startTransition(async () => {
      const res = await finalDecision(requestId, decision, reason, notes);
      if (!res.ok) {
        setError(res.error === "reasonRequired" ? t("reasonRequired") : t("failed"));
        return;
      }
      router.refresh();
    });
  };

  return (
    <div className="goal-item rounded-xl border-2 border-iau-gold/50 bg-white p-6 shadow-sm">
      <h2 className="text-lg font-bold text-iau-green">{t("finalTitle")}</h2>
      <p className="mt-1 text-sm text-gray-600">{t("finalHint")}</p>

      <div className="mt-4 flex flex-wrap gap-2">
        {choices.map((c) => (
          <button
            key={c.key}
            type="button"
            aria-pressed={decision === c.key}
            onClick={() => setDecision(c.key)}
            className={cn(
              "press rounded-full border-2 bg-white px-4 py-2 text-sm font-semibold transition-colors",
              c.style,
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {decision === "not_approve" && (
        <div className="goal-item mt-4">
          <label
            htmlFor="final-reason"
            className="mb-1.5 block text-sm font-semibold text-gray-800"
          >
            {t("reasonLabel")} <span className="text-red-500">*</span>
          </label>
          <textarea
            id="final-reason"
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full rounded-md border border-gray-300 px-3.5 py-2.5 outline-none transition-shadow focus:ring-2 focus:ring-red-400"
          />
        </div>
      )}

      <div className="mt-4">
        <label
          htmlFor="final-notes"
          className="mb-1.5 block text-sm font-semibold text-gray-800"
        >
          {t("notesLabel")}
        </label>
        <textarea
          id="final-notes"
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="w-full rounded-md border border-gray-300 px-3.5 py-2.5 outline-none transition-shadow focus:ring-2 focus:ring-iau-green"
        />
      </div>

      {error && (
        <p role="alert" className="mt-3 text-sm font-medium text-red-600">
          {error}
        </p>
      )}

      <button
        type="button"
        onClick={submit}
        disabled={!decision || pending}
        className="press mt-5 rounded-md bg-iau-green px-6 py-2.5 font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-50"
      >
        {pending ? t("working") : t("confirm")}
      </button>
    </div>
  );
}
