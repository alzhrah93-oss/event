"use client";

import { useState } from "react";
import { useLocale, useTranslations } from "next-intl";

type Criterion = { key: string; score: number; comment: string };

export type AiEvaluationRow = {
  overall_score: number;
  criteria: Criterion[];
  strengths: string[];
  weaknesses: string[];
  recommendation: string;
  model: string;
  created_at: string;
};

/**
 * AI Event Evaluation panel — asks the model for a criteria-based assessment
 * of the request and renders the stored result (score dial, criteria bars,
 * strengths/weaknesses, recommendation).
 */
export default function AiEvaluationPanel({
  requestId,
  initial,
}: {
  requestId: string;
  initial: AiEvaluationRow | null;
}) {
  const t = useTranslations("admin.ai");
  const locale = useLocale();
  const [evaluation, setEvaluation] = useState<AiEvaluationRow | null>(initial);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setPending(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/admin/requests/${requestId}/evaluate?locale=${locale}`,
        { method: "POST" },
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error === "not_configured" ? t("notConfigured") : t("failed"));
        return;
      }
      setEvaluation(data.evaluation);
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  };

  const scoreColor = (s: number) =>
    s >= 70 ? "text-emerald-600" : s >= 40 ? "text-amber-600" : "text-red-600";
  const barColor = (s: number) =>
    s >= 7 ? "bg-emerald-500" : s >= 4 ? "bg-amber-500" : "bg-red-500";

  return (
    <div className="goal-item rounded-xl border-2 border-iau-green/30 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-iau-green">
            {t("evaluation.title")}
          </h2>
          <p className="mt-1 text-sm text-gray-600">{t("evaluation.hint")}</p>
        </div>
        <button
          type="button"
          onClick={run}
          disabled={pending}
          className="press rounded-md bg-iau-green px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-50"
        >
          {pending
            ? t("working")
            : evaluation
              ? t("evaluation.reevaluate")
              : t("evaluation.button")}
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-3 text-sm font-medium text-red-600">
          {error}
        </p>
      )}

      {evaluation && (
        <div className="mt-5 grid gap-5">
          <div className="flex items-center gap-4">
            <span
              className={`text-4xl font-extrabold tabular-nums ${scoreColor(evaluation.overall_score)}`}
            >
              {evaluation.overall_score}
              <span className="text-base font-semibold text-gray-400">/100</span>
            </span>
            <div className="h-3 flex-1 overflow-hidden rounded-full bg-gray-100">
              <div
                className={`h-full rounded-full transition-all duration-700 ${barColor(evaluation.overall_score / 10)}`}
                style={{ width: `${evaluation.overall_score}%` }}
              />
            </div>
          </div>

          <div className="grid gap-2.5">
            {evaluation.criteria.map((c) => (
              <div key={c.key} className="grid gap-1">
                <div className="flex items-center justify-between gap-3 text-sm">
                  <span className="font-semibold text-gray-800">
                    {t(`evaluation.criteria.${c.key}`)}
                  </span>
                  <span className="tabular-nums text-gray-500">{c.score}/10</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-gray-100">
                  <div
                    className={`h-full rounded-full transition-all duration-700 ${barColor(c.score)}`}
                    style={{ width: `${c.score * 10}%` }}
                  />
                </div>
                <p className="text-xs text-gray-500">{c.comment}</p>
              </div>
            ))}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-lg bg-emerald-50 p-4">
              <h3 className="text-sm font-bold text-emerald-800">
                {t("evaluation.strengths")}
              </h3>
              <ul className="mt-2 grid list-inside list-disc gap-1 text-sm text-emerald-900">
                {evaluation.strengths.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-lg bg-red-50 p-4">
              <h3 className="text-sm font-bold text-red-800">
                {t("evaluation.weaknesses")}
              </h3>
              <ul className="mt-2 grid list-inside list-disc gap-1 text-sm text-red-900">
                {evaluation.weaknesses.map((w) => (
                  <li key={w}>{w}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="rounded-lg border border-iau-green/20 bg-iau-green-light/40 p-4">
            <h3 className="text-sm font-bold text-iau-green">
              {t("evaluation.recommendation")}
            </h3>
            <p className="mt-1.5 text-sm leading-relaxed text-gray-800">
              {evaluation.recommendation}
            </p>
          </div>

          <p className="text-xs text-gray-400">
            {t("generatedBy", { model: evaluation.model })}
          </p>
        </div>
      )}
    </div>
  );
}
