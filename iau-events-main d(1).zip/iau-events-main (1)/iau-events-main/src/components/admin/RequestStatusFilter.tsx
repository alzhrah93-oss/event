"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import type { RequestStatus } from "@/lib/requests/status";

const STATUSES: RequestStatus[] = [
  "entity_review",
  "new",
  "pending_completion",
  "under_review",
  "awaiting_final",
  "approved",
  "not_approved",
  "entity_rejected",
  "cancelled",
  "closed",
];

/** Status dropdown for the admin requests queue — navigates via ?f=. */
export default function RequestStatusFilter({ current }: { current: string }) {
  const t = useTranslations("admin.filters");
  const ts = useTranslations("status");
  const router = useRouter();

  return (
    <div className="flex items-center gap-2">
      <label
        htmlFor="request-status-filter"
        className="text-xs font-bold uppercase tracking-wide text-iau-green"
      >
        {t("label")}
      </label>
      <select
        id="request-status-filter"
        value={current}
        onChange={(e) => router.push(`/admin/requests?f=${e.target.value}`)}
        className="cursor-pointer rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-800 outline-none transition-shadow focus:ring-2 focus:ring-iau-green"
      >
        <option value="actionable">{t("actionable")}</option>
        <option value="all">{t("all")}</option>
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {ts(s)}
          </option>
        ))}
      </select>
    </div>
  );
}
