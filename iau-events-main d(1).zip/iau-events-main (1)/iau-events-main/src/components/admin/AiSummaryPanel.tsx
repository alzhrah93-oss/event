"use client";

import { useState } from "react";
import { useLocale, useTranslations } from "next-intl";

/**
 * "Summarize with AI" — one-click concise summary of a long event request or
 * final report. Summaries are cached server-side; "Regenerate" bypasses it.
 */
export default function AiSummaryPanel({
  requestId,
  kind,
  initialSummary,
}: {
  requestId: string;
  kind: "request" | "report";
  initialSummary: string | null;
}) {
  const t = useTranslations("admin.ai");
  const locale = useLocale();
  const [summary, setSummary] = useState<string | null>(initialSummary);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async (force: boolean) => {
    setPending(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/requests/${requestId}/summarize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, locale, force }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error === "not_configured" ? t("notConfigured") : t("failed"));
        return;
      }
      setSummary(data.summary);
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="goal-item rounded-xl border-2 border-iau-green/30 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-iau-green">
            {t(kind === "request" ? "summary.titleRequest" : "summary.titleReport")}
          </h2>
          <p className="mt-1 text-sm text-gray-600">{t("summary.hint")}</p>
        </div>
        <button
          type="button"
          onClick={() => run(!!summary)}
          disabled={pending}
          className="press rounded-md bg-iau-green px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-50"
        >
          {pending
            ? t("working")
            : summary
              ? t("summary.regenerate")
              : t("summary.button")}
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-3 text-sm font-medium text-red-600">
          {error}
        </p>
      )}

      {summary && (
        <blockquote className="mt-4 rounded-lg border-s-4 border-iau-green/50 bg-iau-section p-4 text-sm leading-relaxed text-gray-800">
          {summary}
        </blockquote>
      )}
    </div>
  );
}
