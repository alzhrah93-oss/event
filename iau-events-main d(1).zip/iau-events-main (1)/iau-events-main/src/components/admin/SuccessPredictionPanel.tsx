"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { cn } from "@/lib/utils";

type PredictionResponse = {
  ok: boolean;
  reason?: string;
  needed?: number;
  available?: number;
  probability?: number;
  likelihood?: "high" | "medium" | "low";
  factors?: { name: string; contribution: number }[];
  metrics?: { accuracy: number; precision: number; recall: number; f1: number };
  trainedOn?: number;
  positives?: number;
};

/**
 * Event Success Prediction — a logistic-regression model trained on the
 * platform's own completed events (classical ML, no LLM) estimates how likely
 * this event is to reach its expected attendance.
 */
export default function SuccessPredictionPanel({
  requestId,
}: {
  requestId: string;
}) {
  const t = useTranslations("admin.ai");
  const [result, setResult] = useState<PredictionResponse | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setPending(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/requests/${requestId}/predict`, {
        method: "POST",
      });
      if (!res.ok) {
        setError(t("failed"));
        return;
      }
      setResult(await res.json());
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  };

  const pct = result?.probability != null ? Math.round(result.probability * 100) : 0;
  const likelihoodStyle = {
    high: "bg-emerald-100 text-emerald-800",
    medium: "bg-amber-100 text-amber-800",
    low: "bg-red-100 text-red-800",
  } as const;

  const positives = (result?.factors ?? []).filter((f) => f.contribution > 0);
  const negatives = (result?.factors ?? []).filter((f) => f.contribution < 0);

  return (
    <div className="goal-item rounded-xl border-2 border-iau-green/30 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-iau-green">
            {t("prediction.title")}
          </h2>
          <p className="mt-1 text-sm text-gray-600">{t("prediction.hint")}</p>
        </div>
        <button
          type="button"
          onClick={run}
          disabled={pending}
          className="press rounded-md bg-iau-green px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-50"
        >
          {pending ? t("working") : t("prediction.button")}
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-3 text-sm font-medium text-red-600">
          {error}
        </p>
      )}

      {result && !result.ok && (
        <p className="mt-4 rounded-lg bg-amber-50 p-4 text-sm text-amber-800">
          {t("prediction.insufficient", {
            available: result.available ?? 0,
            needed: result.needed ?? 0,
          })}
        </p>
      )}

      {result?.ok && result.likelihood && (
        <div className="mt-5 grid gap-5">
          <div className="flex items-center gap-4">
            <span className="text-4xl font-extrabold tabular-nums text-iau-green">
              {pct}%
            </span>
            <span
              className={cn(
                "rounded-full px-3 py-1 text-sm font-bold",
                likelihoodStyle[result.likelihood],
              )}
            >
              {t(`prediction.likelihood.${result.likelihood}`)}
            </span>
            <div className="h-3 flex-1 overflow-hidden rounded-full bg-gray-100">
              <div
                className="h-full rounded-full bg-iau-green transition-all duration-700"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {positives.length > 0 && (
              <div className="rounded-lg bg-emerald-50 p-4">
                <h3 className="text-sm font-bold text-emerald-800">
                  {t("prediction.positives")}
                </h3>
                <ul className="mt-2 grid gap-1 text-sm text-emerald-900">
                  {positives.map((f) => (
                    <li key={f.name}>↑ {t(`prediction.features.${f.name}`)}</li>
                  ))}
                </ul>
              </div>
            )}
            {negatives.length > 0 && (
              <div className="rounded-lg bg-red-50 p-4">
                <h3 className="text-sm font-bold text-red-800">
                  {t("prediction.negatives")}
                </h3>
                <ul className="mt-2 grid gap-1 text-sm text-red-900">
                  {negatives.map((f) => (
                    <li key={f.name}>↓ {t(`prediction.features.${f.name}`)}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {result.metrics && (
            <p className="text-xs leading-relaxed text-gray-400">
              {t("prediction.metrics", {
                n: result.trainedOn ?? 0,
                accuracy: Math.round(result.metrics.accuracy * 100),
                f1: Math.round(result.metrics.f1 * 100),
              })}{" "}
              {(result.trainedOn ?? 0) < 30 && t("prediction.smallSample")}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
