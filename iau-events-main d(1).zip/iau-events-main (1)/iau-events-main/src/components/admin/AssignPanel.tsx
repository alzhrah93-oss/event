"use client";

import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import { assignRequest } from "@/lib/requests/admin-actions";

export type AdminOption = { id: string; name: string };

/**
 * Super admin, stage 1: pick which regular admin reviews this request and
 * send it to them. Rendered under the request details.
 */
export default function AssignPanel({
  requestId,
  admins,
  currentAdminId,
}: {
  requestId: string;
  admins: AdminOption[];
  currentAdminId: string | null;
}) {
  const t = useTranslations("admin.workflow");
  const [adminId, setAdminId] = useState(currentAdminId ?? "");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const send = () => {
    if (!adminId) return;
    setError(null);
    startTransition(async () => {
      const res = await assignRequest(requestId, adminId);
      if (!res.ok) {
        setError(t("failed"));
        return;
      }
      router.refresh();
    });
  };

  return (
    <div className="goal-item rounded-xl border-2 border-iau-green/30 bg-white p-6 shadow-sm">
      <h2 className="text-lg font-bold text-iau-green">{t("assignTitle")}</h2>
      <p className="mt-1 text-sm text-gray-600">
        {currentAdminId ? t("reassignHint") : t("assignHint")}
      </p>

      {admins.length === 0 ? (
        <p className="mt-4 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800">
          {t("noAdmins")}
        </p>
      ) : (
        <>
          <label
            htmlFor="assign-admin"
            className="mb-1.5 mt-4 block text-sm font-semibold text-gray-800"
          >
            {t("assignLabel")}
          </label>
          <select
            id="assign-admin"
            value={adminId}
            onChange={(e) => setAdminId(e.target.value)}
            className="w-full max-w-sm rounded-md border border-gray-300 bg-white px-3.5 py-2.5 outline-none transition-shadow focus:ring-2 focus:ring-iau-green"
          >
            <option value="">{t("assignSelect")}</option>
            {admins.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          {error && (
            <p role="alert" className="mt-3 text-sm font-medium text-red-600">
              {error}
            </p>
          )}

          <button
            type="button"
            onClick={send}
            disabled={!adminId || pending}
            className="press mt-5 block rounded-md bg-iau-green px-6 py-2.5 font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-50"
          >
            {pending ? t("working") : t("assignButton")}
          </button>
        </>
      )}
    </div>
  );
}
