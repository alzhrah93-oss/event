"use client";

import { useActionState, useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { useRouter } from "@/i18n/navigation";
import {
  createAdmin,
  deleteAdmin,
  updateAdminPermissions,
} from "@/lib/auth/admin-management";
import { PERMISSION_SECTIONS } from "@/lib/auth/permissions";
import { cn } from "@/lib/utils";

export type AdminRow = {
  id: string;
  full_name: string;
  email: string;
  permissions: Record<string, string>;
};

export function AdminCard({ admin }: { admin: AdminRow }) {
  const t = useTranslations("admins");
  const [perms, setPerms] = useState<Record<string, string>>(
    admin.permissions,
  );
  const [confirming, setConfirming] = useState(false);
  const [saved, setSaved] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const save = () =>
    startTransition(async () => {
      const res = await updateAdminPermissions(admin.id, perms);
      if (res.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2500);
      }
    });

  const remove = () =>
    startTransition(async () => {
      const res = await deleteAdmin(admin.id);
      if (res.ok) router.refresh();
    });

  return (
    <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-bold text-iau-green">{admin.full_name}</h3>
          <p className="text-sm text-gray-500" dir="ltr">
            {admin.email}
          </p>
        </div>
        {!confirming ? (
          <button
            type="button"
            onClick={() => setConfirming(true)}
            className="press rounded-md border border-red-300 px-3 py-1.5 text-xs font-semibold text-red-600 transition-colors hover:bg-red-50"
          >
            {t("delete")}
          </button>
        ) : (
          <div className="goal-item flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 p-2">
            <span className="text-xs font-medium text-red-700">
              {t("confirmDelete")}
            </span>
            <button
              type="button"
              disabled={pending}
              onClick={remove}
              className="press rounded bg-red-600 px-2.5 py-1 text-xs font-bold text-white hover:bg-red-700 disabled:opacity-60"
            >
              {t("confirmYes")}
            </button>
            <button
              type="button"
              onClick={() => setConfirming(false)}
              className="press rounded border border-gray-300 bg-white px-2.5 py-1 text-xs font-semibold text-gray-600"
            >
              {t("confirmNo")}
            </button>
          </div>
        )}
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {PERMISSION_SECTIONS.map((s) => (
          <div key={s.key}>
            <label
              htmlFor={`${admin.id}-${s.key}`}
              className="mb-1 block text-xs font-semibold text-gray-500"
            >
              {t(`sections.${s.key}`)}
            </label>
            <select
              id={`${admin.id}-${s.key}`}
              value={perms[s.key] ?? s.levels[0]}
              onChange={(e) =>
                setPerms({ ...perms, [s.key]: e.target.value })
              }
              className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-sm outline-none transition-shadow focus:ring-2 focus:ring-iau-green"
            >
              {s.levels.map((lv) => (
                <option key={lv} value={lv}>
                  {t(`levels.${lv}`)}
                </option>
              ))}
            </select>
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-center gap-3">
        <button
          type="button"
          onClick={save}
          disabled={pending}
          className="press rounded-md bg-iau-green px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-60"
        >
          {pending ? t("saving") : t("save")}
        </button>
        {saved && (
          <span className="goal-item text-sm font-medium text-iau-green">
            ✓ {t("saved")}
          </span>
        )}
      </div>
    </div>
  );
}

export function AddAdminForm() {
  const t = useTranslations("admins");
  const [state, action, pending] = useActionState(createAdmin, { ok: false });
  const router = useRouter();

  if (state.ok) router.refresh();

  const err = (code?: string) =>
    code ? t(`errors.${code}` as Parameters<typeof t>[0]) : undefined;
  const cls =
    "w-full rounded-md border border-gray-300 bg-white px-3.5 py-2.5 outline-none transition-shadow focus:ring-2 focus:ring-iau-green";

  return (
    <form
      action={action}
      className="rounded-xl border-2 border-iau-green/25 bg-white p-6 shadow-sm"
    >
      <h2 className="text-lg font-bold text-iau-green">{t("addTitle")}</h2>
      {state.error && (
        <p role="alert" className="mt-3 rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">
          {err(state.error)}
        </p>
      )}
      {state.ok && (
        <p role="status" className="goal-item mt-3 rounded-md bg-iau-green-light px-3 py-2 text-sm text-iau-green">
          ✓ {t("added")}
        </p>
      )}
      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        <div>
          <label htmlFor="new-name" className="mb-1.5 block text-sm font-semibold text-gray-800">
            {t("name")} <span className="text-red-500">*</span>
          </label>
          <input id="new-name" name="name" className={cls} />
        </div>
        <div>
          <label htmlFor="new-email" className="mb-1.5 block text-sm font-semibold text-gray-800">
            {t("email")} <span className="text-red-500">*</span>
          </label>
          <input id="new-email" name="email" type="email" dir="ltr" className={cls} />
        </div>
        <div>
          <label htmlFor="new-password" className="mb-1.5 block text-sm font-semibold text-gray-800">
            {t("password")} <span className="text-red-500">*</span>
          </label>
          <input id="new-password" name="password" type="password" className={cls} />
        </div>
      </div>
      <p className="mt-2 text-xs text-gray-500">{t("passwordHint")}</p>
      <button
        type="submit"
        disabled={pending}
        className={cn(
          "press mt-4 rounded-md bg-iau-green px-6 py-2.5 font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-60",
        )}
      >
        {pending ? t("adding") : t("add")}
      </button>
    </form>
  );
}
