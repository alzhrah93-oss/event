import { useTranslations } from "next-intl";
import type { EventItem } from "@/lib/events-data";
import EventCard from "./EventCard";

/**
 * Auto-scrolling row of event cards, moving right-to-left (both locales),
 * pausing on hover. Falls back to a static scrollable row for
 * prefers-reduced-motion (see globals.css `.marquee`).
 */
export default function EventsMarquee({ events }: { events: EventItem[] }) {
  const t = useTranslations("home");

  if (events.length === 0) {
    return <p className="py-8 text-center text-gray-500">{t("eventsEmpty")}</p>;
  }

  // Duplicate the list for a seamless loop.
  const loop = [...events, ...events];

  return (
    <div className="marquee group relative overflow-hidden" dir="ltr">
      <div className="marquee-track flex w-max gap-4 py-2">
        {loop.map((event, i) => (
          <EventCard key={`${event.id}-${i}`} event={event} />
        ))}
      </div>
    </div>
  );
}
