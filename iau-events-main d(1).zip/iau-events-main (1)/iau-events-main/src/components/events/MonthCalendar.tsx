"use client";

import { useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import { buildMonthGrid } from "@/lib/calendar";
import { eventTone } from "@/lib/event-colors";
import { getEventsForMonth, type EventItem } from "@/lib/events-data";
import { cn } from "@/lib/utils";

const todayIso = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

/**
 * Month grid with a details side panel: clicking a day (or the event chips
 * in it) shows that day's events next to the calendar — beside it on large
 * screens, stacked underneath on mobile. Event chips are colored by
 * activity type (shared tones with the marquee cards).
 */
export default function MonthCalendar({ events }: { events: EventItem[] }) {
  const locale = useLocale() as "en" | "ar";
  const t = useTranslations("calendar");
  const te = useTranslations("events");
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1); // 1-based
  const [selected, setSelected] = useState<string | null>(null);

  const grid = buildMonthGrid(year, month);
  const monthEvents = getEventsForMonth(year, month, events);
  const eventsByDate = new Map<string, EventItem[]>();
  for (const e of monthEvents) {
    eventsByDate.set(e.date, [...(eventsByDate.get(e.date) ?? []), e]);
  }

  const monthName = new Intl.DateTimeFormat(
    locale === "ar" ? "ar-SA" : "en-GB",
    { month: "long", year: "numeric" },
  ).format(new Date(year, month - 1, 1));

  // Localized day names, Sunday first
  const dayNames = Array.from({ length: 7 }, (_, i) =>
    new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
      weekday: "short",
    }).format(new Date(2026, 10, 1 + i)), // Nov 2026 starts on Sunday
  );

  const shift = (delta: number) => {
    const d = new Date(year, month - 1 + delta, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth() + 1);
    setSelected(null);
  };

  const today = todayIso();
  const selectedEvents = selected ? (eventsByDate.get(selected) ?? []) : [];
  const fmtDay = (iso: string) =>
    new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(`${iso}T00:00:00`));

  return (
    <div>
      <p className="mb-4 flex items-center gap-2 text-sm text-gray-600">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden className="shrink-0 text-iau-green">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 8v4M12 16h.01" />
        </svg>
        {t("clickHint")}
      </p>

      <div
        className={cn(
          "grid items-start gap-6",
          selected && "lg:grid-cols-[minmax(0,1fr)_20rem]",
        )}
      >
        {/* Calendar card */}
        <div className="rounded-xl border border-gray-200 bg-white shadow-sm">
          {/* Month header */}
          <div className="flex items-center justify-between border-b border-gray-200 px-4 py-3">
            <button
              type="button"
              onClick={() => shift(-1)}
              aria-label={t("prevMonth")}
              className="press rounded-md p-2 text-iau-green transition-colors hover:bg-iau-green-light"
            >
              <span aria-hidden className="inline-block rtl:rotate-180">←</span>
            </button>
            <h3 className="text-lg font-bold text-iau-green">{monthName}</h3>
            <button
              type="button"
              onClick={() => shift(1)}
              aria-label={t("nextMonth")}
              className="press rounded-md p-2 text-iau-green transition-colors hover:bg-iau-green-light"
            >
              <span aria-hidden className="inline-block rtl:rotate-180">→</span>
            </button>
          </div>

          {/* Day names */}
          <div className="grid grid-cols-7 border-b border-gray-100 text-center text-xs font-semibold text-gray-500">
            {dayNames.map((d) => (
              <div key={d} className="py-2">
                {d}
              </div>
            ))}
          </div>

          {/* Weeks (keyed by month so navigation animates the grid in) */}
          <div key={`${year}-${month}`} className="goal-item">
            {grid.map((week, wi) => (
              <div key={wi} className="grid grid-cols-7">
                {week.map((cell) => {
                  const dayEvents = eventsByDate.get(cell.date) ?? [];
                  const dayNum = Number(cell.date.slice(8, 10));
                  const hasEvents = dayEvents.length > 0;
                  const isSelected = selected === cell.date;
                  const inner = (
                    <>
                      <span
                        className={cn(
                          "inline-flex h-6 w-6 items-center justify-center rounded-full text-xs",
                          cell.date === today
                            ? "bg-iau-green font-bold text-white"
                            : "text-gray-600",
                        )}
                      >
                        {new Intl.NumberFormat(
                          locale === "ar" ? "ar-SA" : "en-GB",
                        ).format(dayNum)}
                      </span>
                      <div className="mt-1 space-y-1">
                        {dayEvents.map((e) => (
                          <div
                            key={e.id}
                            title={e.name[locale]}
                            className={cn(
                              "truncate rounded px-1.5 py-0.5 text-xs font-medium",
                              eventTone(e.type.en).chip,
                            )}
                          >
                            {e.name[locale]}
                          </div>
                        ))}
                      </div>
                    </>
                  );
                  const cellCls = cn(
                    "min-h-20 border-b border-e border-gray-100 p-1.5 text-start align-top last:border-e-0",
                    !cell.inMonth && "bg-gray-50 text-gray-400",
                    isSelected && "bg-iau-green-light/50 ring-2 ring-inset ring-iau-green",
                  );
                  return hasEvents ? (
                    <button
                      key={cell.date}
                      type="button"
                      onClick={() =>
                        setSelected(isSelected ? null : cell.date)
                      }
                      aria-pressed={isSelected}
                      className={cn(cellCls, "cursor-pointer transition-colors hover:bg-iau-green-light/40")}
                    >
                      {inner}
                    </button>
                  ) : (
                    <div key={cell.date} className={cellCls}>
                      {inner}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* Details panel — only rendered once a date has been clicked */}
        {selected && (
        <aside
          aria-live="polite"
          className="goal-item rounded-xl border border-gray-200 bg-white p-5 shadow-sm lg:sticky lg:top-40"
        >
          <h3 className="border-b border-gray-100 pb-3 text-base font-bold text-iau-green">
            {t("detailsTitle")}
          </h3>
            <div key={selected} className="goal-item">
              <p className="mt-3 text-sm font-semibold text-gray-700">
                {fmtDay(selected)}
              </p>
              {selectedEvents.length === 0 ? (
                <p className="py-5 text-sm text-gray-400">{t("noEventsDay")}</p>
              ) : (
                <div className="mt-3 grid gap-3">
                  {selectedEvents.map((e) => {
                    const tone = eventTone(e.type.en);
                    return (
                      <article
                        key={e.id}
                        className="rounded-lg border border-gray-200 p-4"
                      >
                        <div className="flex items-start gap-2">
                          <span
                            aria-hidden
                            className={cn(
                              "mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full",
                              tone.dot,
                            )}
                          />
                          <h4 className="font-bold leading-6 text-gray-900">
                            {e.name[locale]}
                          </h4>
                        </div>
                        <span
                          className={cn(
                            "mt-2 inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold",
                            tone.chip,
                          )}
                        >
                          {e.type[locale]}
                        </span>
                        <dl className="mt-3 grid gap-1.5 text-sm text-gray-600">
                          <div className="flex items-baseline gap-2">
                            <dt className="w-14 shrink-0 text-xs font-semibold uppercase tracking-wide text-gray-400">
                              {te("time")}
                            </dt>
                            <dd dir="ltr">
                              {e.startTime} – {e.endTime}
                            </dd>
                          </div>
                          <div className="flex items-baseline gap-2">
                            <dt className="w-14 shrink-0 text-xs font-semibold uppercase tracking-wide text-gray-400">
                              {te("place")}
                            </dt>
                            <dd>{e.place[locale]}</dd>
                          </div>
                          <div className="flex items-baseline gap-2">
                            <dt className="w-14 shrink-0 text-xs font-semibold uppercase tracking-wide text-gray-400">
                              {te("college")}
                            </dt>
                            <dd>{e.college[locale]}</dd>
                          </div>
                        </dl>
                      </article>
                    );
                  })}
                </div>
              )}
            </div>
        </aside>
        )}
      </div>
    </div>
  );
}
