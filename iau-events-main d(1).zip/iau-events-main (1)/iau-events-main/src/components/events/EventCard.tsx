import { useLocale, useTranslations } from "next-intl";
import type { EventItem } from "@/lib/events-data";

function formatDate(iso: string, locale: string) {
  return new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${iso}T00:00:00`));
}

export default function EventCard({ event }: { event: EventItem }) {
  const locale = useLocale() as "en" | "ar";
  const t = useTranslations("events");

  const rows = [
    { label: t("date"), value: formatDate(event.date, locale), ltr: false },
    {
      label: t("time"),
      value: `${event.startTime} – ${event.endTime}`,
      ltr: true,
    },
    { label: t("place"), value: event.place[locale], ltr: false },
    { label: t("college"), value: event.college[locale], ltr: false },
  ];

  return (
    <article className="card-lift flex w-80 shrink-0 flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
      <div className="border-s-4 border-iau-gold bg-iau-green px-5 py-3.5">
        <h3 className="line-clamp-2 min-h-12 text-[15px] font-semibold leading-6 text-white">
          {event.name[locale]}
        </h3>
        <span className="mt-1.5 inline-block rounded-full bg-white/15 px-2.5 py-0.5 text-xs font-semibold text-white">
          {event.type[locale]}
        </span>
      </div>
      <dl className="grid flex-1 content-start gap-2 px-5 py-4 text-sm">
        {rows.map((row) => (
          <div key={row.label} className="flex items-baseline gap-3">
            <dt className="w-16 shrink-0 text-xs font-semibold uppercase tracking-wide text-gray-400">
              {row.label}
            </dt>
            <dd
              className="truncate font-medium text-gray-700"
              dir={row.ltr ? "ltr" : undefined}
            >
              {row.value}
            </dd>
          </div>
        ))}
      </dl>
    </article>
  );
}
