import Image from "next/image";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";

/** Hero frame: IAU campus photo with a settle-zoom, staggered content entrance. */
export default function Hero() {
  const t = useTranslations("home");

  return (
    <section className="relative flex min-h-[560px] md:min-h-[650px] items-center justify-center overflow-hidden bg-iau-green-deep">
      <Image
        src="/images/IAU_background.jpeg"
        alt=""
        fill
        priority
        sizes="100vw"
        className="hero-photo object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-black/20 to-iau-green-deep/60" />
      <div className="hero-stagger relative mx-auto max-w-4xl px-4 py-20 text-center text-white">
        <h1 className="text-4xl font-bold leading-tight drop-shadow-md sm:text-5xl">
          {t("heroTitle")}
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-xl leading-9 text-white/95 drop-shadow">
          {t("heroSubtitle")}
        </p>
        <div>
          <Link
            href="/request"
            className="press mt-10 inline-block rounded-md bg-iau-gold px-8 py-3.5 text-base font-semibold text-white shadow-lg transition-colors hover:bg-iau-gold/90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            {t("submitRequest")}
          </Link>
        </div>
      </div>
    </section>
  );
}
