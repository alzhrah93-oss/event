"use client";

import { useState } from "react";
import { useLocale, useTranslations } from "next-intl";
import {
  ALIGNMENT_ITEMS,
  FOCUS_AREAS,
  FRAMEWORK_NUMBERS,
  MISSION,
  VISION,
} from "@/lib/content";
import { cn } from "@/lib/utils";
import CountUp from "@/components/ui/CountUp";
import Reveal from "@/components/ui/Reveal";

type Loc = "en" | "ar";

export function VisionMission() {
  const t = useTranslations("home");
  const locale = useLocale() as Loc;

  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-20">
        <Reveal>
          <h2 className="mb-3 text-center text-3xl font-bold text-iau-green">
            {t("visionMissionTitle")}
          </h2>
          <div className="mx-auto mb-10 h-1 w-16 rounded bg-iau-gold" />
        </Reveal>
        <div className="grid gap-6 md:grid-cols-2">
          <Reveal pop className="rounded-xl border-s-4 border-iau-gold bg-iau-section p-8">
            <h3 className="mb-3 text-xl font-bold text-iau-green">
              {t("visionLabel")}
            </h3>
            <p className="text-lg leading-8 text-gray-700">{VISION[locale]}</p>
          </Reveal>
          <Reveal
            delay={100}
            pop
            className="rounded-xl border-s-4 border-iau-gold bg-iau-section p-8"
          >
            <h3 className="mb-3 text-xl font-bold text-iau-green">
              {t("missionLabel")}
            </h3>
            <p className="text-lg leading-8 text-gray-700">{MISSION[locale]}</p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function StrategicGoals() {
  const t = useTranslations("home");
  const locale = useLocale() as Loc;
  const [active, setActive] = useState(FOCUS_AREAS[0].id);
  const area = FOCUS_AREAS.find((a) => a.id === active) ?? FOCUS_AREAS[0];

  return (
    <section className="bg-iau-section">
      <div className="mx-auto max-w-7xl px-4 py-20">
        <Reveal>
          <h2 className="mb-3 text-center text-3xl font-bold text-iau-green">
            {t("goalsTitle")}
          </h2>
          <div className="mx-auto mb-6 h-1 w-16 rounded bg-iau-gold" />
          <p className="mx-auto mb-10 max-w-2xl text-center text-lg text-gray-600">
            {t("goalsIntro")}
          </p>
        </Reveal>

        {/* Signature: the strategy pathway 3 → 7 → 10 → 29 */}
        <div className="mx-auto mb-12 flex max-w-3xl items-center justify-center">
          {FRAMEWORK_NUMBERS.map((n, i) => (
            <div key={n.value} className="flex items-center">
              {i > 0 && (
                <div className="mx-2 h-px w-6 bg-iau-gold sm:mx-4 sm:w-12" />
              )}
              <Reveal delay={i * 120} className="text-center">
                <div className="text-3xl font-bold text-iau-green sm:text-4xl">
                  <CountUp value={n.value} />
                </div>
                <div className="mt-1 max-w-24 text-sm leading-5 text-gray-500">
                  {n.label[locale]}
                </div>
              </Reveal>
            </div>
          ))}
        </div>

        <p className="mb-4 text-center text-sm text-gray-500">
          {t("goalsHint")}
        </p>
        <div className="mb-8 flex flex-wrap justify-center gap-2">
          {FOCUS_AREAS.map((a) => (
            <button
              key={a.id}
              type="button"
              onClick={() => setActive(a.id)}
              className={cn(
                "press rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                a.id === active
                  ? "border-iau-green bg-iau-green text-white shadow-sm"
                  : "border-gray-300 bg-white text-gray-700 hover:border-iau-green hover:text-iau-green",
              )}
            >
              {a.name[locale]}
            </button>
          ))}
        </div>

        <ul key={area.id} className="mx-auto grid max-w-4xl gap-3 sm:grid-cols-2">
          {area.goals.map((g) => (
            <li
              key={g.en}
              className="goal-item rounded-lg border-s-4 border-iau-green bg-white px-4 py-3.5 text-base leading-7 text-gray-700 shadow-sm"
            >
              {g[locale]}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function StrategicAlignment() {
  const t = useTranslations("home");
  const locale = useLocale() as Loc;

  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-20">
        <Reveal>
          <h2 className="mb-3 text-center text-3xl font-bold text-iau-green">
            {t("alignmentTitle")}
          </h2>
          <div className="mx-auto mb-6 h-1 w-16 rounded bg-iau-gold" />
          <p className="mb-10 text-center text-lg text-gray-600">
            {t("alignmentIntro")}
          </p>
        </Reveal>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {ALIGNMENT_ITEMS.map((item, i) => (
            <Reveal
              key={item.name.en}
              delay={i * 60}
              pop
              className="card-lift rounded-xl border border-gray-200 bg-iau-section p-7"
            >
              <h3 className="mb-2 font-bold text-iau-green">
                {item.name[locale]}
              </h3>
              <p className="text-base leading-7 text-gray-600">
                {item.detail[locale]}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
