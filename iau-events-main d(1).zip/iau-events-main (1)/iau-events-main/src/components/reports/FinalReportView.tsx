import { getLocale, getTranslations } from "next-intl/server";
import { formatDate } from "@/lib/requests/display";

function Row({
  label,
  value,
}: {
  label: string;
  value?: string | number | null;
}) {
  const v =
    value === null || value === undefined || value === "" ? "—" : String(value);
  return (
    <div className="grid gap-1 py-2.5 sm:grid-cols-3 sm:gap-4">
      <dt className="text-sm font-semibold text-gray-500">{label}</dt>
      <dd className="text-sm leading-6 text-gray-800 sm:col-span-2">{v}</dd>
    </div>
  );
}

type BudgetRow = {
  item: string;
  approved: number;
  spent: number;
  notes: string;
};

/**
 * Tolerate every stored actual_budget shape: the current
 * [{item, approved, spent, notes}] rows, legacy [{item, amount}] arrays,
 * and legacy {"Item": amount} objects. Never throws on unknown data.
 */
export function normalizeBudget(raw: unknown): BudgetRow[] {
  const num = (v: unknown): number => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };
  if (Array.isArray(raw)) {
    return raw
      .map((entry) => {
        const r = (entry ?? {}) as Record<string, unknown>;
        return {
          item: String(r.item ?? r.name ?? "").trim(),
          approved: num(r.approved ?? r.amount ?? r.cost),
          spent: num(r.spent ?? r.amount ?? r.cost),
          notes: String(r.notes ?? r.description ?? "").trim(),
        };
      })
      .filter((r) => r.item);
  }
  if (raw && typeof raw === "object") {
    return Object.entries(raw as Record<string, unknown>)
      .filter(([, v]) => typeof v === "number")
      .map(([item, v]) => ({
        item,
        approved: num(v),
        spent: num(v),
        notes: "",
      }));
  }
  return [];
}

/* eslint-disable @typescript-eslint/no-explicit-any -- rows come straight from Supabase */
type AnyRow = Record<string, any>;

/**
 * The submitted final report card (fields + actual budget + evidence files),
 * shared between the IIE admin and entity-head report pages. Evidence links
 * render only for callers that passed signed URLs (mayDownload).
 */
export default async function FinalReportView({
  report,
  evidence,
  signed,
  mayDownload,
}: {
  report: AnyRow;
  evidence: AnyRow[];
  signed: Map<string, string>;
  mayDownload: boolean;
}) {
  const t = await getTranslations("admin.reports");
  const locale = (await getLocale()) as "en" | "ar";
  const budget = normalizeBudget(report.actual_budget);
  const fmtNum = (n: number) => n.toLocaleString(locale === "ar" ? "ar" : "en");

  return (
    <div
      data-pdf-block
      className="goal-item rounded-xl border border-gray-200 bg-white p-6 shadow-sm"
    >
      <p className="mb-4 inline-block rounded-full bg-iau-green-light px-3 py-1 text-xs font-semibold text-iau-green">
        {t("fields.submittedOn", {
          date: formatDate(report.submitted_at, locale),
        })}
      </p>
      <dl className="divide-y divide-gray-50">
        <Row label={t("fields.summary")} value={report.implementation_summary} />
        <Row
          label={t("fields.actualDate")}
          value={formatDate(report.actual_date, locale)}
        />
        <Row label={t("fields.actualLocation")} value={report.actual_location} />
        <Row
          label={t("fields.actualAttendance")}
          value={report.actual_attendance}
        />
        <Row label={t("fields.studentCount")} value={report.student_count} />
        <Row label={t("fields.ideasReceived")} value={report.ideas_received} />
        <Row
          label={t("fields.projectsNominated")}
          value={report.projects_nominated}
        />
        <Row
          label={t("fields.projectsNominatedDesc")}
          value={report.projects_nominated_desc}
        />
        <Row label={t("fields.partnerships")} value={report.partnerships} />
        <Row
          label={t("fields.satisfactionPct")}
          value={
            report.satisfaction_pct === null
              ? null
              : `${report.satisfaction_pct}%`
          }
        />
        {/* Legacy reports only — the free-text indicators field was removed */}
        {report.satisfaction && (
          <Row label={t("fields.satisfaction")} value={report.satisfaction} />
        )}
      </dl>

      {budget.length > 0 && (
        <div className="mt-5 border-t border-gray-100 pt-4">
          <h2 className="mb-3 text-sm font-bold text-iau-green">
            {t("fields.budget")}
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 text-start text-xs uppercase tracking-wide text-gray-500">
                  <th className="px-3 py-2 text-start">
                    {t("fields.budgetItem")}
                  </th>
                  <th className="px-3 py-2 text-start">
                    {t("fields.budgetApproved")}
                  </th>
                  <th className="px-3 py-2 text-start">
                    {t("fields.budgetSpent")}
                  </th>
                  <th className="px-3 py-2 text-start">
                    {t("fields.budgetVariance")}
                  </th>
                  <th className="px-3 py-2 text-start">
                    {t("fields.budgetNotes")}
                  </th>
                </tr>
              </thead>
              <tbody>
                {budget.map((b, i) => (
                  <tr key={i} className="border-b border-gray-100 last:border-0">
                    <td className="px-3 py-2 text-gray-800">{b.item}</td>
                    <td className="px-3 py-2 text-gray-600" dir="ltr">
                      {fmtNum(b.approved)}
                    </td>
                    <td className="px-3 py-2 text-gray-600" dir="ltr">
                      {fmtNum(b.spent)}
                    </td>
                    <td
                      className="px-3 py-2 font-semibold text-iau-green"
                      dir="ltr"
                    >
                      {fmtNum(b.approved - b.spent)}
                    </td>
                    <td className="px-3 py-2 text-gray-600">
                      {b.notes || "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {evidence.length > 0 && (
        <div className="mt-5 border-t border-gray-100 pt-4">
          <h2 className="mb-2 text-sm font-bold text-iau-green">
            {t("fields.evidence")}
          </h2>
          {mayDownload ? (
            <div className="flex flex-wrap gap-2">
              {evidence.map((a) => (
                <a
                  key={a.id}
                  href={signed.get(a.id)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="press rounded-md border border-iau-green px-3 py-1.5 text-xs font-semibold text-iau-green transition-colors hover:bg-iau-green-light"
                  dir="ltr"
                >
                  {a.file_name}
                </a>
              ))}
            </div>
          ) : (
            <>
              <div className="flex flex-wrap gap-2">
                {evidence.map((a) => (
                  <span
                    key={a.id}
                    className="rounded-md border border-gray-200 bg-iau-section px-3 py-1.5 text-xs text-gray-500"
                    dir="ltr"
                  >
                    {a.file_name}
                  </span>
                ))}
              </div>
              <p className="mt-2 text-xs text-gray-400">
                {t("downloadNotAllowed")}
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
