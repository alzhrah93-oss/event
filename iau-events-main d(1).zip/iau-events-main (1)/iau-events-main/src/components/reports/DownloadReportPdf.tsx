"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { downloadAnalyticsPdf } from "@/components/analytics/export-pdf";

/**
 * "Download PDF" button above a final report: rasterizes every
 * [data-pdf-block] inside the container (Arabic text renders exactly as on
 * screen) and saves an A4 PDF. Shown to IIE admins and entity heads.
 */
export default function DownloadReportPdf({
  containerId,
  fileName,
}: {
  containerId: string;
  fileName: string;
}) {
  const t = useTranslations("admin.reports");
  const [busy, setBusy] = useState(false);

  const onClick = async () => {
    const el = document.getElementById(containerId);
    if (!el || busy) return;
    setBusy(true);
    try {
      await downloadAnalyticsPdf(el, fileName);
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={busy}
      className="press w-fit rounded-md bg-iau-green px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-iau-green-dark disabled:opacity-60"
    >
      {busy ? t("exportingPdf") : t("downloadPdf")}
    </button>
  );
}
