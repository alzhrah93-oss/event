"use client";

import { useActionState, useState } from "react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { signIn, type AuthState } from "@/lib/auth/actions";
import { Field, FormError, SubmitButton } from "./Field";

type Door = "organizer" | "admin";

/**
 * Login landing with Blackboard-portal proportions and spacing but the
 * platform's original card styling: a centered heading, two white door
 * cards with green icon badges, a wide outlined secondary action, and
 * "Forgot password?" under a divider. Brand green + gold only.
 */
export default function LoginForm() {
  const t = useTranslations("auth");
  const [door, setDoor] = useState<Door | null>(null);

  return door === null ? (
    <div className="text-center">
      <h1 className="text-2xl font-bold text-iau-green-dark sm:text-3xl">
        {t("welcomeTitle")}
      </h1>
      <div className="mx-auto mt-5 h-1 w-16 rounded bg-iau-gold" />

      {/* Two doors, side by side — white cards as before the tile redesign */}
      <div className="mt-12 grid gap-4 sm:grid-cols-2">
        <DoorCard
          icon={
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
              <path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7l8-4z" />
              <path d="M9 12l2 2 4-4" />
            </svg>
          }
          title={t("adminLogin")}
          desc={t("adminLoginDesc")}
          onClick={() => setDoor("admin")}
        />
        <DoorCard
          icon={
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
              <circle cx="12" cy="8" r="4" />
              <path d="M4 21c0-4 3.5-6 8-6s8 2 8 6" />
            </svg>
          }
          title={t("organizerLogin")}
          desc={t("organizerLoginDesc")}
          onClick={() => setDoor("organizer")}
        />
      </div>

      <div className="mt-10 border-t border-gray-200 pt-6 text-start">
        <Link
          href="/forgot-password"
          className="font-bold text-iau-green hover:underline"
        >
          {t("forgotPassword")}
        </Link>
      </div>
    </div>
  ) : (
    <CredentialsForm door={door} onBack={() => setDoor(null)} />
  );
}

function DoorCard({
  icon,
  title,
  desc,
  onClick,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="press card-lift flex h-full flex-col items-center gap-3 rounded-xl border-2 border-gray-200 bg-white p-5 text-center shadow-sm transition-colors hover:border-iau-green"
    >
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-iau-green/10 text-iau-green">
        {icon}
      </span>
      <span className="block text-base font-bold leading-6 text-iau-green">
        {title}
      </span>
      <span className="block text-sm leading-6 text-gray-600">{desc}</span>
    </button>
  );
}

function CredentialsForm({ door, onBack }: { door: Door; onBack: () => void }) {
  const t = useTranslations("auth");
  const boundSignIn = signIn.bind(null, door);
  const [state, action, pending] = useActionState<AuthState, FormData>(
    boundSignIn,
    {},
  );

  return (
    <form action={action} className="mx-auto max-w-md space-y-5">
      <button
        type="button"
        onClick={onBack}
        className="press inline-flex items-center gap-1.5 text-sm font-semibold text-gray-500 hover:text-iau-green"
      >
        <span aria-hidden className="inline-block rtl:rotate-180">←</span>
        {t("back")}
      </button>

      <div>
        <h1 className="text-2xl font-bold text-iau-green-dark">
          {door === "admin" ? t("adminLogin") : t("organizerLogin")}
        </h1>
        <div className="mt-3 h-1 w-12 rounded bg-iau-gold" />
      </div>

      <FormError
        message={
          state.errors?.form
            ? t(`errors.${state.errors.form}` as Parameters<typeof t>[0])
            : undefined
        }
      />

      <Field
        label={t("email")}
        name="email"
        type="email"
        dir="ltr"
        autoComplete="email"
      />
      <Field
        label={t("password")}
        name="password"
        type="password"
        autoComplete="current-password"
      />

      <SubmitButton pending={pending}>{t("signIn")}</SubmitButton>

      <p className="text-center">
        <Link
          href="/forgot-password"
          className="text-sm font-semibold text-iau-green hover:underline"
        >
          {t("forgotPassword")}
        </Link>
      </p>
    </form>
  );
}
