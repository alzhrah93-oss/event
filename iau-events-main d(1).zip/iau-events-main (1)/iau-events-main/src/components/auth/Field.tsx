import { cn } from "@/lib/utils";

export function Field({
  label,
  name,
  type = "text",
  error,
  autoComplete,
  dir,
}: {
  label: string;
  name: string;
  type?: string;
  /** Localized error message (already translated) */
  error?: string;
  autoComplete?: string;
  dir?: "ltr" | "rtl";
}) {
  return (
    <div>
      <label
        htmlFor={name}
        className="mb-1.5 block text-sm font-semibold text-gray-800"
      >
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        dir={dir}
        autoComplete={autoComplete}
        aria-invalid={!!error}
        aria-describedby={error ? `${name}-error` : undefined}
        className={cn(
          "w-full rounded-md border bg-white px-3.5 py-2.5 text-gray-900 outline-none transition-shadow",
          "focus:ring-2 focus:ring-iau-green",
          error ? "border-red-400" : "border-gray-300",
        )}
      />
      {error && (
        <p id={`${name}-error`} className="mt-1.5 text-sm text-red-600">
          {error}
        </p>
      )}
    </div>
  );
}

export function FormError({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <div
      role="alert"
      className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
    >
      {message}
    </div>
  );
}

export function FormNotice({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <div
      role="status"
      className="rounded-md border border-iau-gold bg-iau-gold/10 px-4 py-3 text-sm text-iau-green-dark"
    >
      {message}
    </div>
  );
}

export function SubmitButton({
  children,
  pending,
}: {
  children: React.ReactNode;
  pending?: boolean;
}) {
  return (
    <button
      type="submit"
      disabled={pending}
      className="press w-full rounded-md bg-iau-green px-4 py-3 font-bold text-white shadow-sm transition-colors hover:bg-iau-green-dark disabled:opacity-60"
    >
      {children}
    </button>
  );
}
