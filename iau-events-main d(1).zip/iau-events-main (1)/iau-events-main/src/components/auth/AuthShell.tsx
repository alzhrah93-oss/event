import Image from "next/image";
import BackLink from "@/components/ui/BackLink";

/**
 * Split auth layout in the style of the IAU Blackboard portal: campus photo
 * under a deep-green tint with the university logo centered on it, and a
 * narrow white panel for the forms (photo clearly wider, Blackboard
 * proportion). The only page-level back control sits on the photo (large
 * screens); on mobile each form's own back link is the single back
 * affordance.
 */
export default function AuthShell({
  children,
  backHref,
}: {
  children: React.ReactNode;
  backHref?: string;
}) {
  return (
    <main className="flex min-h-[calc(100vh-8rem)] bg-white">
      {/* Photo side */}
      <div className="relative hidden flex-1 lg:block">
        <Image
          src="/images/IAU_background.jpeg"
          alt=""
          fill
          sizes="(min-width: 1024px) 65vw, 0vw"
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-iau-green-deep/55" />
        {backHref && (
          <div className="absolute start-6 top-6 z-10">
            <BackLink href={backHref} light />
          </div>
        )}
        {/* Centered brand mark, Blackboard-portal style */}
        <div className="absolute inset-0 flex items-center justify-center p-10">
          <Image
            src="/images/iau-logo.png"
            alt="IAU"
            width={280}
            height={280}
            className="brightness-0 invert drop-shadow"
          />
        </div>
      </div>

      {/* Form side — white, generous Blackboard-like breathing room.
          No mobile back fallback: each form carries its own back control,
          so a second one here would stack two "Back" buttons on phones. */}
      <div className="relative flex w-full items-center justify-center px-5 py-16 lg:w-[36%] lg:px-8 lg:py-20">
        <div className="hero-stagger w-full max-w-sm">{children}</div>
      </div>
    </main>
  );
}
