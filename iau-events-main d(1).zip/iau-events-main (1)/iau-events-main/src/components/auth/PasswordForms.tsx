"use client";

import { useActionState } from "react";
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import {
  resetPassword,
  updatePassword,
  type AuthState,
} from "@/lib/auth/actions";
import { Field, FormError, FormNotice, SubmitButton } from "./Field";

export function ForgotPasswordForm() {
  const t = useTranslations("auth");
  const [state, action, pending] = useActionState<AuthState, FormData>(
    resetPassword,
    {},
  );

  return (
    <form action={action} className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-iau-green-dark">
          {t("resetPasswordTitle")}
        </h1>
        <p className="mt-1 text-sm text-gray-600">
          {t("resetPasswordSubtitle")}
        </p>
      </div>

      <FormError
        message={
          state.errors?.form
            ? t(`errors.${state.errors.form}` as Parameters<typeof t>[0])
            : undefined
        }
      />
      <FormNotice
        message={
          state.notice
            ? t(`notices.${state.notice}` as Parameters<typeof t>[0])
            : undefined
        }
      />

      <Field
        label={t("email")}
        name="email"
        type="email"
        dir="ltr"
        autoComplete="email"
      />

      <SubmitButton pending={pending}>{t("sendResetLink")}</SubmitButton>

      <p className="text-center">
        <Link
          href="/login"
          className="text-sm font-semibold text-iau-green hover:underline"
        >
          {t("backToLogin")}
        </Link>
      </p>
    </form>
  );
}

export function ResetPasswordForm() {
  const t = useTranslations("auth");
  const [state, action, pending] = useActionState<AuthState, FormData>(
    updatePassword,
    {},
  );

  return (
    <form action={action} className="space-y-4">
      <h1 className="text-2xl font-bold text-iau-green-dark">{t("newPasswordTitle")}</h1>

      <FormError
        message={
          state.errors?.form
            ? t(`errors.${state.errors.form}` as Parameters<typeof t>[0])
            : undefined
        }
      />

      <Field
        label={t("password")}
        name="password"
        type="password"
        autoComplete="new-password"
      />
      <Field
        label={t("confirmPassword")}
        name="confirmPassword"
        type="password"
        autoComplete="new-password"
      />

      <SubmitButton pending={pending}>{t("updatePassword")}</SubmitButton>
    </form>
  );
}
