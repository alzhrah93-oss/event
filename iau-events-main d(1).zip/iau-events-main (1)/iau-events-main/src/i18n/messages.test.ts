import { describe, expect, it } from "vitest";
import en from "../../messages/en.json";
import ar from "../../messages/ar.json";

function flatKeys(obj: Record<string, unknown>, prefix = ""): string[] {
  return Object.entries(obj).flatMap(([k, v]) =>
    v !== null && typeof v === "object"
      ? flatKeys(v as Record<string, unknown>, `${prefix}${k}.`)
      : [`${prefix}${k}`],
  );
}

describe("message catalogs", () => {
  it("ar has exactly the same keys as en", () => {
    expect(flatKeys(ar).sort()).toEqual(flatKeys(en).sort());
  });

  it("no empty strings", () => {
    const check = (o: Record<string, unknown>) =>
      Object.values(o).forEach((v) =>
        typeof v === "object" && v !== null
          ? check(v as Record<string, unknown>)
          : expect(String(v).trim()).not.toBe(""),
      );
    for (const cat of [en, ar]) check(cat);
  });
});
