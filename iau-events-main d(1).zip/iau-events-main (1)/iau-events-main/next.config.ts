import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin();

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      // Vercel rejects request bodies over ~4.5MB, so 4mb is the practical ceiling.
      // Default 1MB caused prod 413s when organizers attached real files.
      bodySizeLimit: "4mb",
    },
  },
};

export default withNextIntl(nextConfig);
