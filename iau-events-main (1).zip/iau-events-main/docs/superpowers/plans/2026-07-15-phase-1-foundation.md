# Phase 1: Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Scaffold the bilingual (EN/AR + RTL) Next.js website with IAU design tokens, shared header/nav/footer, and placeholder routes for every public page.

**Architecture:** Next.js App Router at the repo root with locale-prefixed routing (`/en/...`, `/ar/...`) via next-intl. All UI reads strings from message catalogs; Arabic renders `dir="rtl"`. Design tokens (IAU green/white public palette + Blackboard yellow/blue auth palette) live in Tailwind v4 `@theme` CSS variables.

**Tech Stack:** Next.js (latest, App Router, TypeScript), Tailwind CSS v4, next-intl v4, Vitest, next/font (Inter + Cairo).

## Global Constraints (from spec)

- Product is a **website** — browser-based, responsive (phone/tablet/laptop), no installation.
- Every page fully bilingual EN + AR with correct RTL mirroring.
- Public palette: IAU greens + white. Auth palette: Blackboard yellow + blue (used in Phase 3).
- Nav items (exact): Home, Sign up, Log in, Strategic Plan, Event Request Requirements, Events Calendar.
- Top utility bar: search bar + English/Arabic switch.
- No secrets in the repo; `.gitignore` must exclude all `.env*` files.
- Node 24 / npm 11 (verified on machine).

**Note on brand colors:** Token values below are close approximations of iau.edu.sa. During Phase 2 (visual build-out) they will be checked against the live site in the browser and refined; they are real values, not placeholders.

**Note on logo:** Phase 1 uses a styled text logo ("IAU — Institute of Innovation & Entrepreneurship"). The official logo image is swapped in during Phase 2.

---

### Task 1: Scaffold Next.js at repo root

**Files:**
- Create: entire Next.js scaffold (`package.json`, `src/app/*`, `next.config.ts`, `tsconfig.json`, `.gitignore`, …) at repo root

**Interfaces:**
- Produces: `npm run dev` serving the app; `src/app/` directory later tasks build in; `@/*` path alias → `src/*`.

- [ ] **Step 1: Scaffold in a temp subdir (create-next-app refuses non-empty dirs)**

```bash
cd "C:/Users/Htoon/OneDrive/Desktop/Event Manegment Platform (web)"
npx --yes create-next-app@latest webapp-tmp --ts --tailwind --eslint --app --src-dir --use-npm --no-import-alias --disable-git
```

Expected: scaffold completes in `webapp-tmp/` (accept defaults if prompted; `--no-import-alias` keeps `@/*`).

- [ ] **Step 2: Move scaffold to repo root and remove temp dir**

```bash
cd "C:/Users/Htoon/OneDrive/Desktop/Event Manegment Platform (web)"
# move everything including dotfiles
(shopt -s dotglob; mv webapp-tmp/* .)
rmdir webapp-tmp
```

Expected: `package.json`, `src/`, `next.config.ts` now at root; `webapp-tmp` gone.

- [ ] **Step 3: Confirm `.gitignore` excludes env files**

Open `.gitignore`; it must contain `.env*` (create-next-app default includes it). If missing, add:

```
.env*
```

- [ ] **Step 4: Verify dev server**

```bash
npm run dev
```

Expected: "Ready" on http://localhost:3000, default Next.js page renders. Stop the server after checking.

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat: scaffold Next.js app (TypeScript, Tailwind, App Router)"
```

---

### Task 2: Test infrastructure (Vitest) + `cn` utility

**Files:**
- Create: `vitest.config.ts`, `src/lib/utils.ts`, `src/lib/utils.test.ts`
- Modify: `package.json` (add `test` script)

**Interfaces:**
- Produces: `cn(...inputs: ClassValue[]): string` — class-merging helper every later component uses; `npm test` command.

- [ ] **Step 1: Install dev deps**

```bash
npm install --save-dev vitest vite-tsconfig-paths
npm install clsx tailwind-merge
```

- [ ] **Step 2: Create `vitest.config.ts`**

```ts
import { defineConfig } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [tsconfigPaths()],
  test: {
    environment: "node",
    include: ["src/**/*.test.{ts,tsx}"],
  },
});
```

- [ ] **Step 3: Add test script to `package.json` scripts**

```json
"test": "vitest run"
```

- [ ] **Step 4: Write the failing test — `src/lib/utils.test.ts`**

```ts
import { describe, expect, it } from "vitest";
import { cn } from "./utils";

describe("cn", () => {
  it("merges class names", () => {
    expect(cn("a", "b")).toBe("a b");
  });
  it("drops falsy values", () => {
    expect(cn("a", false && "b", undefined, "c")).toBe("a c");
  });
  it("resolves tailwind conflicts (last wins)", () => {
    expect(cn("p-2", "p-4")).toBe("p-4");
  });
});
```

- [ ] **Step 5: Run test to verify it fails**

Run: `npm test`
Expected: FAIL — cannot resolve `./utils`.

- [ ] **Step 6: Implement `src/lib/utils.ts`**

```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

- [ ] **Step 7: Run tests to verify pass**

Run: `npm test`
Expected: 3 passed.

- [ ] **Step 8: Commit**

```bash
git add -A
git commit -m "feat: add vitest and cn class utility"
```

---

### Task 3: Bilingual routing with next-intl (EN/AR + RTL)

**Files:**
- Create: `src/i18n/routing.ts`, `src/i18n/navigation.ts`, `src/i18n/request.ts`, `src/middleware.ts`, `messages/en.json`, `messages/ar.json`, `src/app/[locale]/layout.tsx`, `src/app/[locale]/page.tsx`, `src/i18n/messages.test.ts`
- Modify: `next.config.ts`
- Delete: `src/app/page.tsx`, `src/app/layout.tsx` (replaced by `[locale]` versions)

**Interfaces:**
- Produces: `routing` (locales `["en","ar"]`, default `en`); `Link`, `usePathname`, `useRouter` from `@/i18n/navigation` (locale-aware — ALL later components import Link from here, never from `next/link`); message catalogs `messages/en.json` / `messages/ar.json`; `t()` via `useTranslations`/`getTranslations`.

- [ ] **Step 1: Install**

```bash
npm install next-intl
```

- [ ] **Step 2: Create `src/i18n/routing.ts`**

```ts
import { defineRouting } from "next-intl/routing";

export const routing = defineRouting({
  locales: ["en", "ar"],
  defaultLocale: "en",
});
```

- [ ] **Step 3: Create `src/i18n/navigation.ts`**

```ts
import { createNavigation } from "next-intl/navigation";
import { routing } from "./routing";

export const { Link, redirect, usePathname, useRouter, getPathname } =
  createNavigation(routing);
```

- [ ] **Step 4: Create `src/i18n/request.ts`**

```ts
import { getRequestConfig } from "next-intl/server";
import { hasLocale } from "next-intl";
import { routing } from "./routing";

export default getRequestConfig(async ({ requestLocale }) => {
  const requested = await requestLocale;
  const locale = hasLocale(routing.locales, requested)
    ? requested
    : routing.defaultLocale;
  return {
    locale,
    messages: (await import(`../../messages/${locale}.json`)).default,
  };
});
```

- [ ] **Step 5: Create `src/middleware.ts`**

```ts
import createMiddleware from "next-intl/middleware";
import { routing } from "./i18n/routing";

export default createMiddleware(routing);

export const config = {
  matcher: "/((?!api|_next|_vercel|.*\\..*).*)",
};
```

- [ ] **Step 6: Wire plugin in `next.config.ts`**

```ts
import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin();

const nextConfig: NextConfig = {};

export default withNextIntl(nextConfig);
```

- [ ] **Step 7: Create `messages/en.json`**

```json
{
  "common": {
    "siteName": "Institute of Innovation and Entrepreneurship",
    "university": "Imam Abdulrahman Bin Faisal University",
    "search": "Search",
    "searchPlaceholder": "Search...",
    "language": "العربية"
  },
  "nav": {
    "home": "Home",
    "signup": "Sign up",
    "login": "Log in",
    "strategicPlan": "Strategic Plan",
    "requirements": "Event Request Requirements",
    "calendar": "Events Calendar"
  },
  "footer": {
    "about": "About the Institute",
    "aboutText": "The premier hub for entrepreneurial and innovation programs and events at Imam Abdulrahman Bin Faisal University.",
    "quickLinks": "Quick Links",
    "contact": "Contact Us",
    "location": "Dammam, Kingdom of Saudi Arabia",
    "email": "Email",
    "phone": "Phone",
    "faq": "Frequently Asked Questions",
    "rights": "All rights reserved.",
    "copyright": "© {year} Imam Abdulrahman Bin Faisal University"
  },
  "home": {
    "heroTitle": "Empowering Innovation, Fueling Entrepreneurship",
    "heroSubtitle": "The premier hub for programs and events at IAU — shaping the future of Saudi innovation",
    "submitRequest": "Submit event request",
    "placeholder": "Home content coming in Phase 2"
  },
  "pages": {
    "strategicPlanTitle": "Strategic Plan",
    "requirementsTitle": "Event Request Requirements",
    "calendarTitle": "Events Calendar",
    "signupTitle": "Create Account",
    "loginTitle": "Log in",
    "comingSoon": "This page is under construction."
  }
}
```

- [ ] **Step 8: Create `messages/ar.json`**

```json
{
  "common": {
    "siteName": "معهد الابتكار وريادة الأعمال",
    "university": "جامعة الإمام عبدالرحمن بن فيصل",
    "search": "بحث",
    "searchPlaceholder": "ابحث...",
    "language": "English"
  },
  "nav": {
    "home": "الرئيسية",
    "signup": "إنشاء حساب",
    "login": "تسجيل الدخول",
    "strategicPlan": "الخطة الاستراتيجية",
    "requirements": "متطلبات طلب الفعالية",
    "calendar": "تقويم الفعاليات"
  },
  "footer": {
    "about": "عن المعهد",
    "aboutText": "المنصة الرائدة للبرامج والفعاليات الريادية والابتكارية في جامعة الإمام عبدالرحمن بن فيصل.",
    "quickLinks": "روابط سريعة",
    "contact": "اتصل بنا",
    "location": "الدمام، المملكة العربية السعودية",
    "email": "البريد الإلكتروني",
    "phone": "الهاتف",
    "faq": "الأسئلة الشائعة",
    "rights": "جميع الحقوق محفوظة.",
    "copyright": "© {year} جامعة الإمام عبدالرحمن بن فيصل"
  },
  "home": {
    "heroTitle": "تمكين الابتكار، ودعم ريادة الأعمال",
    "heroSubtitle": "المنصة الرائدة للبرامج والفعاليات في الجامعة — نصنع مستقبل الابتكار السعودي",
    "submitRequest": "تقديم طلب فعالية",
    "placeholder": "محتوى الصفحة الرئيسية قادم في المرحلة الثانية"
  },
  "pages": {
    "strategicPlanTitle": "الخطة الاستراتيجية",
    "requirementsTitle": "متطلبات طلب الفعالية",
    "calendarTitle": "تقويم الفعاليات",
    "signupTitle": "إنشاء حساب",
    "loginTitle": "تسجيل الدخول",
    "comingSoon": "هذه الصفحة قيد الإنشاء."
  }
}
```

- [ ] **Step 9: Write catalog-parity test — `src/i18n/messages.test.ts`** (this path matches the vitest `include` pattern):

```ts
import { describe, expect, it } from "vitest";
import en from "../../messages/en.json";
import ar from "../../messages/ar.json";

function flatKeys(obj: Record<string, unknown>, prefix = ""): string[] {
  return Object.entries(obj).flatMap(([k, v]) =>
    v !== null && typeof v === "object"
      ? flatKeys(v as Record<string, unknown>, `${prefix}${k}.`)
      : [`${prefix}${k}`],
  );
}

describe("message catalogs", () => {
  it("ar has exactly the same keys as en", () => {
    expect(flatKeys(ar).sort()).toEqual(flatKeys(en).sort());
  });
  it("no empty strings", () => {
    for (const cat of [en, ar]) {
      const check = (o: Record<string, unknown>) =>
        Object.values(o).forEach((v) =>
          typeof v === "object" && v !== null
            ? check(v as Record<string, unknown>)
            : expect(String(v).trim()).not.toBe(""),
        );
      check(cat);
    }
  });
});
```

Run: `npm test` — Expected: PASS immediately if Steps 7–8 were done correctly (this test guards ALL future catalog edits; if it fails, fix the catalogs).

- [ ] **Step 10: Replace root layout/page with `[locale]` versions**

Delete `src/app/layout.tsx` and `src/app/page.tsx`.

Create `src/app/[locale]/layout.tsx`:

```tsx
import type { Metadata } from "next";
import { NextIntlClientProvider, hasLocale } from "next-intl";
import { setRequestLocale } from "next-intl/server";
import { notFound } from "next/navigation";
import { routing } from "@/i18n/routing";
import "../globals.css";

export const metadata: Metadata = {
  title: "IAU | Institute of Innovation and Entrepreneurship",
  description:
    "Event management platform for the Institute of Innovation and Entrepreneurship at Imam Abdulrahman Bin Faisal University",
};

export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!hasLocale(routing.locales, locale)) notFound();
  setRequestLocale(locale);

  return (
    <html lang={locale} dir={locale === "ar" ? "rtl" : "ltr"}>
      <body className="min-h-screen antialiased">
        <NextIntlClientProvider>{children}</NextIntlClientProvider>
      </body>
    </html>
  );
}
```

Create `src/app/[locale]/page.tsx`:

```tsx
import { useTranslations } from "next-intl";

export default function HomePage() {
  const t = useTranslations("home");
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">{t("heroTitle")}</h1>
      <p>{t("heroSubtitle")}</p>
    </main>
  );
}
```

- [ ] **Step 11: Verify locales work**

```bash
npm run dev
```

Check: http://localhost:3000 redirects to `/en`, English hero text; http://localhost:3000/ar shows Arabic text AND the page direction is right-to-left (inspect `<html dir="rtl">`). Stop server.

- [ ] **Step 12: Commit**

```bash
git add -A
git commit -m "feat: bilingual EN/AR routing with next-intl and RTL support"
```

---

### Task 4: IAU design tokens + fonts

**Files:**
- Modify: `src/app/globals.css`, `src/app/[locale]/layout.tsx`

**Interfaces:**
- Produces: Tailwind color utilities all later UI uses: `iau-green` (+`-dark`, `-deep`, `-light`), `iau-gold`, `bb-blue`, `bb-yellow`; font vars `--font-sans-en` (Inter), `--font-sans-ar` (Cairo) auto-applied by `dir`.

- [ ] **Step 1: Replace `src/app/globals.css`**

```css
@import "tailwindcss";

@theme {
  /* IAU public palette (checked against iau.edu.sa in Phase 2) */
  --color-iau-green: #046a38;
  --color-iau-green-dark: #035129;
  --color-iau-green-deep: #02391d;
  --color-iau-green-light: #e6f2ec;
  --color-iau-gold: #c3a24d;

  /* Blackboard-style auth palette (Phase 3) */
  --color-bb-blue: #1e3a6e;
  --color-bb-blue-dark: #14294f;
  --color-bb-yellow: #f5b335;
  --color-bb-yellow-light: #fdeecd;

  --font-sans: var(--font-sans-en), var(--font-sans-ar), system-ui, sans-serif;
}

html[dir="rtl"] body {
  font-family: var(--font-sans-ar), var(--font-sans-en), system-ui, sans-serif;
}
```

- [ ] **Step 2: Load fonts in `src/app/[locale]/layout.tsx`**

Add imports and body class (keep everything else from Task 3 intact):

```tsx
import { Inter, Cairo } from "next/font/google";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans-en",
});

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-sans-ar",
});
```

and on `<body>`:

```tsx
<body className={`${inter.variable} ${cairo.variable} min-h-screen antialiased font-sans`}>
```

- [ ] **Step 3: Verify**

```bash
npm run dev
```

Check `/en` renders with Inter, `/ar` with Cairo (visibly different letterforms; Arabic text no longer fallback-font). Add `class="text-iau-green"` temporarily to the h1 to confirm the token compiles, then remove it. Stop server.

- [ ] **Step 4: Commit**

```bash
git add -A
git commit -m "feat: IAU design tokens and bilingual fonts (Inter + Cairo)"
```

---

### Task 5: Site header — utility bar, nav, language switcher, mobile menu

**Files:**
- Create: `src/components/layout/LanguageSwitcher.tsx`, `src/components/layout/SearchBar.tsx`, `src/components/layout/SiteHeader.tsx`
- Modify: `src/app/[locale]/layout.tsx`

**Interfaces:**
- Consumes: `Link`, `usePathname`, `useRouter` from `@/i18n/navigation`; `cn` from `@/lib/utils`; `nav.*`, `common.*` messages.
- Produces: `<SiteHeader />` server component rendered in the locale layout above `{children}`.

- [ ] **Step 1: Create `src/components/layout/LanguageSwitcher.tsx`**

```tsx
"use client";

import { useLocale, useTranslations } from "next-intl";
import { usePathname, useRouter } from "@/i18n/navigation";

export default function LanguageSwitcher() {
  const locale = useLocale();
  const pathname = usePathname();
  const router = useRouter();
  const t = useTranslations("common");

  const toggle = () => {
    router.replace(pathname, { locale: locale === "en" ? "ar" : "en" });
  };

  return (
    <button
      type="button"
      onClick={toggle}
      className="rounded px-3 py-1 text-sm font-semibold text-white transition-colors hover:bg-white/20"
    >
      {t("language")}
    </button>
  );
}
```

- [ ] **Step 2: Create `src/components/layout/SearchBar.tsx`** (UI only in Phase 1; wired to real search later)

```tsx
"use client";

import { useTranslations } from "next-intl";

export default function SearchBar() {
  const t = useTranslations("common");
  return (
    <form
      role="search"
      onSubmit={(e) => e.preventDefault()}
      className="flex items-center"
    >
      <input
        type="search"
        placeholder={t("searchPlaceholder")}
        aria-label={t("search")}
        className="w-40 rounded-s bg-white/90 px-3 py-1 text-sm text-gray-800 outline-none placeholder:text-gray-500 focus:w-52 transition-all sm:w-52 sm:focus:w-64"
      />
      <button
        type="submit"
        className="rounded-e bg-iau-gold px-3 py-1 text-sm font-semibold text-white"
      >
        {t("search")}
      </button>
    </form>
  );
}
```

- [ ] **Step 3: Create `src/components/layout/SiteHeader.tsx`**

```tsx
"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";
import { cn } from "@/lib/utils";
import LanguageSwitcher from "./LanguageSwitcher";
import SearchBar from "./SearchBar";

const NAV_ITEMS = [
  { key: "home", href: "/" },
  { key: "signup", href: "/signup" },
  { key: "login", href: "/login" },
  { key: "strategicPlan", href: "/strategic-plan" },
  { key: "requirements", href: "/requirements" },
  { key: "calendar", href: "/calendar" },
] as const;

export default function SiteHeader() {
  const t = useTranslations("nav");
  const tc = useTranslations("common");
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 shadow">
      {/* Utility bar: search + language switch */}
      <div className="bg-iau-green-deep">
        <div className="mx-auto flex max-w-7xl items-center justify-end gap-3 px-4 py-1.5">
          <SearchBar />
          <LanguageSwitcher />
        </div>
      </div>

      {/* Main bar: logo + nav */}
      <div className="bg-iau-green">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          <Link href="/" className="flex flex-col leading-tight text-white">
            <span className="text-lg font-bold">IAU</span>
            <span className="text-xs opacity-90">{tc("siteName")}</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 lg:flex">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.key}
                href={item.href}
                className={cn(
                  "rounded px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-white/15",
                  pathname === item.href && "bg-white/20",
                )}
              >
                {t(item.key)}
              </Link>
            ))}
          </nav>

          {/* Mobile hamburger */}
          <button
            type="button"
            className="text-white lg:hidden"
            aria-label="Menu"
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {open ? (
                <path d="M6 6l12 12M18 6L6 18" />
              ) : (
                <path d="M3 6h18M3 12h18M3 18h18" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile menu */}
        {open && (
          <nav className="border-t border-white/20 lg:hidden">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.key}
                href={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "block px-6 py-3 text-sm font-medium text-white hover:bg-white/15",
                  pathname === item.href && "bg-white/20",
                )}
              >
                {t(item.key)}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
```

- [ ] **Step 4: Render header in `src/app/[locale]/layout.tsx`**

Add import and place inside provider, above children:

```tsx
import SiteHeader from "@/components/layout/SiteHeader";
// ...
<NextIntlClientProvider>
  <SiteHeader />
  {children}
</NextIntlClientProvider>
```

- [ ] **Step 5: Verify**

`npm run dev` — check on `/en`: green two-tier header, search + language button top-right, all 6 nav items; click العربية → `/ar`, layout mirrors (nav flows right-to-left, search bar position flips); shrink window below `lg` → hamburger menu opens/closes. Stop server.

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat: IAU-style site header with search, language switch, responsive nav"
```

---

### Task 6: IAU-style footer

**Files:**
- Create: `src/components/layout/SiteFooter.tsx`
- Modify: `src/app/[locale]/layout.tsx`

**Interfaces:**
- Consumes: `Link` from `@/i18n/navigation`; `footer.*`, `nav.*`, `common.*` messages.
- Produces: `<SiteFooter />` rendered below `{children}`.

- [ ] **Step 1: Create `src/components/layout/SiteFooter.tsx`**

```tsx
import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";

export default function SiteFooter() {
  const t = useTranslations("footer");
  const tn = useTranslations("nav");
  const tc = useTranslations("common");
  const year = new Date().getFullYear();

  return (
    <footer className="bg-iau-green-deep text-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-3">
        <div>
          <h3 className="mb-3 border-b border-iau-gold pb-2 text-base font-bold">
            {t("about")}
          </h3>
          <p className="text-sm leading-6 opacity-90">{t("aboutText")}</p>
        </div>
        <div>
          <h3 className="mb-3 border-b border-iau-gold pb-2 text-base font-bold">
            {t("quickLinks")}
          </h3>
          <ul className="space-y-2 text-sm">
            <li><Link className="hover:text-iau-gold" href="/">{tn("home")}</Link></li>
            <li><Link className="hover:text-iau-gold" href="/strategic-plan">{tn("strategicPlan")}</Link></li>
            <li><Link className="hover:text-iau-gold" href="/requirements">{tn("requirements")}</Link></li>
            <li><Link className="hover:text-iau-gold" href="/calendar">{tn("calendar")}</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="mb-3 border-b border-iau-gold pb-2 text-base font-bold">
            {t("contact")}
          </h3>
          <ul className="space-y-2 text-sm opacity-90">
            <li>{tc("university")}</li>
            <li>{t("location")}</li>
            <li>{t("faq")}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/15">
        <p className="mx-auto max-w-7xl px-4 py-4 text-center text-xs opacity-80">
          {t("copyright", { year })} — {t("rights")}
        </p>
      </div>
    </footer>
  );
}
```

- [ ] **Step 2: Render in `src/app/[locale]/layout.tsx`** (below children)

```tsx
import SiteFooter from "@/components/layout/SiteFooter";
// ...
<NextIntlClientProvider>
  <SiteHeader />
  {children}
  <SiteFooter />
</NextIntlClientProvider>
```

- [ ] **Step 3: Verify**

`npm run dev` — footer shows 3 columns desktop / stacked mobile, correct in both locales, columns mirror in AR. Stop server.

- [ ] **Step 4: Commit**

```bash
git add -A
git commit -m "feat: IAU-style footer"
```

---

### Task 7: Placeholder routes for all public pages

**Files:**
- Create: `src/app/[locale]/strategic-plan/page.tsx`, `src/app/[locale]/requirements/page.tsx`, `src/app/[locale]/calendar/page.tsx`, `src/app/[locale]/signup/page.tsx`, `src/app/[locale]/login/page.tsx`

**Interfaces:**
- Consumes: `pages.*` messages.
- Produces: working routes `/strategic-plan`, `/requirements`, `/calendar`, `/signup`, `/login` (per locale) that Phases 2–3 replace with real content.

- [ ] **Step 1: Create the five placeholder pages** — identical pattern, different title key. Example `src/app/[locale]/strategic-plan/page.tsx`:

```tsx
import { useTranslations } from "next-intl";

export default function StrategicPlanPage() {
  const t = useTranslations("pages");
  return (
    <main className="mx-auto min-h-[50vh] max-w-7xl px-4 py-12">
      <h1 className="mb-4 text-3xl font-bold text-iau-green">
        {t("strategicPlanTitle")}
      </h1>
      <p className="text-gray-600">{t("comingSoon")}</p>
    </main>
  );
}
```

Repeat for the other four files with title keys `requirementsTitle`, `calendarTitle`, `signupTitle`, `loginTitle` and component names `RequirementsPage`, `CalendarPage`, `SignupPage`, `LoginPage`.

- [ ] **Step 2: Verify every nav item works**

`npm run dev` — click all 6 nav items in EN and AR; each renders its translated title, no 404s. Stop server.

- [ ] **Step 3: Full check — lint, tests, build**

```bash
npm run lint && npm test && npm run build
```

Expected: lint clean, 5 tests pass, production build succeeds for both locales.

- [ ] **Step 4: Commit**

```bash
git add -A
git commit -m "feat: placeholder routes for all public pages"
```

---

**Phase 1 exit criteria:** `npm run build` green; site renders bilingual with RTL; header/footer on every page; all six nav destinations resolve; tokens + fonts in place. → Phase 2 (public site content) gets its own plan.
