# Phase 2: Public Site Content Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the placeholder public pages with real content: home page (hero, strategy frames, moving event cards), strategic plan page (+ PDF viewer), event request requirements page, and events calendar — all bilingual EN/AR.

**Architecture:** Static content lives in the message catalogs (EN/AR). Structured content (focus areas, requirements lists, demo events) lives in typed data modules under `src/lib/`. Events are demo data until the Supabase phase replaces the source; every consumer imports the `EventItem` type so the swap is invisible. Work on branch `phase-2-public-site`.

**Tech Stack:** Existing Phase 1 stack. No new dependencies except copying the strategic-plan PDF asset.

## Global Constraints (from spec)

- Bilingual EN + AR with correct RTL on every page.
- IAU palette (green/white) for public pages; tokens verified against live iau.edu.sa during Task 1.
- Hero: IAU building photo. Until the user supplies one, use `public/images/hero-campus.jpg` if present, else a token-based gradient fallback. Ask the user for a photo at phase review.
- Event cards must show: name, place, date, time, type, college.
- Marquee moves right-to-left, pauses on hover.
- The exact hero tagline (EN): "Empowering Innovation, Fueling Entrepreneurship" / "The premier hub for programs and events at IAU — shaping the future of Saudi innovation".

## Source content (extracted this session — authoritative)

**Vision (AR, verbatim from plan p.9):** جامعة رائدة في تحويل الاكتشافات العلمية إلى ابتكارات عملية ذات أثر مجتمعي ملموس وقابل للقياس.
**Vision (EN):** A leading university in transforming scientific discoveries into practical innovations with tangible, measurable societal impact.

**Mission (AR, verbatim):** إنشاء منظومة بحثية متكاملة تركز على الصحة وجودة الحياة، من خلال توحيد الجهود البحثية متعددة التخصصات، وتطوير الكوادر البحثية المتميزة، وبناء شراكات استراتيجية تضمن تحويل المعرفة العلمية إلى حلول مؤثرة تخدم المجتمع.
**Mission (EN):** Establishing an integrated research ecosystem focused on health and quality of life — unifying multidisciplinary research efforts, developing distinguished research talent, and building strategic partnerships that transform scientific knowledge into impactful solutions serving society.

**Strategic alignment (plan p.10):** Saudi Vision 2030 · Research, Development and Innovation Authority (RDIA) priorities · Saudi Data & AI Authority (SDAIA) · Priorities of related national entities (Ministries of Environment/Water/Agriculture, Culture, Communications & IT, Industry & Mineral Resources, Education, Tourism, Energy) · UN Sustainable Development Goals (strategy aligned with 11 of the 17 SDGs).

**Strategic framework numbers (plan p.21):** 3 national focus areas → 7 national priorities → 10 grand challenges → 29 innovation goals, organized into 6 strategic pillars.

**6 focus areas + goals:** already stored verbatim in the spec §6.5 — reuse from `docs/superpowers/specs/2026-07-15-iau-event-management-website-design.md`.

**Requirements page content:** governance guide §3 (6 principles) and §4 (7 pre-activity requirements) — from the spec's source extraction (gov_guide.txt lines 80–94).

---

### Task 1: Brand check + assets + content data module

**Files:**
- Create: `public/documents/strategic-plan.pdf` (copied from COOP Project folder)
- Create: `src/lib/content.ts` (focus areas, alignment items, requirements — typed, with EN/AR strings)
- Modify: `src/app/globals.css` (only if live-site sampling shows the green is off)

**Interfaces:**
- Produces: `FOCUS_AREAS: FocusArea[]` (`{id, icon, en, ar, goals: {en, ar}[]}`), `ALIGNMENT_ITEMS`, `GOV_PRINCIPLES`, `PRE_SUBMISSION_REQUIREMENTS` — all bilingual arrays consumed by later tasks; `/documents/strategic-plan.pdf` URL.

**Steps:**
- [ ] Copy the strategic plan PDF into `public/documents/strategic-plan.pdf` (~28 MB; git-tracked, acceptable for now).
- [ ] Visit https://www.iau.edu.sa/en in the browser; sample header green + footer green via computed styles; update `--color-iau-*` tokens only if visibly different.
- [ ] Write `src/lib/content.ts` with the typed bilingual arrays (content from "Source content" above + spec §6.5).
- [ ] `npm test` still green; commit `feat: brand assets and bilingual content data`.

### Task 2: Demo events module (typed, swap-ready)

**Files:**
- Create: `src/lib/events-data.ts`, `src/lib/events-data.test.ts`

**Interfaces:**
- Produces: `type EventItem = { id: string; name: {en,ar}; place: {en,ar}; date: string (ISO); startTime: string; endTime: string; type: {en,ar}; college: {en,ar}; status: "ongoing" | "upcoming" }` and `DEMO_EVENTS: EventItem[]` (8–10 realistic IIE events spanning current & next months) plus helpers `getEventsForMonth(year, month)`, `getOngoingAndUpcoming()`.
- **Swap contract:** Phase 6 replaces DEMO_EVENTS with a Supabase query returning the same shape.

**Steps:**
- [ ] TDD: failing tests for `getEventsForMonth` (filters by year+month) and `getOngoingAndUpcoming` (sorted by date, no past events).
- [ ] Implement module; tests green; commit `feat: demo events data module`.

### Task 3: Home page

**Files:**
- Create: `src/components/home/Hero.tsx`, `src/components/home/StrategySection.tsx`, `src/components/events/EventCard.tsx`, `src/components/events/EventsMarquee.tsx`
- Modify: `src/app/[locale]/page.tsx`, `messages/en.json`, `messages/ar.json`, `src/app/globals.css` (marquee keyframes)

**Interfaces:**
- Consumes: `content.ts` arrays, `events-data.ts`, existing tokens.
- Produces: `<EventCard event={EventItem} />` and `<EventsMarquee events={EventItem[]} />` — reused verbatim on the calendar page (Task 6) and admin dashboard (Phase 6).

**Layout (top→bottom):** Hero (full-width, building image or gradient fallback + tagline + "Submit event request" button linking `/request` — route exists Phase 4, links to `/login` for now) → Vision & Mission frame (two cards) → Strategic Goals frame (framework numbers strip + 6 focus-area cards with expandable goals) → Strategic Alignment frame (5 alignment items) → "Ongoing & upcoming events" marquee → footer.

**Marquee spec:** CSS `@keyframes marquee { from {transform: translateX(0)} to {transform: translateX(-50%)} }`, duplicated card list for seamless loop, `animation-play-state: paused` on hover, `animation-direction` respects RTL (in RTL the visual direction stays right-to-left as specified), `prefers-reduced-motion: reduce` → static scrollable row.

**Steps:**
- [ ] Add all new message keys (both catalogs; parity test enforces).
- [ ] Build EventCard (name, place, date, time, type, college — localized, date via `Intl.DateTimeFormat(locale)`).
- [ ] Build EventsMarquee with the spec above.
- [ ] Build Hero + StrategySection; assemble page.
- [ ] Verify EN + AR rendering, RTL mirroring, mobile layout in browser; `npm test && npm run build`; commit `feat: home page with hero, strategy frames, events marquee`.

### Task 4: Strategic Plan page

**Files:**
- Modify: `src/app/[locale]/strategic-plan/page.tsx`, message catalogs

**Content sections:** header with **"View strategic plan document"** button (opens `/documents/strategic-plan.pdf` in new tab) → Vision & Mission → National & International Alignment (5 items) → Strategic Goals (framework numbers + 6 focus areas with all goals listed).

**Steps:**
- [ ] Implement page reusing StrategySection pieces where sensible.
- [ ] Verify EN/AR + PDF opens; commit `feat: strategic plan page`.

### Task 5: Event Request Requirements page

**Files:**
- Modify: `src/app/[locale]/requirements/page.tsx`, message catalogs

**Content:** Two blocks from the governance guide — "Pre-Activity Submission Requirements" (7 numbered items, highlight the 3-working-week lead time and the 5-working-day final-report deadline) and "Principles of Governance and Approval" (6 principles). End with a callout: approval must be obtained before any implementation, announcement, or expenditure + CTA button to submit a request.

**Steps:**
- [ ] Implement from `GOV_PRINCIPLES` / `PRE_SUBMISSION_REQUIREMENTS` data.
- [ ] Verify EN/AR; commit `feat: event request requirements page`.

### Task 6: Events Calendar page

**Files:**
- Create: `src/components/events/MonthCalendar.tsx`, `src/lib/calendar.ts`, `src/lib/calendar.test.ts`
- Modify: `src/app/[locale]/calendar/page.tsx`, message catalogs

**Interfaces:**
- Produces: `buildMonthGrid(year, month): { date: string; inMonth: boolean }[][]` (pure, tested — weeks × 7 days, weeks start Sunday); `<MonthCalendar year month events onPrev onNext />` client component; calendar page = current month by default, prev/next month navigation unbounded (past + future), events shown as chips in day cells; below the grid, the same `<EventsMarquee />` from Task 3.
- RTL: grid order flips automatically via logical properties; day names localized via `Intl`.

**Steps:**
- [ ] TDD `buildMonthGrid` (Feb leap year, month starting Sunday, 6-week month).
- [ ] Build MonthCalendar + page wiring (client state for displayed month).
- [ ] Verify EN/AR, chip rendering for demo events, prev/next including past months; commit `feat: events calendar page`.

### Task 7: Full check + merge

**Steps:**
- [ ] `npm run lint && npm test && npm run build` — all green.
- [ ] Browser pass: every nav item EN + AR, mobile viewport spot-check, marquee pauses on hover.
- [ ] Merge `phase-2-public-site` → `main`, delete branch.

**Phase 2 exit criteria:** public site fully browsable with real content in both languages; calendar navigable across months; PDF accessible; build green. → Phase 3 (auth) next.
