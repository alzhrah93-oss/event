# Phase 7: Super Admin Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans.

**Goal:** Super admin "Admins" section: list admins, add a new admin (with initial password), delete an admin, and control each admin's per-section permissions — with DB-level enforcement.

**Architecture:** Two security-definer Postgres functions guarded by `is_super_admin()`: `create_admin(email, password, name)` (auth user + identity + role promotion, default permissions) and `delete_admin(target)` (admins only, never super admins/organizers). Permission model on `profiles.permissions` jsonb: `requests: view|approve`, `reports: view|none`, `analytics: view|none`. Defense in depth: the `admins update requests` RLS policy now requires `requests=approve` (via `has_permission()` helper); the UI hides the DecisionPanel without it and `/admin/reports` redirects without `reports=view`. UI at `/admin/admins` (super_admin-guarded): admin cards with permission selects + save, add-admin form, delete with confirm. Branch `phase-7-super-admin`.

## Tasks
1. Migration `admin_management`: `has_permission()`, tightened update policy, default permissions backfill, `create_admin`, `delete_admin` (+ repo copy).
2. Permissions metadata module (TDD): sections/levels, `canApprove(profile)`, `canViewReports(profile)` used by UI + actions.
3. Server actions: `createAdmin`, `deleteAdmin`, `updateAdminPermissions` (all re-checked super_admin server-side; createAdmin validates email/password strength).
4. `/admin/admins` page + AdminCard client component; wire super-admin dashboard card; hide DecisionPanel + guard reports page by permission; reviewRequest action checks `canApprove`.
5. Messages EN/AR (`admins` namespace).
6. E2E verify: rpc create_admin → new admin logs in; permissions downgraded to view → PATCH on a real request blocked by RLS; delete_admin → login dead; negatives (admin calling create_admin fails). Cleanup, gate, merge.

**Exit criteria:** super admin manages admins and their permissions from the UI; a view-only admin cannot decide requests even via direct API; deleted admins lose access immediately.
