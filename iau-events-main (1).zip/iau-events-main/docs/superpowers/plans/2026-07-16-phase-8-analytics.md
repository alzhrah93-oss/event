# Phase 8: Analytics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans.

**Goal:** /admin/analytics (gated by analytics permission): stat tiles + charts for requests/events per month, approved vs not approved, entity leaders, status & focus-area distributions, report compliance — with a year switcher.

**Architecture:** Server page fetches minimal columns (admin RLS) and aggregates in pure TDD-tested functions (src/lib/analytics/aggregate.ts). Recharts client components with dataviz-skill specs: thin rounded bars, 2px gaps, recessive grid, tooltips, legend only on the 2-series chart, direct labels selective. Palette validated by script: single-series #1B8354; approved/not_approved status pair #1B8354/#DC2626 (icons+labels, not color alone). Numbers stay LTR inside localized layout. Empty state per year.

Tasks: 1) aggregate.ts TDD · 2) npm i recharts + chart components · 3) messages EN/AR · 4) page + year switcher + dashboard card wiring + permission gate · 5) gate/verify/merge.
