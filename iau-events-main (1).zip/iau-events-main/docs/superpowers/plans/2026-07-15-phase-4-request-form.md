# Phase 4: Event Request Form Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans. Checkbox steps.

**Goal:** The complete governance-guide event request form: 8 wizard steps with conditional sections, focus-area goal selection, 3-working-week rule, attachments upload, declaration gate, auto request number, and submission pipeline — login-gated at `/request`.

**Architecture:** DB-first: `event_requests` (all form fields as columns + jsonb for lists/tables), `request_alignment`, `request_status_history`, `attachments` + private storage bucket, all with owner/admin RLS. Request numbers `REQ-YYYY-NNNN` from a per-year Postgres sequence function. Form = client wizard (one component per step) with a `useRequestForm` reducer, localStorage draft autosave, on-blur validation; submission via a server action that validates everything server-side, inserts, uploads attachments to storage, writes history, and shows a success page with the request number. UX per ui-ux-pro-max: step indicator, inline errors (`role=alert`), asterisk required markers, loading→success feedback; motion per emil-design-eng (<300ms, ease-out, goal-in cascades for conditional reveals). Branch `phase-4-request-form`.

## Global Constraints
- Form sections/fields exactly as spec §6 (governance guide merged with condensed form; duplicates once).
- 6 focus areas → their goals multi-select (data already in `src/lib/content.ts` FOCUS_AREAS).
- Activity date ≥ 3 **working weeks** (15 working days, Sun–Thu KSA week) from today — enforced client AND server (pure function `workingDaysBetween`, TDD).
- Submit disabled until required fields valid + declaration checked; server re-validates.
- Auto: request_number, submitted_at; status starts `new`.
- Attachments: approved letter (required), agenda, participants list, invitation letter, profile deck, IP docs; PDF/DOC/DOCX/PPT/PPTX/PNG/JPG, ≤10 MB each; private bucket `request-attachments`, path `{request_id}/{kind}-{filename}`.
- Bilingual EN/AR + RTL; all dropdown options from the guide's Appendix A.

## Tasks

### T1: Schema migration `event_requests`
Tables (+ repo SQL copy in `supabase/migrations/`):
- `event_requests`: id uuid pk default gen_random_uuid(), request_number text unique, organizer_id → profiles, status request_status enum (new, pending_completion, under_review, approved, not_approved, cancelled, closed) default 'new';
  §1 applicant: organizing_entity, applicant_name, job_title, university_email, mobile, alt_coordinator;
  §2 activity: request_types text[], title, description, activity_date date, start_time, end_time, target_audience text[], expected_attendance int, activity_format;
  §3 venue: venue, external_host, city_country, location_details, external_participation_type, represents_university bool;
  §4 participants: has_students bool, student_count int, has_faculty bool, faculty_count int, has_partners bool;
  §5 partners jsonb (name, type, has_mou, mou_ref, has_obligation, obligation_note);
  §6 alignment: sdgs text[], expected_outputs text[], impact_indicators text, followup_pathways text[];
  §7 IP: presents_ip (yes/no/unsure), ip_disclosed bool, ip_prototype bool, ip_patent text, ip_unpublished bool, ip_nda text;
  §8 budget: needs_funding bool, funding_source, budget_items jsonb[], needs_labs bool, labs_details, needs_materials bool, materials_details, needs_media bool;
  admin: reviewer_id, institute_notes, decision_reason, decided_at, cancelled_at, submitted_at default now(), created_at.
- `request_alignment`: request_id, focus_area_id text, goals text[] (per selected area).
- `request_status_history`: id, request_id, from_status, to_status, actor_id, note, created_at.
- `attachments`: id, request_id, kind, file_name, storage_path, uploaded_by, created_at.
- `generate_request_number()` trigger: `REQ-<year>-<lpad(count+1)>` using an advisory-locked per-year counter table `request_counters(year int pk, n int)`.
- RLS: organizer full select own + insert own (status='new' only); admins select all + update status fields; history/attachments follow parent. Storage bucket `request-attachments` private; policies: owner upload/read own prefix, admins read all.
- Verify via list_tables + test insert/rollback. Commit.

### T2: Pure logic (TDD): working days + request form validation
- `src/lib/requests/working-days.ts`: `addWorkingDays(startIso, n)`, `isAtLeastWorkingDaysAhead(dateIso, n, todayIso)` with KSA weekend (Fri/Sat). Tests: crosses weekends, exact boundary, today edge.
- `src/lib/requests/validate.ts`: `validateRequestStep(step, data)` + `validateRequestFull(data)` returning code-based errors incl. conditional requirements (off-campus → host/city; students → count; partners → partner fields; funding → source; declaration). Tests for each conditional branch. Commit.

### T3: Form state + wizard shell
- `src/lib/requests/types.ts` RequestFormData (mirrors schema, camelCase).
- `src/components/request/useRequestForm.ts`: reducer + localStorage draft (key per user id), hydrate/clear helpers.
- `src/components/request/Wizard.tsx`: step indicator (numbered, named, "Step n of 8", completed steps clickable), Prev/Next with per-step validation gate, `role=alert` error summary, goal-in transition between steps, RTL-aware.
- Steps enum: 1 Applicant · 2 Activity · 3 Venue · 4 Participants+Partners · 5 Alignment · 6 IP (conditional-visible always but content conditionally required) · 7 Budget · 8 Attachments+Declaration+Review.
- Commit after wizard renders with step 1.

### T4: Step components (2 commits: steps 1–4, steps 5–8)
- Shared inputs: `LabeledInput`, `LabeledSelect`, `MultiSelect` (checkbox chips), `YesNo` (segmented), `DateField` (min = today+15 working days hint), `FileField` (type/size client checks). Required asterisks; on-blur validation; errors inline.
- Conditional reveals animate with existing `.goal-item` cascade.
- Step 5 embeds FOCUS_AREAS picker: select areas → goals multi-select per area (same interaction as home page).
- Step 8: attachment slots, declaration checkbox with acknowledgment text (guide Appendix B), review summary of key fields, Submit button (disabled until valid + declared).

### T5: Submission pipeline
- Server action `submitRequest(formData)`: auth check (organizer), server-side `validateRequestFull`, working-days re-check, insert request (returns request_number via trigger), insert alignment rows, upload files to storage, insert attachments rows, insert history (null→new), redirect to `/request/success?rn=...` page showing the number + email-notice placeholder (emails Phase 9).
- Failure paths: validation errors re-rendered; storage failure → request marked pending_completion note? No — upload BEFORE insert is impossible (need id); use transaction-ish order: insert request → uploads → on upload failure, delete request and report error.
- Hero + requirements CTAs switch from `/login` to `/request` (guard redirects anonymous users to login automatically).
- Commit.

### T6: Verification + audit + merge
- **verification skill:** E2E in browser as organizer seed: fill full form (incl. conditional branches), upload sample PDF, submit, confirm success page + DB rows (SQL check) + storage object.
- Negative: date < 3 working weeks blocked; declaration unchecked blocks; anonymous → login redirect.
- **web-design-guidelines audit** of the form pages; fix findings.
- lint + tests + build; AR/RTL pass; merge to main.

**Exit criteria:** an organizer can submit a complete governance-compliant request end-to-end; request appears in DB with number `REQ-2026-0001`, history row, attachment in storage; all rules enforced both sides; build green.
