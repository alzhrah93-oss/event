# Phase 5: Organizer Dashboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans.

**Goal:** Organizer request tracking (progress line + status + rejection reason), cancel-while-under-review, and the final report form that closes a request.

**Architecture:** New `final_reports` table (one per request) + RLS additions: organizers may UPDATE their own request only to `cancelled` while it's still reviewable; a DB trigger closes the request when a final report is inserted. UI: `/dashboard/requests` list → `/dashboard/requests/[id]` detail (ProgressTracker + StatusBadge + actions) → `/dashboard/requests/[id]/report` form. White-first design per the saved direction. Branch `phase-5-organizer-dashboard`.

## Tasks
1. **Migration `final_reports_and_cancel`** — table per guide §11 (implementation_summary, actual_date, actual_location, actual_attendance, student_count, ideas_received, projects_nominated + desc, partnerships, satisfaction, actual_budget jsonb, submitted_at); organizer-cancel RLS policy (new/pending_completion/under_review → cancelled only); `close_request_on_report` trigger (status→closed + history); repo SQL copy.
2. **Status meta (TDD)** — `src/lib/requests/status.ts`: badge color/token per status, progress-step mapping (submitted → review → decision → closed), `isCancellable`, `canSubmitReport(status, activityDate, hasReport)`. Unit tests.
3. **Organizer data reads** — server queries: list own requests (number, title, date, status), request detail + history + report existence.
4. **UI** — StatusBadge, ProgressTracker (4 nodes, RTL-aware, colored fill to current stage), requests list page, request detail (summary of key fields, tracker, decision_reason when not_approved, Cancel with confirm, report CTA when eligible), final report form + `submitFinalReport` action (validation + uploads to `{request_id}/report-*` + attachments rows) → success back to detail showing Closed.
5. **Dashboard wiring** — organizer dashboard cards link to real routes with live counts.
6. **Messages EN/AR** (shared `status` namespace reused by admin phase) — parity test guards.
7. **Verification + merge** — data-layer E2E (disposable organizer: submit → cancel path; second request → approve via SQL → report → closed), negative RLS checks, lint/test/build, merge.

**Exit criteria:** organizer sees live statuses with tracker; can cancel while reviewable (with auto cancelled_at + history); can submit the final report for an approved past event which closes it; all enforced by RLS.
