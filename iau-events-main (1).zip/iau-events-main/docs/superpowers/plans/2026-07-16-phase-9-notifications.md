# Phase 9: Notifications Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans.

**Goal:** In-app notification bell + emails for the organizer lifecycle (submitted, approved, not approved with reason, cancelled, final report received) and an overdue-report reminder endpoint.

**Architecture:** `notifications` table stores `type` + `data` jsonb (bilingual rendering happens at display time from message catalogs — language switching just works). DB triggers insert notifications on request insert, status change, and final-report insert — no RLS gymnastics, fires for every entry point. Emails: `src/lib/email.ts` calls the Resend REST API via fetch (no SDK); without `RESEND_API_KEY` it logs and skips. Wired fire-and-forget into the four server actions. Reminder: `GET /api/cron/report-reminders` guarded by `CRON_SECRET`, inserts reminder notifications + emails for approved-ended-unreported requests (deduped, 3-day cooldown); Vercel Cron wiring happens at deploy. Bell: client component in the header (browser Supabase client), unread badge, dropdown list, mark-read on open. Branch `phase-9-notifications`.

Tasks: 1) migration (table + RLS + 3 triggers) · 2) email lib + action wiring + cron route · 3) bell UI + messages EN/AR · 4) E2E (trigger rows on submit/approve/reject/cancel/report; RLS isolation), gate, merge.
