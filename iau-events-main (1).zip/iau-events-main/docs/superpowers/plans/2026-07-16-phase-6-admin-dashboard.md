# Phase 6: Admin Dashboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:executing-plans.

**Goal:** Admin review workflow: request queue with full detail + approve/not-approve (mandatory reason) + intermediate statuses, cancelled requests list, final reports section (submitted vs missing + counts), and the public calendar/marquee switched to REAL approved events.

**Architecture:** Admin RLS update policies already exist. New server action `reviewRequest` (admin-guarded; decision → status + decision_reason/institute_notes + history; decided_at via existing trigger). Detail page renders every form section via a definition-list renderer that maps stored values back to localized option labels (`src/lib/requests/display.ts`, unit-tested). Attachments downloadable via short-lived signed URLs. `src/lib/events-server.ts` maps approved/closed requests to `EventItem` for the public calendar + marquee (falls back to demo data only when the database has no approved events, so the public site never looks empty). Motion per saved vocabulary; BackLink everywhere. Branch `phase-6-admin-dashboard`.

## Tasks
1. **Messages** — `admin` namespace EN/AR: queue headers/filters, detail section titles, decision panel (approve/notApprove/underReview/pendingCompletion, reason required, notes), cancelled list, reports tabs + counts + "not submitted" message. Parity test guards.
2. **Display mapping (TDD)** — `optionLabel(list, value, locale)`, `labelsFor(list, values[])`, boolean/date/time formatters. Tests for option lookup incl. unknown values (fallback to raw).
3. **Events from DB** — `getPublicEvents()` (approved+closed → EventItem, demo fallback), wire home + calendar pages. Unit test for the row→EventItem mapper.
4. **Review action** — `reviewRequest(requestId, decision, reason?, notes?)`: admin guard (profile role via getSessionProfile), reject requires reason, transitions allowed from new/pending_completion/under_review (approve/reject) and any-reviewable → intermediate; history row; revalidate.
5. **Admin pages** — `/admin/requests` (status filter chips + table, row-in stagger) → `/admin/requests/[id]` (all sections + attachments signed links + history timeline + DecisionPanel client component) · `/admin/cancelled` (list → same detail read-only) · `/admin/reports` (submitted/missing tabs with counts → report view or event info + not-submitted notice). Admin dashboard cards wired with live counts.
6. **Verification + merge** — E2E: seed organizer + request via REST; admin (REST token as seeded admin) PATCHes status approve → decided_at + calendar shows event; reject path with reason; RLS negative (organizer can't set institute_notes); reports counts correct. lint/tests/build, merge.

**Exit criteria:** admin reviews and decides with mandatory reasons; organizer sees the decision + reason; approved events appear on the public calendar; reports section counts submitted vs missing; all admin routes guarded.
