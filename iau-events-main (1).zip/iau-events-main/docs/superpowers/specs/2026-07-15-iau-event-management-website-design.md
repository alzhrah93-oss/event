# IAU Event Management Website — Design Spec

**Date:** 2026-07-15
**Client:** Institute of Innovation and Entrepreneurship (IIE), Imam Abdulrahman bin Faisal University (IAU)
**Deliverable:** A complete, functional, bilingual **website** (not a mobile app — pages served at a URL, opened in any browser on any device) for managing entrepreneurial and innovation event requests: submission, review, approval, calendar, final reports, notifications, and analytics.

**Source documents (authoritative for content and workflow):**
- `IAU_Governance_Guide_English_Translation.docx` — governance workflow, full form structure, statuses, final report fields, dropdown lists, acknowledgment text
- `Governance_Form_Entrepreneurial_and_Innovative_Programs_and_Events_EN.docx` — condensed form (merged with the guide's form; duplicated questions appear once)
- `الخطة الاستراتيجية -وكالة البحث العلمي والابتكار(strategic plan).pdf` — strategic vision, mission, goals, national/international alignment (content extracted + translated; user confirms English drafts)
- User-provided: 6 focus areas with their goals (verbatim in §6.5)
- Reference images `a1–a10.jpeg` and https://www.iau.edu.sa/en for visual design

---

## 1. Architecture & Stack

| Layer | Choice |
|---|---|
| Framework | Next.js (App Router) + React + TypeScript + Tailwind CSS — one codebase for frontend + backend |
| Database | Supabase Postgres with Row-Level Security (RLS) |
| Auth | Supabase Auth (email/password + password reset) |
| File storage | Supabase Storage (request attachments, final-report uploads) |
| Email | Resend + React Email templates (user adds the API key; code ships ready) |
| In-app notifications | `notifications` table + bell/badge in dashboard header |
| Scheduled reminders | Vercel Cron — daily job finds ended events missing final reports |
| i18n | next-intl — full EN/AR catalogs, `dir="rtl"` for Arabic |
| Charts | Recharts (analytics dashboard) |
| Deployment | GitHub repo → Vercel auto-deploy; Supabase cloud project |

**Decisions confirmed by user:**
- Notifications: **both** in-app and real email from the start
- Language: **full bilingual EN + AR with RTL** on every page, form, dashboard, and email
- Framework: Next.js full-stack
- Delivery: phased local build → live deployment at the end
- Product is a **website** — no installation, no app store

## 2. Actors & Access Control

| Role | Capabilities |
|---|---|
| **Visitor** (not logged in) | Public pages: home, strategic plan, requirements, events calendar, sign up, log in. Clicking "Submit event request" redirects to login. |
| **Organizer** (user) | Self sign-up. Submit event requests, track status, cancel a request under review, submit final report after the event. |
| **Admin** | Review requests (approve / not approve with mandatory reason), events calendar, cancelled requests, final reports, analytics. Actions gated by per-admin permissions. |
| **Super admin** | Everything an admin has + **Admins** panel: add/remove admins, set each admin's permissions (view / edit / approve per section). |

**Roles storage:** `profiles.role` ∈ {`organizer`, `admin`, `super_admin`}; admin permissions in `profiles.permissions` (jsonb, e.g. `{"requests": "approve", "reports": "view", "analytics": "view"}`). RLS policies enforce every rule at the database layer, not only in UI.

**Seed accounts** (created directly in the live Supabase project during deployment — never committed to the repo):
- Super admin: `superadmin@iau.edu.sa` / `Sa12342026`
- Admin: `admin1@iau.edu.sa` / `Admin2026`
- Organizer: `organizer1@iau.edu.sa` / `Organizer2026`

## 3. Data Model (Supabase Postgres)

- **profiles** — `id` (FK → auth.users), full_name, national_id (national ID / iqama), email, phone, role, permissions (jsonb, admins only), created_at
- **event_requests** — id, `request_number` (auto-generated, unique, human-readable e.g. `REQ-2026-0001`), organizer_id → profiles, all form fields (§6), `status` ∈ {new, pending_completion, under_review, approved, not_approved, cancelled, closed}, `submitted_at` (auto), `decided_at` (auto on approve/reject), `decision_reason` (required when not approved), `cancelled_at` (auto), reviewer_id, institute_notes
- **request_strategic_alignment** — request_id, focus_area (1–6), goal keys (multi-select array)
- **request_status_history** — request_id, from_status, to_status, actor_id, note, created_at — drives the organizer progress tracker
- **attachments** — id, request_id or final_report_id, kind (approved_letter / agenda / participants_list / invitation_letter / profile_deck / ip_document / report_evidence …), storage_path, uploaded_by, created_at
- **final_reports** — id, request_id (unique), all report fields (§8), `submitted_at` (auto)
- **notifications** — id, user_id, type, title/body (both languages), request_id, read, created_at

Calendar and analytics **derive** from `event_requests` (status = approved / closed) — no duplicated event data.

All dates (submission, decision, cancellation, report submission) are set automatically server-side. Request numbers are auto-generated server-side (sequence per year).

## 4. Public Website (bilingual EN/AR)

### 4.1 Global chrome
- **Top utility bar** (IAU style): search bar + English/Arabic switch button.
- **Main nav:** IAU logo left; clickable items right: **Home, Sign up, Log in, Strategic Plan, Event Request Requirements, Events Calendar**. When logged in, "Sign up / Log in" is replaced by the user's name → dashboard link + log out.
- **Footer:** modeled on the official IAU website footer (link columns, contact info, social icons, copyright), in IAU green.

### 4.2 Home page (top → bottom)
1. **Hero frame:** background photo of an IAU University building; overlay text: *"Empowering Innovation, Fueling Entrepreneurship — The premier hub for programs and events at IAU — shaping the future of Saudi innovation"*; button **"Submit event request"**.
2. **Strategic Vision & Mission** frame
3. **Strategic Goals** frame
4. **Strategic Alignment** frame (national & international alignment)
   — content for 2–4 extracted from the strategic plan PDF and translated; user confirms English wording.
5. **Ongoing & upcoming events marquee:** cards auto-scrolling right-to-left; each card shows event **name, place, date, time, type, college**. Pauses on hover.
6. Footer.

### 4.3 Strategic Plan page
Sections: Strategic Vision and Mission · National & International Alignment · Strategic Goals. Button at top: **"View strategic plan document"** → opens the strategic plan PDF (stored in the site's public assets / Supabase Storage) in a viewer.

### 4.4 Event Request Requirements page
Two content blocks straight from the governance guide: **Pre-Activity Submission Requirements** (7 items, incl. the 3-working-week lead time and 5-day final-report deadline) and **Principles of Governance and Approval** (6 principles).

### 4.5 Events Calendar page
- Month-grid calendar showing approved (booked) ongoing and upcoming events; defaults to the current month; prev/next navigation to any past or future month.
- Below the calendar: the same right-to-left moving event cards as the home page.

## 5. Authentication Pages

### 5.1 Sign up (Create account)
Fields: name, national ID / iqama, email, phone number, password, confirm password → button **"Create account"**. Validations: matching passwords, password strength, valid email/phone, unique email. Creates an **organizer** profile.

### 5.2 Log in (Blackboard-style)
Layout mimics IAU Blackboard: university photo on the left; on the right two options — **Administrator login** and **Organizer login** — with **"Forgot password?"** underneath (Supabase reset-password email flow). Either option → email + password form. Color language: yellow + blue shades (per Blackboard), distinct from the green public site.
- After organizer login → organizer dashboard. After admin/super-admin login → admin dashboard.
- Role mismatch (e.g. organizer using admin login) → clear error.

## 6. Event Request Form (login-gated)

Reached from the hero button (or dashboard). **If not logged in → redirect to login, then return to the form.** Multi-section form implementing the governance guide's "Detailed Electronic Request Form" merged with the condensed form document (duplicates appear once):

1. **Applicant & Entity Information** — Organizing entity (dropdown: College / Deanship / Institute / Center / Administration / Student Club / Other) · Applicant name · Job title/capacity · University email · Mobile number · Alternate coordinator name (optional)
2. **Activity Information** — Request type (multi-select: Event / Workshop / Initiative / Competition / Program / Judging / Partnership / Forum / Conference / Exhibition / Disclosure of an idea or project / External participation / Training / Student nomination / Other) · Activity title · Brief description (150–300 words) · Activity date (**must be ≥ 3 working weeks ahead; enforced**) · Start & end time · Target audience (multi-select) · Expected attendance (number) · Activity format (In-person / Virtual / Hybrid)
3. **Venue & External Participation** — Implementation venue (On campus / Off campus / Virtual). *Conditional (off campus):* external host name, city & country, activity location, external participation type (dropdown). · "Does the activity officially represent the University?" (Yes/No; Yes → nomination/approval letter required)
4. **Participants** — Students participating? (Yes → number, names/IDs attachment) · Faculty participating? (Yes → number) · External partners? (Yes → §5)
5. **Partners** *(conditional)* — Partner organization name · Partnership type (dropdown) · MoU/agreement? (Yes → attach copy or number) · Financial/media obligation? (Yes → explain)
6. **Strategic Alignment** — pick 1+ of the **6 focus areas**; selecting an area reveals its goals for multi-select (verbatim list below) · SDG multi-select · Expected outputs (multi-select from guide's list) · Impact indicators (target numbers/text) · Post-activity follow-up pathway (multi-select)
7. **Intellectual Property** *(conditional if activity presents ideas/projects/prototypes)* — the guide's 6 IP questions (protectable idea? previously disclosed? prototype? patent application? unpublished data? NDA needed?)
8. **Budget & Support** *(conditional if financial support requested)* — funding source dropdown · budget items table (item, description, estimated cost SAR, funding source, justification) · labs/facilities operation? · materials/equipment? · media coverage?
9. **Attachments** — Approved letter from organizing entity (**required**) · Activity program/agenda · participants list, invitation letter, profile deck, IP documents (conditional/optional per guide)
10. **Declaration** — the guide's acknowledgment text with a **required checkbox**.

**Submission rules:** "Submit request" disabled until all required fields valid + declaration checked. On submit: request_number + submitted_at auto-generated; status = **New**; in-app + email confirmation with the request ID.

### 6.5 Focus areas & goals (verbatim)
1. **Health and Wellness** — Reducing Musculoskeletal Disorders · Reducing KSA Obesity · Reducing Vector-Borne Disease · Reducing Prevalence of Depression
2. **Energy & Industrials** — Improving Efficiency of Energy Storage Systems · Reducing the Cost of Hydrogen Storage · Recycling Polymer Waste · Recycle of Glass and Battery Waste · Increase the Use of Recycled Waste · Develop Solutions to Reduce Industrial Energy Waste
3. **Economies of the Future** — Reducing Energy Consumption in Water Systems · Reducing Post-Surgery Recovery Time · Developing Smart Supply Chain System · Governance & Regulation of Therapeutics Procedures
4. **Sustainability and Essential Needs** — Develop Integrated CCS Strategy · Achieving Net-Zero/Net-Positive Energy Status · Utilize Waste Materials for Value-Added Applications · Developing Advanced Chemicals or Membranes · Implement Cooling Technology Using Renewable Energy
5. **AI Education** — Improving Student Career Decisions · AI-Powered Mental Health Support · Create Inclusive and Accessible Learning Environments
6. **Digital Tourism** — Create Digital Solutions to Enhance Tourist Experience

## 7. Organizer Dashboard

Grid of three primary cards + request list:
- **Request Status** — pick a request → horizontal **progress tracker** (Submitted → Initial Verification → Under Review → Decision → Closed) with the current stage highlighted; status text below; if **Not Approved**, the administrator's reason is displayed. Status badges (colored pills + icons) throughout.
- **Cancel Request** — lists the organizer's requests still cancellable (status New / Pending Completion / Under Review); confirm dialog → status = cancelled, cancelled_at auto, notification + email sent.
- **Submit Event Final Report** — for approved events whose date has passed and no report exists. Form fields (from the guide): implementation summary · actual date & location · actual attendance · number of participating students · number of ideas/projects received · number of projects nominated for follow-up · resulting partnerships/opportunities · satisfaction/evaluation indicators (percentage + optional attachment) · actual budget table · documentary attachments (photos, final program, certificates, links, media coverage — file uploads). Submitting sets request status → **Closed**, sends notification + email.

## 8. Admin & Super Admin Dashboards

Cards: **Event Requests · Events Calendar · Cancelled Requests · Events Final Reports · Analytics** (+ **Admins** for super admin only).

- **Event Requests** — filterable list (status, date, entity); click → full request detail (all form answers + attachments + admin-only fields: request number, submission date, status, reviewer, institute notes). Decision buttons: **Approve** / **Not Approve** (reason text mandatory). Decision date auto; organizer notified in-app + email. Admins may also set intermediate statuses (Pending Completion, Under Review) with notes.
- **Events Calendar** — same month calendar as public page + moving event cards below.
- **Cancelled Requests** — list; click → read-only request info + cancellation date.
- **Events Final Reports** — toggle **Submitted** / **Not Submitted**; counts of each shown at the top. Click an event: if submitted → the full report; if not → event info + "The event has not submitted their final report."
- **Analytics** — charts (Recharts): events per month/year · which college hosted the most events per month/year · requests per month/year · approved vs not approved per month/year · plus: status distribution, focus-area distribution, final-report compliance rate. Month/year period switcher.
- **Admins (super admin only)** — list admins; add admin (creates auth user + admin profile); delete admin; edit each admin's per-section permissions (view / edit / approve).

## 9. Notifications

| Trigger | In-app | Email |
|---|---|---|
| Request submitted | ✅ | ✅ (includes request ID) |
| Request approved | ✅ | ✅ |
| Request not approved (with reason) | ✅ | ✅ |
| Request cancelled | ✅ | ✅ |
| Final report submitted | ✅ | ✅ |
| Final report overdue reminder | ✅ | ✅ (daily Vercel Cron; event ended, no report, > 5 working days) |

Emails: Resend + React Email, bilingual (recipient's language preference), IAU-branded. The Resend API key is added by the user to Vercel env vars — never handled or committed by Claude. Until the key exists, in-app notifications work and email sending no-ops gracefully.

## 10. Visual Design

- **Public site + dashboards:** IAU identity — green shades + white (sampled from iau.edu.sa), matching typography feel, IAU-style header/footer.
- **Auth pages:** Blackboard-style — yellow + blue shades, split layout with university photo.
- **Responsive** across phone / tablet / laptop breakpoints; accessible (labels, contrast, keyboard nav); **RTL-correct** in Arabic (layout mirrors, calendar/cards/progress tracker flip properly).
- Implementation guided by installed design skills (`frontend-design`, `ui-ux-pro-max`, `web-design-guidelines`).
- Hero/building imagery: user-supplied photos (a1–a10 candidates) or IAU imagery the user provides; placeholders until then.

## 11. Error Handling & Edge Cases

- Form date < 3 working weeks → inline error, submission blocked.
- Draft-less navigation guard: warn before leaving a dirty form (bonus: local draft autosave).
- Upload limits: file type (PDF/DOCX/PPT/images) + size caps; storage paths scoped per request with RLS.
- Cancel only while New / Pending Completion / Under Review; approved or decided requests cannot be cancelled by the organizer.
- Final report only for approved events whose date has passed; one report per request.
- Role mismatch at login → explicit message. Unauthorized route access → redirect.
- Admin without a permission sees the section disabled/hidden.
- All state transitions validated server-side (RLS + API checks), not just in UI.

## 12. Testing

- Unit tests for critical logic: lead-time calculation (working weeks), request-number generation, status-transition rules, permission checks.
- Integration tests for API routes (submit, decide, cancel, report) against a local/branch Supabase.
- Manual E2E pass per phase using the three seed roles; final full-flow verification (submit → approve → report → closed) before deploy.

## 13. Build Phases

1. **Foundation** — Next.js + TypeScript + Tailwind scaffold, next-intl EN/AR + RTL, design tokens (IAU greens, Blackboard yellow/blue), shared header/nav/footer
2. **Public site** — home (hero, strategy frames, marquee), strategic plan page (+ PDF), requirements page, events calendar
3. **Auth** — Supabase Auth wiring, sign-up, Blackboard-style login (two-option), forgot password, role routing, seed accounts (live DB, not in repo)
4. **Request form** — all sections, conditional logic, focus-areas → goals, validation, attachments upload, submission pipeline (auto ID/dates)
5. **Organizer dashboard** — status progress tracker, cancel flow, final report form
6. **Admin dashboard** — requests review/decide, calendar, cancelled list, final reports section
7. **Super admin** — admins management + permissions
8. **Analytics** — charts + period switchers
9. **Notifications** — in-app center + Resend emails + cron reminder
10. **Arabic/RTL pass** — full translation catalogs, RTL audit of every page
11. **Deploy** — GitHub repo, Vercel project, Supabase production config, user adds secrets, E2E verification on the live URL

Each phase ends in a working, reviewable state.

## 14. Security Boundaries (user-mandated)

- Claude never enters passwords into external sites, never pastes secret API keys, never approves OAuth/billing consent — those exact steps are handed to the user.
- Secret keys (Supabase service role, Resend) live only in Vercel/local env vars, added by the user; `.gitignore` excludes all env files.
- Seed-account passwords are set via Supabase admin tooling at deploy time, never committed to the repository.
