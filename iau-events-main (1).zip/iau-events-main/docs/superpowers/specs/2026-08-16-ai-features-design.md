# AI Features v2 — Design (2026-08-16)

Three AI features requested by the Institute (per their guidance document), built for the
admin review workflow. This replaces nothing: the earlier chatbot/ask-your-data features
(removed in 7c69cb9) stay removed.

## Context & constraints

- Stack: Next.js 16 App Router + Supabase (project `uobhwrnqgdxcxnclubxm`) + Vercel.
- The Vercel AI Gateway is blocked on this account (403 `customer_verification_required`,
  no card on file) — so features call the **official Anthropic SDK** (`@anthropic-ai/sdk`)
  directly with `ANTHROPIC_API_KEY`. The key is added by the user (never by Claude) to
  `.env.local` and Vercel env settings. Until then, AI endpoints return a clear
  "AI is not configured" error that the UI surfaces.
- Model: `claude-opus-5` (thinking on by default; structured outputs via
  `output_config.format`; server-side refusal fallbacks enabled with `fallbacks: "default"`).
- Feature 3 (success prediction) is **classical supervised ML, not an LLM** — a logistic
  regression implemented in TypeScript, trained at request time on the platform's own
  closed events (12 today, grows over time). Metrics via leave-one-out cross-validation.

## Feature 1 — AI Event Evaluation

**Goal:** the model reads a full event request and produces a criteria-based assessment
to help the admin decide.

- Criteria (from the Institute's doc): clarity of objectives, relevance to the university,
  expected impact, feasibility, alignment with strategic goals, quality of expected outputs.
- `POST /api/admin/requests/[id]/evaluate` — admin/super_admin only. Loads the request +
  alignment rows, builds a structured prompt, calls Claude with a zod-validated JSON schema:
  `{ overallScore 0-100, criteria: [{key, score 0-10, comment}], strengths[], weaknesses[],
  recommendation }`.
- Result is **stored** in a new `ai_evaluations` table (unique per request; re-evaluating
  overwrites) so it persists for the whole review chain and for the record.
- UI: `AiEvaluationPanel` on `/admin/requests/[id]` — shows stored evaluation (score dial,
  criteria bars, strengths/weaknesses, recommendation) with an "Evaluate with AI" /
  "Re-evaluate" button. Bilingual: the model writes in the admin's locale.

## Feature 2 — AI Text Summarization

**Goal:** one-click concise summary of a long event request or a final report.

- `POST /api/admin/requests/[id]/summarize` with `{ kind: "request" | "report" }` —
  admin/super_admin only. Concatenates the relevant text fields (description, objectives/
  outputs, audience, venue, partners… / implementation summary, results, partnerships…),
  prompts Claude for a short faithful summary (~120 words), locale-aware.
- Cached in `ai_summaries` (request_id + kind + locale unique) so repeat clicks are free;
  a "Regenerate" action bypasses the cache.
- UI: `AiSummaryPanel` ("Summarize with AI") on the admin request detail page and the
  admin report detail page.

## Feature 3 — Event Success Prediction

**Goal:** predict the probability that a proposed event will succeed, learned from
historical completed events.

- **Success definition** (per Institute doc): attendance rate = actual/expected ≥ 0.8
  counts as success (1), else 0. Reports always exist for closed events.
- **Features** (from the request only, so it works pre-approval): expected attendance
  (log-scaled), duration hours, month (sin/cos), activity format one-hot, request types,
  has_students/has_faculty/has_partners, counts, sdgs/outputs breadth.
- **Model:** logistic regression, gradient descent, z-score normalization — pure
  TypeScript in `src/lib/ai/success-model.ts` (no external ML deps, fully unit-testable).
- **Evaluation:** leave-one-out cross-validation → accuracy, precision, recall, F1;
  returned with the prediction along with training-set size and a small-sample caveat.
- `POST /api/admin/requests/[id]/predict` — trains on closed events (cached in-memory
  per server instance for 10 min), predicts for this request, returns probability,
  likelihood band (high ≥70% / medium ≥40% / low), top contributing factors
  (weight × feature value), metrics, n.
- UI: `SuccessPredictionPanel` on the admin request detail page. Not stored — always
  computed from the latest historical data.

## Cross-cutting

- New migration `20260816_ai_features.sql`: `ai_evaluations`, `ai_summaries`, RLS
  `is_admin()` only (service access via authenticated admin session; API routes verify
  role before writing with the user's own client, so RLS needs admin insert/update too).
- i18n: full en/ar strings under `admin.ai.*`.
- Tests: success-model lib (training convergence, prediction sanity, LOOCV metrics,
  feature encoding) + prompt-builder pure functions.
- Errors: missing `ANTHROPIC_API_KEY` → 503 `{error:"not_configured"}` → UI shows a
  bilingual "AI not configured" hint; refusal stop_reason handled; 30s maxDuration.
