"use server";

import { getLocale } from "next-intl/server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isIauEmail } from "./validation";

export type AuthState = {
  errors?: { form?: string; email?: string };
  notice?: string;
};

export type Role = "organizer" | "admin" | "super_admin" | "entity_head";

async function dashboardPath(role: Role) {
  const locale = await getLocale();
  if (role === "organizer") return `/${locale}/dashboard`;
  if (role === "entity_head") return `/${locale}/entity`;
  return `/${locale}/admin`;
}

// Public self-signup was removed: accounts exist only for university members
// (@iau.edu.sa — enforced by the handle_new_user DB trigger) and are
// provisioned by the Institute (e.g. create_admin for admins).

export async function signIn(
  door: "organizer" | "admin",
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  if (!email || !password) return { errors: { form: "required" } };
  if (!isIauEmail(email)) return { errors: { form: "iauEmail" } };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    if (error.code === "email_not_confirmed")
      return { errors: { form: "emailNotConfirmed" } };
    return { errors: { form: "invalidCredentials" } };
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", data.user.id)
    .single();

  // Entity heads (deans/managers/presidents) use the administrator door too
  const role = (profile?.role ?? "organizer") as Role;
  const isAdminRole =
    role === "admin" || role === "super_admin" || role === "entity_head";

  if (door === "admin" && !isAdminRole) {
    await supabase.auth.signOut();
    return { errors: { form: "notAdmin" } };
  }
  if (door === "organizer" && isAdminRole) {
    await supabase.auth.signOut();
    return { errors: { form: "notOrganizer" } };
  }

  redirect(await dashboardPath(role));
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  const locale = await getLocale();
  redirect(`/${locale}`);
}

export async function resetPassword(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim();
  if (!email) return { errors: { form: "required" } };
  if (!isIauEmail(email)) return { errors: { form: "iauEmail" } };

  const locale = await getLocale();
  const supabase = await createClient();
  const origin =
    process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${origin}/${locale}/reset-password`,
  });
  // Always confirm — do not leak whether the email exists
  return { notice: "resetSent" };
}

export async function updatePassword(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirmPassword") ?? "");
  if (!password) return { errors: { form: "required" } };
  if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password))
    return { errors: { form: "passwordWeak" } };
  if (password !== confirm) return { errors: { form: "passwordMismatch" } };

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { errors: { form: "resetFailed" } };

  const { data } = await supabase
    .from("profiles")
    .select("role")
    .single();
  redirect(await dashboardPath((data?.role ?? "organizer") as Role));
}
