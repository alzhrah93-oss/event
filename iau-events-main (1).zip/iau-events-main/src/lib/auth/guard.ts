import { getLocale } from "next-intl/server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Role } from "./actions";

export type SessionProfile = {
  id: string;
  fullName: string;
  email: string;
  role: Role;
  permissions: Record<string, string>;
  /** Entity heads only: the entity they manage (e.g. "college:medicine"). */
  entityKey: string | null;
};

/** Read the current session's profile, or null when signed out. */
export async function getSessionProfile(): Promise<SessionProfile | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, email, role, permissions, entity_key")
    .eq("id", user.id)
    .single();
  if (!profile) return null;

  return {
    id: user.id,
    fullName: profile.full_name,
    email: profile.email,
    role: profile.role as Role,
    permissions: (profile.permissions ?? {}) as Record<string, string>,
    entityKey: profile.entity_key ?? null,
  };
}

/**
 * Server-side route guard. Redirects to login when signed out, or to the
 * user's own dashboard when the role doesn't allow this page.
 */
export async function requireUser(
  allowed: Role[],
): Promise<SessionProfile> {
  const locale = await getLocale();
  const profile = await getSessionProfile();
  if (!profile) redirect(`/${locale}/login`);
  if (!allowed.includes(profile.role)) {
    redirect(
      profile.role === "organizer"
        ? `/${locale}/dashboard`
        : profile.role === "entity_head"
          ? `/${locale}/entity`
          : `/${locale}/admin`,
    );
  }
  return profile;
}
