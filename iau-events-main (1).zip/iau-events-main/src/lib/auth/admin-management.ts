"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getSessionProfile } from "./guard";
import {
  PERMISSION_SECTIONS,
  type PermissionSection,
} from "./permissions";
import { isIauEmail } from "./validation";

type Result = { ok: boolean; error?: string };

async function requireSuperAdmin() {
  const profile = await getSessionProfile();
  return profile?.role === "super_admin" ? profile : null;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function createAdmin(
  _prev: Result,
  fd: FormData,
): Promise<Result> {
  if (!(await requireSuperAdmin())) return { ok: false, error: "forbidden" };

  const name = String(fd.get("name") ?? "").trim();
  const email = String(fd.get("email") ?? "").trim();
  const password = String(fd.get("password") ?? "");
  if (!name) return { ok: false, error: "nameRequired" };
  if (!EMAIL_RE.test(email)) return { ok: false, error: "invalidEmail" };
  if (!isIauEmail(email)) return { ok: false, error: "iauEmail" };
  if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password))
    return { ok: false, error: "weakPassword" };

  const supabase = await createClient();
  const { error } = await supabase.rpc("create_admin", {
    p_email: email,
    p_password: password,
    p_name: name,
  });
  if (error) {
    if (error.message.includes("email_exists"))
      return { ok: false, error: "emailExists" };
    return { ok: false, error: "failed" };
  }

  revalidatePath("/[locale]/admin/admins", "page");
  return { ok: true };
}

export async function deleteAdmin(targetId: string): Promise<Result> {
  if (!(await requireSuperAdmin())) return { ok: false, error: "forbidden" };

  const supabase = await createClient();
  const { error } = await supabase.rpc("delete_admin", { target: targetId });
  if (error) return { ok: false, error: "failed" };

  revalidatePath("/[locale]/admin/admins", "page");
  return { ok: true };
}

export async function updateAdminPermissions(
  targetId: string,
  permissions: Record<string, string>,
): Promise<Result> {
  if (!(await requireSuperAdmin())) return { ok: false, error: "forbidden" };

  // Only known sections/levels are persisted
  const clean: Record<string, string> = {};
  for (const s of PERMISSION_SECTIONS) {
    const v = permissions[s.key];
    if (v && (s.levels as readonly string[]).includes(v)) {
      clean[s.key as PermissionSection] = v;
    }
  }

  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({ permissions: clean })
    .eq("id", targetId)
    .eq("role", "admin");
  if (error) return { ok: false, error: "failed" };

  revalidatePath("/[locale]/admin/admins", "page");
  return { ok: true };
}
