import type { SessionProfile } from "./guard";

/**
 * Per-admin permission model stored in profiles.permissions (jsonb).
 * Mirrors the DB-side `has_permission()` policy helper.
 */
export const PERMISSION_SECTIONS = [
  { key: "requests", levels: ["view", "approve"] },
  { key: "reports", levels: ["none", "view", "download"] },
  { key: "analytics", levels: ["none", "view"] },
] as const;

export type PermissionSection = (typeof PERMISSION_SECTIONS)[number]["key"];

export const DEFAULT_ADMIN_PERMISSIONS: Record<PermissionSection, string> = {
  requests: "approve",
  reports: "view",
  analytics: "view",
};

function check(
  profile: SessionProfile,
  section: PermissionSection,
  required: string[],
): boolean {
  if (profile.role === "super_admin") return true;
  if (profile.role !== "admin") return false;
  return required.includes(profile.permissions[section]);
}

export const canApprove = (p: SessionProfile) =>
  check(p, "requests", ["approve"]);
/** "download" implies view access — it is view + attachment download. */
export const canViewReports = (p: SessionProfile) =>
  check(p, "reports", ["view", "download"]);
/** Super admin always; admins only when granted the download level. */
export const canDownloadReports = (p: SessionProfile) =>
  check(p, "reports", ["download"]);
export const canViewAnalytics = (p: SessionProfile) =>
  check(p, "analytics", ["view"]);
