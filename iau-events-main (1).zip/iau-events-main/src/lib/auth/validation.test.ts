import { describe, expect, it } from "vitest";
import { validateSignup } from "./validation";

const valid = {
  fullName: "Hatoon Al Test",
  nationalId: "1234567890",
  email: "test@iau.edu.sa",
  phone: "0512345678",
  password: "secret123",
  confirmPassword: "secret123",
};

describe("validateSignup", () => {
  it("accepts a valid payload", () => {
    expect(validateSignup(valid)).toEqual({});
  });

  it("requires all fields", () => {
    const errors = validateSignup({
      fullName: "",
      nationalId: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
    });
    for (const k of [
      "fullName",
      "nationalId",
      "email",
      "phone",
      "password",
    ] as const) {
      expect(errors[k]).toBe("required");
    }
  });

  it("rejects malformed national id, email, phone", () => {
    expect(validateSignup({ ...valid, nationalId: "12345" }).nationalId).toBe(
      "nationalId",
    );
    expect(validateSignup({ ...valid, email: "not-an-email" }).email).toBe(
      "email",
    );
    expect(validateSignup({ ...valid, phone: "12345" }).phone).toBe("phone");
  });

  it("rejects non-IAU email domains", () => {
    expect(validateSignup({ ...valid, email: "test@example.com" }).email).toBe(
      "iauEmail",
    );
    expect(validateSignup({ ...valid, email: "x@iau.edu.sa.evil.com" }).email).toBe(
      "iauEmail",
    );
    expect(validateSignup({ ...valid, email: "Test@IAU.edu.sa" })).toEqual({});
  });

  it("accepts +9665 phone format", () => {
    expect(validateSignup({ ...valid, phone: "+966512345678" })).toEqual({});
  });

  it("enforces password strength and match", () => {
    expect(
      validateSignup({ ...valid, password: "short1", confirmPassword: "short1" })
        .password,
    ).toBe("passwordWeak");
    expect(
      validateSignup({
        ...valid,
        password: "onlyletters",
        confirmPassword: "onlyletters",
      }).password,
    ).toBe("passwordWeak");
    expect(
      validateSignup({ ...valid, confirmPassword: "different1" })
        .confirmPassword,
    ).toBe("passwordMismatch");
  });
});
