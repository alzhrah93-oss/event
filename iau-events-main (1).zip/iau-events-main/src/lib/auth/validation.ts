export type SignupInput = {
  fullName: string;
  nationalId: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
};

/**
 * Error codes (not messages) keyed by field — the UI maps codes to
 * localized strings under the `auth.errors` namespace.
 */
export type SignupErrors = Partial<Record<keyof SignupInput, string>>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const NATIONAL_ID_RE = /^\d{10}$/;
const PHONE_RE = /^(05\d{8}|\+9665\d{8})$/;

/** Platform accounts are restricted to university addresses. */
export const isIauEmail = (email: string) =>
  /@iau\.edu\.sa$/i.test(email.trim());

export function validateSignup(input: SignupInput): SignupErrors {
  const errors: SignupErrors = {};

  if (!input.fullName.trim()) errors.fullName = "required";

  if (!input.nationalId.trim()) errors.nationalId = "required";
  else if (!NATIONAL_ID_RE.test(input.nationalId.trim()))
    errors.nationalId = "nationalId";

  if (!input.email.trim()) errors.email = "required";
  else if (!EMAIL_RE.test(input.email.trim())) errors.email = "email";
  else if (!isIauEmail(input.email)) errors.email = "iauEmail";

  if (!input.phone.trim()) errors.phone = "required";
  else if (!PHONE_RE.test(input.phone.trim().replace(/[\s-]/g, "")))
    errors.phone = "phone";

  if (!input.password) errors.password = "required";
  else if (
    input.password.length < 8 ||
    !/[a-zA-Z]/.test(input.password) ||
    !/\d/.test(input.password)
  )
    errors.password = "passwordWeak";

  if (!errors.password && input.password !== input.confirmPassword)
    errors.confirmPassword = "passwordMismatch";

  return errors;
}
