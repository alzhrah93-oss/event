import { describe, expect, it } from "vitest";
import {
  canApprove,
  canDownloadReports,
  canViewReports,
  PERMISSION_SECTIONS,
} from "./permissions";
import type { SessionProfile } from "./guard";

const base: SessionProfile = {
  id: "x",
  fullName: "A",
  email: "a@a.sa",
  role: "admin",
  permissions: {},
  entityKey: null,
};

describe("permission checks", () => {
  it("super admins can do everything", () => {
    const p = { ...base, role: "super_admin" as const };
    expect(canApprove(p)).toBe(true);
    expect(canViewReports(p)).toBe(true);
    expect(canDownloadReports(p)).toBe(true);
  });

  it("admins follow their permissions map", () => {
    expect(canApprove({ ...base, permissions: { requests: "approve" } })).toBe(true);
    expect(canApprove({ ...base, permissions: { requests: "view" } })).toBe(false);
    expect(canViewReports({ ...base, permissions: { reports: "view" } })).toBe(true);
    expect(canViewReports({ ...base, permissions: { reports: "none" } })).toBe(false);
  });

  it("download level implies view but not the reverse", () => {
    expect(canViewReports({ ...base, permissions: { reports: "download" } })).toBe(true);
    expect(canDownloadReports({ ...base, permissions: { reports: "download" } })).toBe(true);
    expect(canDownloadReports({ ...base, permissions: { reports: "view" } })).toBe(false);
    expect(canDownloadReports({ ...base, permissions: { reports: "none" } })).toBe(false);
  });

  it("organizers never pass", () => {
    const p = { ...base, role: "organizer" as const, permissions: { requests: "approve" } };
    expect(canApprove(p)).toBe(false);
  });

  it("sections metadata is complete", () => {
    expect(PERMISSION_SECTIONS.map((s) => s.key)).toEqual([
      "requests",
      "reports",
      "analytics",
    ]);
  });
});
