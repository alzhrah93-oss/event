/**
 * Bilingual static content for the public site.
 *
 * Sources (authoritative):
 * - IAU Scientific Research & Innovation Strategic Plan 2025–2030 (PDF, pp. 9–10, 21)
 * - IAU Governance and Approval Guide (English translation), §3 and §4
 * - Focus areas & goals: provided verbatim by the Institute
 */

export type Localized = { en: string; ar: string };

export type FocusArea = {
  id: string;
  name: Localized;
  goals: Localized[];
};

/** Vision & Mission — strategic plan pp. 9–10 (Arabic verbatim; English translated) */
export const VISION: Localized = {
  en: "A leading university in transforming scientific discoveries into practical innovations with tangible, measurable societal impact.",
  ar: "جامعة رائدة في تحويل الاكتشافات العلمية إلى ابتكارات عملية ذات أثر مجتمعي ملموس وقابل للقياس.",
};

export const MISSION: Localized = {
  en: "Establishing an integrated research ecosystem focused on health and quality of life — unifying multidisciplinary research efforts, developing distinguished research talent, and building strategic partnerships that transform scientific knowledge into impactful solutions serving society.",
  ar: "إنشاء منظومة بحثية متكاملة تركز على الصحة وجودة الحياة، من خلال توحيد الجهود البحثية متعددة التخصصات، وتطوير الكوادر البحثية المتميزة، وبناء شراكات استراتيجية تضمن تحويل المعرفة العلمية إلى حلول مؤثرة تخدم المجتمع.",
};

/** National & international alignment — strategic plan p. 10 */
export const ALIGNMENT_ITEMS: { name: Localized; detail: Localized }[] = [
  {
    name: { en: "Saudi Vision 2030", ar: "رؤية المملكة 2030" },
    detail: {
      en: "The research and innovation strategy is aligned with the Kingdom's Vision 2030.",
      ar: "تتوافق استراتيجية البحث والابتكار مع رؤية المملكة 2030.",
    },
  },
  {
    name: {
      en: "RDIA — Research, Development and Innovation Authority",
      ar: "هيئة البحث والتطوير والابتكار",
    },
    detail: {
      en: "Aligned with the national priorities of the Research, Development and Innovation Authority.",
      ar: "مواءمة مع أولويات هيئة البحث والتطوير والابتكار الوطنية.",
    },
  },
  {
    name: {
      en: "SDAIA — Saudi Data & AI Authority",
      ar: "الهيئة السعودية للبيانات والذكاء الاصطناعي",
    },
    detail: {
      en: "Aligned with the Saudi Data & Artificial Intelligence Authority.",
      ar: "مواءمة مع الهيئة السعودية للبيانات والذكاء الاصطناعي.",
    },
  },
  {
    name: {
      en: "Related national entities",
      ar: "أولويات الجهات الوطنية ذات الصلة",
    },
    detail: {
      en: "Priorities of national entities including the Ministries of Environment, Water & Agriculture; Culture; Communications & IT; Industry & Mineral Resources; Education; Tourism; and Energy.",
      ar: "أولويات الجهات الوطنية ذات الصلة مثل وزارة البيئة والمياه والزراعة، ووزارة الثقافة، ووزارة الاتصالات وتقنية المعلومات، ووزارة الصناعة والثروة المعدنية، ووزارة التعليم، ووزارة السياحة، ووزارة الطاقة.",
    },
  },
  {
    name: {
      en: "UN Sustainable Development Goals",
      ar: "أهداف التنمية المستدامة",
    },
    detail: {
      en: "The strategy is aligned with 11 of the 17 Sustainable Development Goals, reflecting the University's commitment to the Kingdom's progress toward sustainable development by 2030.",
      ar: "تمت مواءمة الاستراتيجية مع 11 هدفاً من أصل 17 هدفاً للتنمية المستدامة، مما يعكس التزام الجامعة بدعم تقدم المملكة نحو تحقيق التنمية المستدامة لعام 2030.",
    },
  },
];

/** Strategic framework numbers — strategic plan p. 21 */
export const FRAMEWORK_NUMBERS: { value: number; label: Localized }[] = [
  {
    value: 3,
    label: { en: "National focus areas", ar: "مجالات التركيز الوطنية" },
  },
  {
    value: 7,
    label: { en: "National priorities", ar: "الأولويات الوطنية" },
  },
  {
    value: 10,
    label: { en: "Grand challenges", ar: "التحديات" },
  },
  {
    value: 29,
    label: { en: "Innovation goals", ar: "الأهداف الابتكارية" },
  },
];

/** 6 strategic focus areas + goals — provided verbatim by the Institute */
export const FOCUS_AREAS: FocusArea[] = [
  {
    id: "health-wellness",
    name: { en: "Health and Wellness", ar: "الصحة وجودة الحياة" },
    goals: [
      {
        en: "Reducing Musculoskeletal Disorders",
        ar: "الحد من الاضطرابات العضلية الهيكلية",
      },
      { en: "Reducing KSA Obesity", ar: "خفض معدلات السمنة في المملكة" },
      {
        en: "Reducing Vector-Borne Disease",
        ar: "الحد من الأمراض المنقولة بالنواقل",
      },
      {
        en: "Reducing Prevalence of Depression",
        ar: "خفض معدل انتشار الاكتئاب",
      },
    ],
  },
  {
    id: "energy-industrials",
    name: { en: "Energy & Industrials", ar: "الطاقة والصناعة" },
    goals: [
      {
        en: "Improving Efficiency of Energy Storage Systems",
        ar: "تحسين كفاءة أنظمة تخزين الطاقة",
      },
      {
        en: "Reducing the Cost of Hydrogen Storage",
        ar: "خفض تكلفة تخزين الهيدروجين",
      },
      { en: "Recycling Polymer Waste", ar: "إعادة تدوير مخلفات البوليمرات" },
      {
        en: "Recycle of Glass and Battery Waste",
        ar: "إعادة تدوير مخلفات الزجاج والبطاريات",
      },
      {
        en: "Increase the Use of Recycled Waste",
        ar: "زيادة استخدام المخلفات المعاد تدويرها",
      },
      {
        en: "Develop Solutions to Reduce Industrial Energy Waste",
        ar: "تطوير حلول لخفض هدر الطاقة الصناعية",
      },
    ],
  },
  {
    id: "future-economies",
    name: { en: "Economies of the Future", ar: "اقتصاديات المستقبل" },
    goals: [
      {
        en: "Reducing Energy Consumption in Water Systems",
        ar: "خفض استهلاك الطاقة في أنظمة المياه",
      },
      {
        en: "Reducing Post-Surgery Recovery Time",
        ar: "تقليل مدة التعافي بعد العمليات الجراحية",
      },
      {
        en: "Developing Smart Supply Chain System",
        ar: "تطوير نظام سلاسل إمداد ذكية",
      },
      {
        en: "Governance & Regulation of Therapeutics Procedures",
        ar: "حوكمة وتنظيم الإجراءات العلاجية",
      },
    ],
  },
  {
    id: "sustainability",
    name: {
      en: "Sustainability and Essential Needs",
      ar: "استدامة البيئة والاحتياجات الأساسية",
    },
    goals: [
      {
        en: "Develop Integrated CCS Strategy",
        ar: "تطوير استراتيجية متكاملة لالتقاط الكربون وتخزينه",
      },
      {
        en: "Achieving Net-Zero/Net-Positive Energy Status",
        ar: "تحقيق الحياد الصفري أو الإيجابية الصافية للطاقة",
      },
      {
        en: "Utilize Waste Materials for Value-Added Applications",
        ar: "الاستفادة من المخلفات في تطبيقات ذات قيمة مضافة",
      },
      {
        en: "Developing Advanced Chemicals or Membranes",
        ar: "تطوير مواد كيميائية أو أغشية متقدمة",
      },
      {
        en: "Implement Cooling Technology Using Renewable Energy",
        ar: "تطبيق تقنيات التبريد باستخدام الطاقة المتجددة",
      },
    ],
  },
  {
    id: "ai-education",
    name: { en: "AI Education", ar: "التعليم بالذكاء الاصطناعي" },
    goals: [
      {
        en: "Improving Student Career Decisions",
        ar: "تحسين القرارات المهنية للطلبة",
      },
      {
        en: "AI-Powered Mental Health Support",
        ar: "دعم الصحة النفسية بالذكاء الاصطناعي",
      },
      {
        en: "Create Inclusive and Accessible Learning Environments",
        ar: "إنشاء بيئات تعليمية شاملة وميسّرة",
      },
    ],
  },
  {
    id: "digital-tourism",
    name: { en: "Digital Tourism", ar: "السياحة الرقمية" },
    goals: [
      {
        en: "Create Digital Solutions to Enhance Tourist Experience",
        ar: "تطوير حلول رقمية لتعزيز تجربة السائح",
      },
    ],
  },
];

export type GrandChallenge = {
  id: string;
  focusAreaId: string;
  /** Short label for filters and charts */
  short: Localized;
  /** Full challenge statement shown when selecting */
  text: Localized;
};

/**
 * 10 grand challenges — strategic plan pp. 21–28. They map onto only 3 of
 * the 6 focus areas: health (6), energy (2), future economies (2).
 */
export const GRAND_CHALLENGES: GrandChallenge[] = [
  {
    id: "cardio_deaths",
    focusAreaId: "health-wellness",
    short: { en: "Cardiovascular deaths −50%", ar: "خفض وفيات القلب 50%" },
    text: {
      en: "Reduce deaths from cardiovascular disease in the Kingdom by 50% by 2035, through comprehensive prevention strategies and optimal clinical management",
      ar: "خفض وفيات أمراض القلب والأوعية الدموية في المملكة بنسبة 50% بحلول 2035، من خلال استراتيجيات وقائية شاملة وإدارة سريرية مثلى",
    },
  },
  {
    id: "diabetes_deaths",
    focusAreaId: "health-wellness",
    short: { en: "Diabetes deaths −50%", ar: "خفض وفيات السكري 50%" },
    text: {
      en: "Reduce diabetes-related deaths among Saudis under 60 by 50% by 2040, through early treatment and preventive strategies",
      ar: "خفض الوفيات المرتبطة بالسكري بين السعوديين دون سن الستين بنسبة 50% بحلول 2040، من خلال العلاج المبكر والاستراتيجيات الوقائية",
    },
  },
  {
    id: "cancer_rates",
    focusAreaId: "health-wellness",
    short: { en: "Cancer rates −25%", ar: "خفض معدلات السرطان 25%" },
    text: {
      en: "Reduce cancer rates by 25% through enhanced early detection and targeted therapies",
      ar: "خفض معدلات الإصابة بالسرطان بنسبة 25% من خلال تعزيز الكشف المبكر والعلاجات الموجهة",
    },
  },
  {
    id: "infectious_diseases",
    focusAreaId: "health-wellness",
    short: { en: "Eliminate infectious diseases", ar: "القضاء على الأمراض المعدية" },
    text: {
      en: "Halt and eliminate the spread of common infectious diseases in the Kingdom by 2030",
      ar: "إيقاف انتشار الأمراض المعدية الشائعة في المملكة والقضاء عليها بحلول 2030",
    },
  },
  {
    id: "beta_thalassemia",
    focusAreaId: "health-wellness",
    short: { en: "Cure beta-thalassemia", ar: "علاج شافٍ للثلاسيميا" },
    text: {
      en: "Develop a curative treatment for beta-thalassemia by 2035",
      ar: "تطوير علاج شافٍ لمرض الثلاسيميا (بيتا) بحلول 2035",
    },
  },
  {
    id: "sickle_cell",
    focusAreaId: "health-wellness",
    short: { en: "Sickle-cell complications −40%", ar: "خفض مضاعفات فقر الدم المنجلي 40%" },
    text: {
      en: "Reduce sickle-cell-disease complications and hospitalizations in the Kingdom by 40% by 2040",
      ar: "خفض مضاعفات مرض فقر الدم المنجلي وحالات التنويم في المملكة بنسبة 40% بحلول 2040",
    },
  },
  {
    id: "solar_wind_efficiency",
    focusAreaId: "energy-industrials",
    short: { en: "Solar/wind efficiency +20%", ar: "رفع كفاءة الطاقة الشمسية والرياح 20%" },
    text: {
      en: "Increase solar/wind system generation efficiency by 20%",
      ar: "زيادة كفاءة توليد أنظمة الطاقة الشمسية وطاقة الرياح بنسبة 20%",
    },
  },
  {
    id: "metal_recovery",
    focusAreaId: "energy-industrials",
    short: { en: "Recover 30% of high-value metals", ar: "استرجاع 30% من المعادن الثمينة" },
    text: {
      en: "Recover 30% of high-value metals from industrial waste by 2030",
      ar: "استرجاع 30% من المعادن عالية القيمة من المخلفات الصناعية بحلول 2030",
    },
  },
  {
    id: "ai_remote_diagnosis",
    focusAreaId: "future-economies",
    short: { en: "AI remote diagnosis", ar: "التشخيص عن بُعد بالذكاء الاصطناعي" },
    text: {
      en: "Develop AI-supported remote diagnosis to cut hospital admissions in the Kingdom by 30% by 2030",
      ar: "تطوير التشخيص عن بُعد المدعوم بالذكاء الاصطناعي لخفض حالات التنويم في مستشفيات المملكة بنسبة 30% بحلول 2030",
    },
  },
  {
    id: "emergency_response",
    focusAreaId: "future-economies",
    short: { en: "Emergency response time −70%", ar: "خفض زمن الاستجابة للطوارئ 70%" },
    text: {
      en: "Reduce emergency response time in the Kingdom by 70% by 2030",
      ar: "خفض زمن الاستجابة للطوارئ في المملكة بنسبة 70% بحلول 2030",
    },
  },
];

export const challengesForArea = (focusAreaId: string): GrandChallenge[] =>
  GRAND_CHALLENGES.filter((c) => c.focusAreaId === focusAreaId);

/** Principles of Governance and Approval — governance guide §3 */
export const GOV_PRINCIPLES: { title: Localized; detail: Localized }[] = [
  {
    title: { en: "Strategic alignment", ar: "الارتباط الاستراتيجي" },
    detail: {
      en: "An activity will not be approved unless its connection to the objectives of scientific research, innovation, and entrepreneurship is demonstrated.",
      ar: "لا يُعتمد النشاط ما لم يثبت ارتباطه بأهداف البحث العلمي والابتكار وريادة الأعمال.",
    },
  },
  {
    title: { en: "Prior approval", ar: "الموافقة المسبقة" },
    detail: {
      en: "Implementation, announcement, or expenditure must not begin before the formal approval process is completed through the platform.",
      ar: "لا يمكن البدء بالتنفيذ أو الإعلان أو الصرف قبل استكمال إجراءات الاعتماد عبر المنصة.",
    },
  },
  {
    title: {
      en: "Intellectual property protection",
      ar: "حماية الملكية الفكرية",
    },
    detail: {
      en: "Ideas, projects, and prototypes must undergo an initial review before public presentation or external participation.",
      ar: "تخضع الأفكار والمشاريع والنماذج الأولية لمراجعة أولية قبل العرض العام أو المشاركة الخارجية.",
    },
  },
  {
    title: { en: "Measurability", ar: "قابلية القياس" },
    detail: {
      en: "Expected outputs and impact indicators must be defined before implementation, and results must be documented afterward.",
      ar: "تُحدد المخرجات المتوقعة ومؤشرات الأثر قبل التنفيذ، وتُوثق النتائج بعده.",
    },
  },
  {
    title: { en: "Resource efficiency", ar: "كفاءة الموارد" },
    detail: {
      en: "The budget, source of support, and operational need for laboratories, facilities, or services must be clearly stated.",
      ar: "يجب توضيح الميزانية ومصدر الدعم والاحتياج التشغيلي من مختبرات أو مرافق أو خدمات.",
    },
  },
  {
    title: { en: "Institutional integration", ar: "التكامل المؤسسي" },
    detail: {
      en: "Events must be linked to the unified platform and to innovation databases, programs, projects, and partnerships.",
      ar: "تُربط الفعاليات بالمنصة الموحدة وبقواعد بيانات الابتكار والبرامج والمشاريع والشراكات.",
    },
  },
];

/** Pre-Activity Submission Requirements — governance guide §4 */
export const PRE_SUBMISSION_REQUIREMENTS: Localized[] = [
  {
    en: "Submit the request through the platform at least three working weeks before the implementation date.",
    ar: "رفع الطلب عبر المنصة قبل موعد التنفيذ بثلاثة أسابيع عمل على الأقل.",
  },
  {
    en: "Attach an official letter or the approval of the organizing or hosting entity, when applicable.",
    ar: "إرفاق خطاب رسمي أو موافقة الجهة المنظمة أو المستضيفة.",
  },
  {
    en: "Specify the activity type, nature, location, target audience, and expected outputs.",
    ar: "تحديد نوع النشاط وطبيعته وموقعه والفئة المستهدفة والمخرجات المتوقعة.",
  },
  {
    en: "Do not make a final announcement or represent the University externally before approval is granted.",
    ar: "عدم الإعلان النهائي أو تمثيل الجامعة خارجياً قبل صدور الموافقة.",
  },
  {
    en: "If the activity includes ideas, projects, or prototypes, complete the Intellectual Property and Disclosure section.",
    ar: "إذا تضمن النشاط أفكاراً أو مشاريع أو نماذج أولية، تُستكمل بيانات الملكية الفكرية والإفصاح.",
  },
  {
    en: "If the activity includes a request for financial or operational support, complete the Budget and Funding Source section.",
    ar: "إذا تضمن النشاط طلب دعم مالي أو تشغيلي، تُستكمل بيانات الميزانية ومصدر التمويل.",
  },
  {
    en: "Upload the final report within five working days after the activity ends.",
    ar: "رفع التقرير الختامي خلال خمسة أيام عمل من انتهاء النشاط.",
  },
];

/** Path to the strategic plan document served from public assets */
export const STRATEGIC_PLAN_PDF = "/documents/strategic-plan.pdf";

/** "About the Platform" page content — Arabic provided by the Institute */
export const ABOUT_PLATFORM: {
  description: Localized;
  goals: Localized[];
  audience: Localized[];
} = {
  description: {
    en: "The Governance Platform for Entrepreneurial and Innovation Events is a unified digital platform dedicated to organizing, managing, and governing all entrepreneurial and innovation events, programs, and initiatives at the University. It unifies the procedures for submitting, reviewing, approving, and following up on requests and documenting their outputs — ensuring quality of implementation, raising the efficiency of coordination between entities, strengthening integration, and achieving the University's targets in entrepreneurship and innovation.",
    ar: "منصة لحوكمة الفعاليات الريادية والابتكارية وهي منصة رقمية موحدة تُعنى بتنظيم وإدارة وحوكمة جميع الفعاليات والبرامج والمبادرات الريادية والابتكارية في الجامعة، من خلال توحيد إجراءات تقديم الطلبات ومراجعتها واعتمادها ومتابعتها وتوثيق مخرجاتها، بما يضمن جودة التنفيذ، ورفع كفاءة التنسيق بين الجهات، وتعزيز التكامل وتحقيق مستهدفات الجامعة في مجالي الريادة والابتكار.",
  },
  goals: [
    {
      en: "Govern and organize all entrepreneurial and innovation events and programs at the University under unified, clear procedures.",
      ar: "حوكمة وتنظيم جميع الفعاليات والبرامج الريادية والابتكارية في الجامعة وفق إجراءات موحدة وواضحة.",
    },
    {
      en: "Unify the mechanism for submitting and approving events across colleges, deanships, and administrations.",
      ar: "توحيد آلية تقديم واعتماد الفعاليات بين الكليات والعمادات والإدارات.",
    },
    {
      en: "Ensure events align with the University's strategy and its entrepreneurship and innovation targets.",
      ar: "ضمان توافق الفعاليات مع استراتيجية الجامعة ومستهدفاتها في الريادة والابتكار.",
    },
    {
      en: "Raise the quality and efficiency of planning, implementation, follow-up, and evaluation.",
      ar: "رفع جودة وكفاءة التخطيط والتنفيذ والمتابعة والتقييم.",
    },
    {
      en: "Reduce duplicated events and strengthen integration and coordination between organizing entities.",
      ar: "الحد من تكرار الفعاليات وتعزيز التكامل والتنسيق بين الجهات المنظمة.",
    },
    {
      en: "Build a central database of events, performance indicators, and their outputs.",
      ar: "بناء قاعدة بيانات مركزية للفعاليات ومؤشرات الأداء ومخرجاتها.",
    },
    {
      en: "Support decision-making through reports and statistical indicator dashboards.",
      ar: "دعم اتخاذ القرار من خلال التقارير ولوحات المؤشرات الإحصائية.",
    },
  ],
  audience: [
    { en: "Colleges", ar: "الكليات" },
    { en: "Supporting deanships", ar: "العمادات المساندة" },
    { en: "Institutes and centers", ar: "المعاهد والمراكز" },
    {
      en: "Related administrations and units",
      ar: "الإدارات والوحدات ذات العلاقة",
    },
    { en: "Faculty members", ar: "أعضاء هيئة التدريس" },
  ],
};
