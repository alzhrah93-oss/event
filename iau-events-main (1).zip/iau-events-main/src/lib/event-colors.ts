/**
 * Stable per-event-type colors shared by the month calendar chips and the
 * marquee cards, so the same activity type always wears the same hue.
 * Pairs are contrast-checked: light chip bg + 900-level text, and solid
 * header bg + white text (≥ 4.5:1).
 */
export type EventTone = {
  /** Calendar chip: light background + dark text */
  chip: string;
  /** Marquee card header: solid background (white text) */
  header: string;
  /** Small dot/accent */
  dot: string;
};

const TONES: EventTone[] = [
  {
    chip: "bg-iau-green-light text-iau-green-dark",
    header: "bg-iau-green",
    dot: "bg-iau-green",
  },
  { chip: "bg-sky-100 text-sky-900", header: "bg-sky-700", dot: "bg-sky-600" },
  {
    chip: "bg-violet-100 text-violet-900",
    header: "bg-violet-700",
    dot: "bg-violet-600",
  },
  {
    chip: "bg-rose-100 text-rose-900",
    header: "bg-rose-700",
    dot: "bg-rose-600",
  },
  {
    chip: "bg-teal-100 text-teal-900",
    header: "bg-teal-700",
    dot: "bg-teal-600",
  },
  {
    chip: "bg-indigo-100 text-indigo-900",
    header: "bg-indigo-700",
    dot: "bg-indigo-600",
  },
  {
    chip: "bg-amber-100 text-amber-900",
    header: "bg-amber-700",
    dot: "bg-amber-600",
  },
  {
    chip: "bg-cyan-100 text-cyan-950",
    header: "bg-cyan-800",
    dot: "bg-cyan-700",
  },
];

/** Deterministic tone for an event type (hash of the stable English name). */
export function eventTone(typeEn: string): EventTone {
  let h = 0;
  for (let i = 0; i < typeEn.length; i++) h = (h * 31 + typeEn.charCodeAt(i)) >>> 0;
  return TONES[h % TONES.length];
}
