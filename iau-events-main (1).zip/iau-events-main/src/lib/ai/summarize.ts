import { AI_MODEL, getAnthropic } from "./client";
import type { EvaluationInput } from "./evaluate";
import { buildEvaluationDocument } from "./evaluate";

/**
 * AI Text Summarization — condenses a long event request or final report into
 * a short, faithful summary for the admin ("Summarize with AI" button).
 */

export type SummaryKind = "request" | "report";

export type ReportInput = {
  implementation_summary: string;
  actual_date: string;
  actual_location: string;
  actual_attendance: number;
  student_count: number;
  ideas_received: number;
  projects_nominated: number;
  projects_nominated_desc: string | null;
  partnerships: string | null;
  actual_budget: unknown[];
};

/** Pure — unit-testable. */
export function buildReportDocument(
  report: ReportInput,
  requestTitle: string,
): string {
  const rows = [
    `Event: ${requestTitle}`,
    `Implementation summary: ${report.implementation_summary}`,
    `Actual date: ${report.actual_date}`,
    `Location: ${report.actual_location}`,
    `Actual attendance: ${report.actual_attendance}`,
    `Student participants: ${report.student_count}`,
    `Ideas received: ${report.ideas_received}`,
    `Projects nominated: ${report.projects_nominated}`,
  ];
  if (report.projects_nominated_desc)
    rows.push(`Nominated projects: ${report.projects_nominated_desc}`);
  if (report.partnerships) rows.push(`Partnerships: ${report.partnerships}`);
  if (Array.isArray(report.actual_budget) && report.actual_budget.length > 0)
    rows.push(`Budget: ${JSON.stringify(report.actual_budget)}`);
  return rows.join("\n");
}

/** Pure — unit-testable. */
export function buildSummaryInstructions(
  kind: SummaryKind,
  locale: "en" | "ar",
): string {
  return [
    kind === "request"
      ? "Summarize this university event request for a busy administrator."
      : "Summarize this event final report for a busy administrator.",
    "Write one short paragraph of at most 120 words.",
    "Preserve the important facts (what, who, when, expected/actual numbers) and do not introduce any information that is not in the source.",
    "Respond with the summary only — no preamble, no headings.",
    locale === "ar" ? "Write the summary in Arabic." : "Write the summary in English.",
  ].join("\n");
}

export async function runSummary(
  kind: SummaryKind,
  document: string,
  locale: "en" | "ar",
): Promise<string> {
  const anthropic = getAnthropic();
  const response = await anthropic.beta.messages.create({
    model: AI_MODEL,
    max_tokens: 8000,
    betas: ["server-side-fallback-2026-07-01"],
    fallbacks: "default",
    system: buildSummaryInstructions(kind, locale),
    messages: [{ role: "user", content: document }],
  });

  if (response.stop_reason === "refusal") {
    throw new Error("The model declined to summarize this content.");
  }
  const text = response.content.find((b) => b.type === "text");
  if (!text || text.type !== "text" || !text.text.trim()) {
    throw new Error("Empty model response.");
  }
  return text.text.trim();
}

export { buildEvaluationDocument as buildRequestDocument };
export type { EvaluationInput as RequestInput };
