import Anthropic from "@anthropic-ai/sdk";

/**
 * Direct Anthropic API access (the Vercel AI Gateway is not available on this
 * account). Requires ANTHROPIC_API_KEY in .env.local / Vercel env settings —
 * the key is added by the platform owner, never committed.
 */
export const AI_MODEL = "claude-opus-5";

export const aiConfigured = () => !!process.env.ANTHROPIC_API_KEY;

let client: Anthropic | null = null;

export function getAnthropic(): Anthropic {
  if (!client) client = new Anthropic();
  return client;
}

/** Thrown when an endpoint is called before the API key is configured. */
export class AiNotConfiguredError extends Error {
  constructor() {
    super("ANTHROPIC_API_KEY is not set");
    this.name = "AiNotConfiguredError";
  }
}
