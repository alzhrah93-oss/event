import { describe, expect, it } from "vitest";
import {
  buildEvaluationDocument,
  buildEvaluationInstructions,
  type EvaluationInput,
} from "./evaluate";
import { buildReportDocument, buildSummaryInstructions } from "./summarize";

const request: EvaluationInput = {
  title: "AI Bootcamp",
  description: "A hands-on machine-learning bootcamp for students.",
  request_types: ["workshop"],
  organizing_entity: "college",
  entity_detail: "college:computer_science",
  activity_date: "2026-10-01",
  start_time: "09:00",
  end_time: "15:00",
  target_audience: ["students"],
  expected_attendance: 120,
  activity_format: "in_person",
  venue: "main_campus",
  external_host: null,
  represents_university: false,
  has_students: true,
  student_count: 100,
  has_faculty: true,
  faculty_count: 5,
  has_partners: false,
  partners: [],
  sdgs: ["sdg4"],
  expected_outputs: ["ideas", "prototypes"],
  impact_indicators: null,
  followup_pathways: ["incubation"],
  needs_funding: false,
  funding_source: null,
  budget_items: [],
  focus_areas: ["entrepreneurship"],
  grand_challenges: [],
};

describe("buildEvaluationDocument", () => {
  it("includes the filled fields", () => {
    const doc = buildEvaluationDocument(request);
    expect(doc).toContain("AI Bootcamp");
    expect(doc).toContain("Expected attendance: 120");
    expect(doc).toContain("Student participation: yes (100)");
  });

  it("omits empty fields entirely", () => {
    const doc = buildEvaluationDocument(request);
    expect(doc).not.toContain("External host");
    expect(doc).not.toContain("Impact indicators");
    expect(doc).not.toContain("Grand challenges");
  });
});

describe("instructions", () => {
  it("switch output language by locale", () => {
    expect(buildEvaluationInstructions("ar")).toContain("Arabic");
    expect(buildEvaluationInstructions("en")).toContain("English");
    expect(buildSummaryInstructions("request", "ar")).toContain("Arabic");
  });

  it("evaluation instructions name every criterion", () => {
    const text = buildEvaluationInstructions("en");
    for (const key of [
      "clarity_objectives",
      "relevance",
      "expected_impact",
      "feasibility",
      "strategic_alignment",
      "outputs_quality",
    ]) {
      expect(text).toContain(key);
    }
  });
});

describe("buildReportDocument", () => {
  it("flattens report fields and skips absent ones", () => {
    const doc = buildReportDocument(
      {
        implementation_summary: "Went well.",
        actual_date: "2026-10-01",
        actual_location: "Main hall",
        actual_attendance: 110,
        student_count: 90,
        ideas_received: 12,
        projects_nominated: 3,
        projects_nominated_desc: null,
        partnerships: null,
        actual_budget: [],
      },
      "AI Bootcamp",
    );
    expect(doc).toContain("Event: AI Bootcamp");
    expect(doc).toContain("Actual attendance: 110");
    expect(doc).not.toContain("Partnerships");
    expect(doc).not.toContain("Budget");
  });
});
