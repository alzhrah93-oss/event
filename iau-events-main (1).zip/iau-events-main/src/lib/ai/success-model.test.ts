import { describe, expect, it } from "vitest";
import {
  buildSuccessModel,
  FEATURE_NAMES,
  featurize,
  looCrossValidate,
  MIN_TRAINING_EVENTS,
  predictSuccess,
  type LabeledEvent,
  type SuccessFeaturesInput,
} from "./success-model";

const base: SuccessFeaturesInput = {
  expected_attendance: 100,
  activity_format: "in_person",
  request_types: ["event"],
  activity_date: "2026-03-10",
  start_time: "09:00",
  end_time: "13:00",
  has_students: true,
  has_faculty: false,
  has_partners: false,
  sdgs: ["sdg4"],
  expected_outputs: ["ideas"],
};

/** Synthetic history where in-person events with students succeed. */
function syntheticHistory(): LabeledEvent[] {
  const events: LabeledEvent[] = [];
  for (let i = 0; i < 10; i++) {
    events.push({
      ...base,
      expected_attendance: 50 + i * 20,
      activity_date: `2026-${String((i % 12) + 1).padStart(2, "0")}-15`,
      activity_format: "in_person",
      has_students: true,
      success: true,
    });
    events.push({
      ...base,
      expected_attendance: 400 + i * 50,
      activity_date: `2026-${String((i % 12) + 1).padStart(2, "0")}-20`,
      activity_format: "virtual",
      has_students: false,
      success: false,
    });
  }
  return events;
}

describe("featurize", () => {
  it("produces one value per feature name", () => {
    expect(featurize(base)).toHaveLength(FEATURE_NAMES.length);
  });

  it("encodes duration and format", () => {
    const x = featurize(base);
    expect(x[FEATURE_NAMES.indexOf("duration_hours")]).toBeCloseTo(4);
    expect(x[FEATURE_NAMES.indexOf("is_in_person")]).toBe(1);
    expect(
      featurize({ ...base, activity_format: "virtual" })[
        FEATURE_NAMES.indexOf("is_in_person")
      ],
    ).toBe(0);
  });

  it("log-scales attendance", () => {
    const x = featurize({ ...base, expected_attendance: 0 });
    expect(x[FEATURE_NAMES.indexOf("expected_attendance_log")]).toBe(0);
  });
});

describe("buildSuccessModel / predictSuccess", () => {
  it("rejects a training set that is too small", () => {
    expect(() =>
      buildSuccessModel(syntheticHistory().slice(0, MIN_TRAINING_EVENTS - 1)),
    ).toThrow();
  });

  it("learns a separable pattern from history", () => {
    const trained = buildSuccessModel(syntheticHistory());
    const good = predictSuccess(trained, {
      ...base,
      activity_format: "in_person",
      has_students: true,
      expected_attendance: 80,
    });
    const bad = predictSuccess(trained, {
      ...base,
      activity_format: "virtual",
      has_students: false,
      expected_attendance: 600,
    });
    expect(good.probability).toBeGreaterThan(0.6);
    expect(bad.probability).toBeLessThan(0.4);
    expect(good.probability).toBeGreaterThan(bad.probability);
  });

  it("returns bounded probabilities and ranked factors", () => {
    const trained = buildSuccessModel(syntheticHistory());
    const p = predictSuccess(trained, base);
    expect(p.probability).toBeGreaterThanOrEqual(0);
    expect(p.probability).toBeLessThanOrEqual(1);
    expect(p.factors.length).toBeLessThanOrEqual(5);
    for (let i = 1; i < p.factors.length; i++) {
      expect(Math.abs(p.factors[i - 1].contribution)).toBeGreaterThanOrEqual(
        Math.abs(p.factors[i].contribution),
      );
    }
  });

  it("maps probability to likelihood bands", () => {
    const trained = buildSuccessModel(syntheticHistory());
    const p = predictSuccess(trained, {
      ...base,
      activity_format: "in_person",
      has_students: true,
    });
    if (p.probability >= 0.7) expect(p.likelihood).toBe("high");
    else if (p.probability >= 0.4) expect(p.likelihood).toBe("medium");
    else expect(p.likelihood).toBe("low");
  });
});

describe("looCrossValidate", () => {
  it("scores well on cleanly separable data", () => {
    const metrics = looCrossValidate(syntheticHistory());
    expect(metrics.accuracy).toBeGreaterThan(0.8);
    expect(metrics.f1).toBeGreaterThan(0.8);
  });

  it("returns metrics in [0, 1]", () => {
    const metrics = looCrossValidate(syntheticHistory());
    for (const v of Object.values(metrics)) {
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThanOrEqual(1);
    }
  });
});
