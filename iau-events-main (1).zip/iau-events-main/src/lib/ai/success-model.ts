/**
 * Event Success Prediction — classical supervised machine learning, no LLM.
 *
 * A logistic-regression classifier implemented in plain TypeScript:
 *   historical closed events -> feature vectors + success labels -> gradient
 *   descent training -> probability prediction for a new request.
 *
 * Success (the target) follows the Institute's definition:
 *   attendance rate = actual attendance / expected attendance >= 0.8  ->  1
 *
 * The training set is small today, so the model uses few features, L2
 * regularization, and reports honest leave-one-out cross-validation metrics
 * alongside every prediction.
 */

export const SUCCESS_ATTENDANCE_RATE = 0.8;

/** Request-side fields available before the event happens. */
export type SuccessFeaturesInput = {
  expected_attendance: number;
  activity_format: string; // "in_person" | "virtual" | "hybrid" | ...
  request_types: string[];
  activity_date: string; // ISO date
  start_time: string; // "HH:MM[:SS]"
  end_time: string;
  has_students: boolean;
  has_faculty: boolean;
  has_partners: boolean;
  sdgs: string[];
  expected_outputs: string[];
};

export type LabeledEvent = SuccessFeaturesInput & { success: boolean };

export const FEATURE_NAMES = [
  "expected_attendance_log",
  "duration_hours",
  "month_sin",
  "month_cos",
  "is_in_person",
  "has_students",
  "has_faculty",
  "has_partners",
  "sdgs_count",
  "outputs_count",
] as const;

export type FeatureName = (typeof FEATURE_NAMES)[number];

const timeToHours = (t: string): number => {
  const [h, m] = t.split(":").map(Number);
  return (h ?? 0) + (m ?? 0) / 60;
};

/** Encode one event into a numeric feature vector (order = FEATURE_NAMES). */
export function featurize(e: SuccessFeaturesInput): number[] {
  const month = new Date(e.activity_date + "T00:00:00Z").getUTCMonth() + 1;
  const duration = Math.max(0, timeToHours(e.end_time) - timeToHours(e.start_time));
  return [
    Math.log1p(Math.max(0, e.expected_attendance)),
    duration,
    Math.sin((2 * Math.PI * month) / 12),
    Math.cos((2 * Math.PI * month) / 12),
    e.activity_format === "in_person" ? 1 : 0,
    e.has_students ? 1 : 0,
    e.has_faculty ? 1 : 0,
    e.has_partners ? 1 : 0,
    e.sdgs.length,
    e.expected_outputs.length,
  ];
}

export type Standardization = { means: number[]; stds: number[] };

/** Column-wise z-score parameters (std 1 for constant columns). */
export function fitStandardization(X: number[][]): Standardization {
  const d = X[0].length;
  const means = new Array<number>(d).fill(0);
  const stds = new Array<number>(d).fill(0);
  for (const row of X) for (let j = 0; j < d; j++) means[j] += row[j] / X.length;
  for (const row of X)
    for (let j = 0; j < d; j++) stds[j] += (row[j] - means[j]) ** 2 / X.length;
  for (let j = 0; j < d; j++) stds[j] = Math.sqrt(stds[j]) || 1;
  return { means, stds };
}

export const standardize = (x: number[], s: Standardization): number[] =>
  x.map((v, j) => (v - s.means[j]) / s.stds[j]);

export type LogisticModel = { weights: number[]; bias: number };

const sigmoid = (z: number) => 1 / (1 + Math.exp(-z));

export const predictProbability = (m: LogisticModel, x: number[]): number =>
  sigmoid(m.weights.reduce((acc, w, j) => acc + w * x[j], m.bias));

/**
 * Batch gradient descent on the regularized log-loss.
 * Inputs are expected to be standardized already.
 */
export function trainLogistic(
  X: number[][],
  y: number[],
  opts: { epochs?: number; learningRate?: number; l2?: number } = {},
): LogisticModel {
  const { epochs = 800, learningRate = 0.3, l2 = 0.05 } = opts;
  const n = X.length;
  const d = X[0].length;
  const weights = new Array<number>(d).fill(0);
  let bias = 0;

  for (let epoch = 0; epoch < epochs; epoch++) {
    const gradW = new Array<number>(d).fill(0);
    let gradB = 0;
    for (let i = 0; i < n; i++) {
      const err = predictProbability({ weights, bias }, X[i]) - y[i];
      for (let j = 0; j < d; j++) gradW[j] += (err * X[i][j]) / n;
      gradB += err / n;
    }
    for (let j = 0; j < d; j++)
      weights[j] -= learningRate * (gradW[j] + (l2 * weights[j]) / n);
    bias -= learningRate * gradB;
  }
  return { weights, bias };
}

export type ModelMetrics = {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
};

/**
 * Leave-one-out cross-validation: with a small dataset this is the honest way
 * to estimate out-of-sample performance (each event is predicted by a model
 * that never saw it).
 */
export function looCrossValidate(events: LabeledEvent[]): ModelMetrics {
  let tp = 0,
    tn = 0,
    fp = 0,
    fn = 0;
  for (let i = 0; i < events.length; i++) {
    const trainSet = events.filter((_, idx) => idx !== i);
    const { model, std } = fitModel(trainSet);
    const x = standardize(featurize(events[i]), std);
    const predicted = predictProbability(model, x) >= 0.5;
    const actual = events[i].success;
    if (predicted && actual) tp++;
    else if (!predicted && !actual) tn++;
    else if (predicted && !actual) fp++;
    else fn++;
  }
  const total = tp + tn + fp + fn;
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
  return {
    accuracy: total > 0 ? (tp + tn) / total : 0,
    precision,
    recall,
    f1: precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0,
  };
}

function fitModel(events: LabeledEvent[]): {
  model: LogisticModel;
  std: Standardization;
} {
  const rawX = events.map(featurize);
  const std = fitStandardization(rawX);
  const X = rawX.map((x) => standardize(x, std));
  const y = events.map((e) => (e.success ? 1 : 0));
  return { model: trainLogistic(X, y), std };
}

export type TrainedSuccessModel = {
  model: LogisticModel;
  std: Standardization;
  metrics: ModelMetrics;
  trainedOn: number;
  positives: number;
};

export const MIN_TRAINING_EVENTS = 6;

/** Train on the full history and attach LOOCV metrics. */
export function buildSuccessModel(events: LabeledEvent[]): TrainedSuccessModel {
  if (events.length < MIN_TRAINING_EVENTS) {
    throw new Error(`Need at least ${MIN_TRAINING_EVENTS} labeled events.`);
  }
  const { model, std } = fitModel(events);
  return {
    model,
    std,
    metrics: looCrossValidate(events),
    trainedOn: events.length,
    positives: events.filter((e) => e.success).length,
  };
}

export type Prediction = {
  probability: number;
  likelihood: "high" | "medium" | "low";
  /** Signed contribution of each feature (weight x standardized value). */
  factors: { name: FeatureName; contribution: number }[];
};

export function predictSuccess(
  trained: TrainedSuccessModel,
  input: SuccessFeaturesInput,
): Prediction {
  const x = standardize(featurize(input), trained.std);
  const probability = predictProbability(trained.model, x);
  const factors = trained.model.weights
    .map((w, j) => ({ name: FEATURE_NAMES[j], contribution: w * x[j] }))
    .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
    .slice(0, 5);
  return {
    probability,
    likelihood: probability >= 0.7 ? "high" : probability >= 0.4 ? "medium" : "low",
    factors,
  };
}
