import { createClient } from "@/lib/supabase/server";
import {
  SUCCESS_ATTENDANCE_RATE,
  type LabeledEvent,
  type SuccessFeaturesInput,
} from "./success-model";

/**
 * Training data for the success-prediction model: every closed event with a
 * final report, labeled by the Institute's success definition
 * (actual/expected attendance >= 80%).
 */

const REQUEST_COLUMNS =
  "id, expected_attendance, activity_format, request_types, activity_date, start_time, end_time, has_students, has_faculty, has_partners, sdgs, expected_outputs";

type RequestRow = SuccessFeaturesInput & { id: string };

export async function loadLabeledEvents(): Promise<LabeledEvent[]> {
  const supabase = await createClient();
  const [{ data: requests }, { data: reports }] = await Promise.all([
    supabase.from("event_requests").select(REQUEST_COLUMNS).eq("status", "closed"),
    supabase.from("final_reports").select("request_id, actual_attendance"),
  ]);

  const actualByRequest = new Map(
    (reports ?? []).map((r) => [r.request_id as string, r.actual_attendance as number]),
  );

  return ((requests ?? []) as RequestRow[])
    .filter((r) => actualByRequest.has(r.id) && r.expected_attendance > 0)
    .map((r) => ({
      ...r,
      success:
        (actualByRequest.get(r.id) ?? 0) / r.expected_attendance >=
        SUCCESS_ATTENDANCE_RATE,
    }));
}
