import { z } from "zod";
import { zodOutputFormat } from "@anthropic-ai/sdk/helpers/zod";
import { AI_MODEL, getAnthropic } from "./client";

/**
 * AI Event Evaluation — the model reads the whole request semantically and
 * scores it against the Institute's review criteria. The output is constrained
 * to this schema (structured outputs), so the route can store it verbatim.
 */

export const EVALUATION_CRITERIA = [
  "clarity_objectives",
  "relevance",
  "expected_impact",
  "feasibility",
  "strategic_alignment",
  "outputs_quality",
] as const;

export const evaluationSchema = z.object({
  overallScore: z.number().describe("Overall evaluation from 0 to 100"),
  criteria: z.array(
    z.object({
      key: z.enum(EVALUATION_CRITERIA),
      score: z.number().describe("Criterion score from 0 to 10"),
      comment: z.string().describe("One-sentence justification"),
    }),
  ),
  strengths: z.array(z.string()).describe("2-4 concrete strengths"),
  weaknesses: z.array(z.string()).describe("2-4 concrete weaknesses or gaps"),
  recommendation: z
    .string()
    .describe("2-3 sentence recommendation for the reviewing admin"),
});

export type Evaluation = z.infer<typeof evaluationSchema>;

/** The request fields the evaluation prompt is built from. */
export type EvaluationInput = {
  title: string;
  description: string;
  request_types: string[];
  organizing_entity: string;
  entity_detail: string | null;
  activity_date: string;
  start_time: string;
  end_time: string;
  target_audience: string[];
  expected_attendance: number;
  activity_format: string;
  venue: string;
  external_host: string | null;
  represents_university: boolean;
  has_students: boolean;
  student_count: number | null;
  has_faculty: boolean;
  faculty_count: number | null;
  has_partners: boolean;
  partners: unknown[];
  sdgs: string[];
  expected_outputs: string[];
  impact_indicators: string | null;
  followup_pathways: string[];
  needs_funding: boolean;
  funding_source: string | null;
  budget_items: unknown[];
  focus_areas: string[];
  grand_challenges: string[];
};

const line = (label: string, value: unknown) => {
  if (value === null || value === undefined || value === "") return null;
  if (Array.isArray(value)) {
    if (value.length === 0) return null;
    return `${label}: ${value.map((v) => (typeof v === "string" ? v : JSON.stringify(v))).join("; ")}`;
  }
  return `${label}: ${String(value)}`;
};

/** Pure — unit-testable. Flattens the request into a readable brief. */
export function buildEvaluationDocument(r: EvaluationInput): string {
  return [
    line("Title", r.title),
    line("Description", r.description),
    line("Request types", r.request_types),
    line("Organizing entity", r.organizing_entity),
    line("Entity detail", r.entity_detail),
    line("Date", r.activity_date),
    line("Time", `${r.start_time} - ${r.end_time}`),
    line("Format", r.activity_format),
    line("Venue", r.venue),
    line("External host", r.external_host),
    line("Represents the university externally", r.represents_university),
    line("Target audience", r.target_audience),
    line("Expected attendance", r.expected_attendance),
    line(
      "Student participation",
      r.has_students ? `yes (${r.student_count ?? "count n/a"})` : "no",
    ),
    line(
      "Faculty participation",
      r.has_faculty ? `yes (${r.faculty_count ?? "count n/a"})` : "no",
    ),
    line("Partners", r.has_partners ? r.partners : "none"),
    line("SDGs", r.sdgs),
    line("Expected outputs", r.expected_outputs),
    line("Impact indicators", r.impact_indicators),
    line("Follow-up pathways", r.followup_pathways),
    line(
      "Funding",
      r.needs_funding ? `needed (source: ${r.funding_source ?? "n/a"})` : "not needed",
    ),
    line("Budget items", r.budget_items),
    line("Strategic focus areas", r.focus_areas),
    line("Grand challenges", r.grand_challenges),
  ]
    .filter(Boolean)
    .join("\n");
}

/** Pure — unit-testable. */
export function buildEvaluationInstructions(locale: "en" | "ar"): string {
  return [
    "You evaluate event requests submitted to the Innovation & Entrepreneurship Institute at Imam Abdulrahman Bin Faisal University (IAU).",
    "Assess the request semantically — judge the substance of what is written, not merely whether fields are filled.",
    "Score each criterion 0-10: clarity_objectives (are the objectives clear and specific?), relevance (relevance to the university and its community), expected_impact, feasibility (date, venue, budget, attendance realism), strategic_alignment (fit with the Institute's focus areas, grand challenges and SDGs), outputs_quality (are expected outputs concrete and measurable?).",
    "overallScore (0-100) reflects your holistic judgement, not an average.",
    "Be specific and reference the request's own content. Keep every comment to one sentence.",
    locale === "ar"
      ? "Write all comments, strengths, weaknesses and the recommendation in Arabic."
      : "Write in English.",
  ].join("\n");
}

/** Calls Claude and returns a schema-validated evaluation. */
export async function runEvaluation(
  input: EvaluationInput,
  locale: "en" | "ar",
): Promise<Evaluation> {
  const anthropic = getAnthropic();
  const response = await anthropic.beta.messages.create({
    model: AI_MODEL,
    max_tokens: 16000,
    // Safety classifiers can decline a request; the server-side fallback
    // re-runs it on the recommended fallback model instead of failing.
    betas: ["server-side-fallback-2026-07-01"],
    fallbacks: "default",
    system: buildEvaluationInstructions(locale),
    output_config: { format: zodOutputFormat(evaluationSchema) },
    messages: [
      {
        role: "user",
        content: `Evaluate this event request:\n\n${buildEvaluationDocument(input)}`,
      },
    ],
  });

  if (response.stop_reason === "refusal") {
    throw new Error("The model declined to evaluate this request.");
  }
  const text = response.content.find((b) => b.type === "text");
  if (!text || text.type !== "text") {
    throw new Error("Empty model response.");
  }
  const parsed = evaluationSchema.parse(JSON.parse(text.text));
  // Clamp defensively — schema can't express numeric ranges.
  parsed.overallScore = Math.max(0, Math.min(100, Math.round(parsed.overallScore)));
  for (const c of parsed.criteria) c.score = Math.max(0, Math.min(10, Math.round(c.score)));
  return parsed;
}
