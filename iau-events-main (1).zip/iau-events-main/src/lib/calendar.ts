export type DayCell = { date: string; inMonth: boolean };

function toIso(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/**
 * Build a Sunday-start week grid for a calendar month (month is 1-based).
 * Leading/trailing cells from adjacent months are marked `inMonth: false`.
 */
export function buildMonthGrid(year: number, month: number): DayCell[][] {
  const first = new Date(year, month - 1, 1);
  const start = new Date(first);
  start.setDate(first.getDate() - first.getDay()); // back to Sunday

  const weeks: DayCell[][] = [];
  const cursor = new Date(start);

  while (true) {
    const week: DayCell[] = [];
    for (let i = 0; i < 7; i++) {
      week.push({
        date: toIso(cursor),
        inMonth: cursor.getMonth() === month - 1,
      });
      cursor.setDate(cursor.getDate() + 1);
    }
    weeks.push(week);
    if (cursor.getMonth() !== month - 1 || weeks.length > 6) break;
  }
  return weeks;
}
