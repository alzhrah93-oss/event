import { describe, expect, it } from "vitest";
import { buildMonthGrid } from "./calendar";

describe("buildMonthGrid", () => {
  it("July 2026 starts on Wednesday and spans 5 weeks", () => {
    const grid = buildMonthGrid(2026, 7);
    expect(grid).toHaveLength(5);
    for (const week of grid) expect(week).toHaveLength(7);
    // 1 Jul 2026 is a Wednesday → index 3 in a Sunday-start week
    expect(grid[0][3]).toEqual({ date: "2026-07-01", inMonth: true });
    // leading cells belong to June
    expect(grid[0][0]).toEqual({ date: "2026-06-28", inMonth: false });
    // last day
    expect(grid[4][6]).toEqual({ date: "2026-08-01", inMonth: false });
  });

  it("handles leap-year February (2028 starts on Tuesday)", () => {
    const grid = buildMonthGrid(2028, 2);
    const days = grid.flat().filter((c) => c.inMonth);
    expect(days).toHaveLength(29);
    expect(days[0].date).toBe("2028-02-01");
    expect(days[28].date).toBe("2028-02-29");
  });

  it("month starting on Sunday has no leading out-of-month cells", () => {
    // Nov 2026 starts on Sunday
    const grid = buildMonthGrid(2026, 11);
    expect(grid[0][0]).toEqual({ date: "2026-11-01", inMonth: true });
  });

  it("6-week months render fully (Aug 2026: starts Sat, 31 days)", () => {
    const grid = buildMonthGrid(2026, 8);
    expect(grid).toHaveLength(6);
    expect(grid.flat().filter((c) => c.inMonth)).toHaveLength(31);
  });
});
