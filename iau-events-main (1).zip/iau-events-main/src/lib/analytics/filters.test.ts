import { describe, expect, it } from "vitest";
import {
  applyFilters,
  attendanceBucket,
  attendanceOf,
  EMPTY_FILTERS,
  type AnalyticsRow,
} from "./filters";

const row = (over: Partial<AnalyticsRow>): AnalyticsRow => ({
  id: "x",
  entity_detail: null,
  status: "approved",
  submitted_at: "2026-01-05T08:00:00Z",
  activity_date: "2026-03-10",
  organizing_entity: "college",
  decided_at: null,
  expected_attendance: 80,
  activity_format: "in_person",
  request_types: ["workshop"],
  venue: "on_campus",
  target_audience: ["students"],
  focus_areas: ["health-wellness"],
  grand_challenges: [],
  actual_attendance: null,
  student_count: null,
  ideas_received: null,
  projects_nominated: null,
  has_report: false,
  ...over,
});

describe("attendanceBucket", () => {
  it("buckets attendance figures", () => {
    expect(attendanceBucket(10)).toBe("lt50");
    expect(attendanceBucket(50)).toBe("b50_100");
    expect(attendanceBucket(99)).toBe("b50_100");
    expect(attendanceBucket(100)).toBe("b100_500");
    expect(attendanceBucket(500)).toBe("gte500");
  });
});

describe("attendanceOf", () => {
  it("prefers actual attendance from the report over expected", () => {
    expect(attendanceOf(row({ actual_attendance: 200 }))).toBe(200);
    expect(attendanceOf(row({}))).toBe(80);
  });
});

describe("applyFilters", () => {
  const rows = [
    row({ id: "a", activity_date: "2026-03-10", organizing_entity: "college", status: "approved", expected_attendance: 30 }),
    row({ id: "b", activity_date: "2026-07-01", organizing_entity: "institute", status: "not_approved", expected_attendance: 150 }),
    row({ id: "c", activity_date: "2025-03-15", organizing_entity: "college", status: "closed", expected_attendance: 700, actual_attendance: 650 }),
  ];

  it("no filters returns everything", () => {
    expect(applyFilters(rows, EMPTY_FILTERS)).toHaveLength(3);
  });

  it("filters by activity year and month", () => {
    expect(applyFilters(rows, { ...EMPTY_FILTERS, year: [2026] }).map((r) => r.id)).toEqual(["a", "b"]);
    expect(applyFilters(rows, { ...EMPTY_FILTERS, month: [3] }).map((r) => r.id)).toEqual(["a", "c"]);
    expect(applyFilters(rows, { ...EMPTY_FILTERS, year: [2026], month: [3] }).map((r) => r.id)).toEqual(["a"]);
    expect(applyFilters(rows, { ...EMPTY_FILTERS, year: [2025, 2026] })).toHaveLength(3);
  });

  it("filters by specific college (entity_detail), several at once", () => {
    const mixed = [
      row({ id: "m", organizing_entity: "college", entity_detail: "medicine" }),
      row({ id: "e", organizing_entity: "college", entity_detail: "engineering" }),
      row({ id: "d", organizing_entity: "deanship", entity_detail: "medicine" }),
    ];
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, college: ["medicine"] }).map((r) => r.id)).toEqual(["m"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, college: ["medicine", "engineering"] }).map((r) => r.id)).toEqual(["m", "e"]);
  });

  it("filters by entity, outcome, and attendance bucket", () => {
    expect(applyFilters(rows, { ...EMPTY_FILTERS, entity: ["college"] })).toHaveLength(2);
    expect(applyFilters(rows, { ...EMPTY_FILTERS, status: ["not_approved"] }).map((r) => r.id)).toEqual(["b"]);
    expect(applyFilters(rows, { ...EMPTY_FILTERS, status: ["approved", "not_approved"] }).map((r) => r.id)).toEqual(["a", "b"]);
    expect(applyFilters(rows, { ...EMPTY_FILTERS, attendance: ["gte500"] }).map((r) => r.id)).toEqual(["c"]);
  });

  it("combines filters (AND across dimensions)", () => {
    expect(
      applyFilters(rows, { ...EMPTY_FILTERS, year: [2026], entity: ["college"], attendance: ["lt50"] }).map((r) => r.id),
    ).toEqual(["a"]);
  });

  it("multiple focus areas combine as OR (health or energy or both)", () => {
    const mixed = [
      row({ id: "h", focus_areas: ["health-wellness"] }),
      row({ id: "e", focus_areas: ["energy-industrials"] }),
      row({ id: "b", focus_areas: ["health-wellness", "energy-industrials"] }),
      row({ id: "x", focus_areas: ["ai-education"] }),
    ];
    expect(
      applyFilters(mixed, { ...EMPTY_FILTERS, focusArea: ["health-wellness", "energy-industrials"] }).map((r) => r.id),
    ).toEqual(["h", "e", "b"]);
  });

  it("filters by format, venue, type, audience, focus area, grand challenge, and report", () => {
    const mixed = [
      row({ id: "p", activity_format: "virtual", venue: "off_campus", request_types: ["forum", "workshop"], target_audience: ["researchers"], focus_areas: ["ai-education"], grand_challenges: ["cancer_rates"], has_report: true }),
      row({ id: "q" }),
    ];
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, format: ["virtual"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, venue: ["off_campus"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, type: ["forum"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, type: ["workshop"] })).toHaveLength(2);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, audience: ["researchers"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, focusArea: ["ai-education"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, grandChallenge: ["cancer_rates"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, report: ["submitted"] }).map((r) => r.id)).toEqual(["p"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, report: ["missing"] }).map((r) => r.id)).toEqual(["q"]);
    expect(applyFilters(mixed, { ...EMPTY_FILTERS, report: ["submitted", "missing"] })).toHaveLength(2);
  });
});
