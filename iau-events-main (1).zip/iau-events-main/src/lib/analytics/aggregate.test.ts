import { describe, expect, it } from "vitest";
import {
  availableYears,
  decisionByMonth,
  distributionOf,
  monthlyCounts,
  rankBy,
  reportCompliance,
  type AnalyticsRequest,
} from "./aggregate";

const reqs: AnalyticsRequest[] = [
  { status: "approved", submitted_at: "2026-01-10T08:00:00Z", activity_date: "2026-02-05", organizing_entity: "college", decided_at: "2026-01-15T08:00:00Z", has_report: true },
  { status: "approved", submitted_at: "2026-01-20T08:00:00Z", activity_date: "2026-03-01", organizing_entity: "college", decided_at: "2026-02-01T08:00:00Z", has_report: false },
  { status: "not_approved", submitted_at: "2026-02-02T08:00:00Z", activity_date: "2026-04-10", organizing_entity: "institute", decided_at: "2026-02-08T08:00:00Z", has_report: false },
  { status: "under_review", submitted_at: "2026-02-14T08:00:00Z", activity_date: "2026-05-20", organizing_entity: "deanship", decided_at: null, has_report: false },
  { status: "closed", submitted_at: "2025-11-01T08:00:00Z", activity_date: "2025-12-10", organizing_entity: "college", decided_at: "2025-11-10T08:00:00Z", has_report: true },
];

describe("availableYears", () => {
  it("collects distinct years from submissions, newest first", () => {
    expect(availableYears(reqs)).toEqual([2026, 2025]);
  });
});

describe("monthlyCounts", () => {
  it("counts by submission month for a year", () => {
    const m = monthlyCounts(reqs, 2026, "submitted_at");
    expect(m[0]).toBe(2); // Jan
    expect(m[1]).toBe(2); // Feb
    expect(m.reduce((a, b) => a + b, 0)).toBe(4);
  });

  it("counts events by activity month (approved/closed only)", () => {
    const m = monthlyCounts(
      reqs.filter((r) => r.status === "approved" || r.status === "closed"),
      2026,
      "activity_date",
    );
    expect(m[1]).toBe(1); // Feb event
    expect(m[2]).toBe(1); // Mar event
  });
});

describe("decisionByMonth", () => {
  it("splits approved vs not approved by decision month", () => {
    const d = decisionByMonth(reqs, 2026);
    expect(d[0]).toEqual({ approved: 1, notApproved: 0 }); // Jan
    expect(d[1]).toEqual({ approved: 1, notApproved: 1 }); // Feb
  });
});

describe("rankBy", () => {
  it("ranks entities by event count, descending", () => {
    const top = rankBy(
      reqs.filter((r) => r.status === "approved" || r.status === "closed"),
      (r) => r.organizing_entity,
    );
    expect(top[0]).toEqual({ key: "college", count: 3 });
  });
});

describe("distributionOf", () => {
  it("counts by status", () => {
    const d = distributionOf(reqs, (r) => r.status);
    expect(d.find((x) => x.key === "approved")?.count).toBe(2);
  });
});

describe("reportCompliance", () => {
  it("computes reports submitted vs due (approved past + closed)", () => {
    // due: approved with past activity (2026-02-05, 2026-03-01) + closed (1) = 3; submitted = 2
    const c = reportCompliance(reqs, "2026-07-16");
    expect(c).toEqual({ submitted: 2, due: 3, rate: 67 });
  });

  it("handles zero due", () => {
    expect(reportCompliance([], "2026-07-16")).toEqual({ submitted: 0, due: 0, rate: 100 });
  });
});
