import type { DataRow } from "./filters";
import { createClient } from "@/lib/supabase/server";

/**
 * One flattened row per request: request columns + strategic alignment
 * (focus areas, grand challenges) + final-report outputs when present.
 * Shared by the analytics dashboard and the events-data sheet.
 * `closedOnly` restricts to closed events (approved + final report submitted)
 * — the events-data sheet shows completed events, not in-flight requests.
 */
export async function loadAnalyticsRows(
  opts: { closedOnly?: boolean } = {},
): Promise<DataRow[]> {
  const supabase = await createClient();

  let requestsQuery = supabase
    .from("event_requests")
    .select(
      "id, request_number, title, applicant_name, status, submitted_at, activity_date, organizing_entity, entity_detail, decided_at, expected_attendance, activity_format, request_types, venue, target_audience",
    );
  if (opts.closedOnly) requestsQuery = requestsQuery.eq("status", "closed");

  const [{ data: requests }, { data: reports }, { data: alignment }] =
    await Promise.all([
      requestsQuery,
      supabase
        .from("final_reports")
        .select(
          "request_id, actual_attendance, student_count, ideas_received, projects_nominated",
        ),
      supabase
        .from("request_alignment")
        .select("request_id, focus_area_id, grand_challenges"),
    ]);

  const reportByRequest = new Map((reports ?? []).map((r) => [r.request_id, r]));
  const focusByRequest = new Map<string, string[]>();
  const challengesByRequest = new Map<string, string[]>();
  for (const a of alignment ?? []) {
    focusByRequest.set(a.request_id, [
      ...(focusByRequest.get(a.request_id) ?? []),
      a.focus_area_id,
    ]);
    challengesByRequest.set(a.request_id, [
      ...(challengesByRequest.get(a.request_id) ?? []),
      ...((a.grand_challenges ?? []) as string[]),
    ]);
  }

  return (requests ?? []).map((r) => {
    const rep = reportByRequest.get(r.id);
    return {
      ...r,
      has_report: !!rep,
      focus_areas: focusByRequest.get(r.id) ?? [],
      grand_challenges: challengesByRequest.get(r.id) ?? [],
      actual_attendance: rep?.actual_attendance ?? null,
      student_count: rep?.student_count ?? null,
      ideas_received: rep?.ideas_received ?? null,
      projects_nominated: rep?.projects_nominated ?? null,
    };
  });
}
