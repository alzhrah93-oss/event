import type { AnalyticsRequest } from "./aggregate";

/** Full analytics row: request columns + final-report outputs when present. */
export type AnalyticsRow = AnalyticsRequest & {
  id: string;
  /** College slug when organizing_entity = college (entity_detail column) */
  entity_detail: string | null;
  expected_attendance: number;
  activity_format: string;
  request_types: string[];
  venue: string;
  target_audience: string[];
  /** Focus areas selected in the request's strategic alignment */
  focus_areas: string[];
  /** Grand challenges selected in the request's strategic alignment */
  grand_challenges: string[];
  actual_attendance: number | null;
  student_count: number | null;
  ideas_received: number | null;
  projects_nominated: number | null;
};

/** Analytics row plus the identifying fields the data-sheet page shows. */
export type DataRow = AnalyticsRow & {
  request_number: string;
  title: string;
  applicant_name: string;
};

export type AttendanceBucket = "lt50" | "b50_100" | "b100_500" | "gte500";

/**
 * Every dimension is multi-select: an empty array means "all"; several
 * values combine as OR within the dimension (e.g. focus area health OR
 * energy), while different dimensions combine as AND.
 */
export type EventFilters = {
  year: number[];
  month: number[]; // 1-based
  entity: string[];
  /** Specific entity (entity_detail) per organizing-entity type */
  college: string[];
  deanship: string[];
  institute: string[];
  center: string[];
  status: string[];
  attendance: AttendanceBucket[];
  format: string[];
  venue: string[];
  type: string[];
  audience: string[];
  focusArea: string[];
  grandChallenge: string[];
  report: ("submitted" | "missing")[];
};

export const EMPTY_FILTERS: EventFilters = {
  year: [],
  month: [],
  entity: [],
  college: [],
  deanship: [],
  institute: [],
  center: [],
  status: [],
  attendance: [],
  format: [],
  venue: [],
  type: [],
  audience: [],
  focusArea: [],
  grandChallenge: [],
  report: [],
};

export function attendanceBucket(n: number): AttendanceBucket {
  if (n < 50) return "lt50";
  if (n < 100) return "b50_100";
  if (n < 500) return "b100_500";
  return "gte500";
}

/** Actual attendance from the final report when available, else expected. */
export function attendanceOf(r: AnalyticsRow): number {
  return r.actual_attendance ?? r.expected_attendance;
}

/** Filters apply to the activity (event) date and its attributes. */
export function applyFilters(
  rows: AnalyticsRow[],
  f: EventFilters,
): AnalyticsRow[] {
  // Empty selection = dimension not filtered; otherwise the row must match
  // at least one selected value (OR within the dimension).
  const pass = <T,>(selected: T[], ok: boolean) => selected.length === 0 || ok;
  return rows.filter((r) => {
    if (!pass(f.year, f.year.includes(Number(r.activity_date.slice(0, 4)))))
      return false;
    if (!pass(f.month, f.month.includes(Number(r.activity_date.slice(5, 7)))))
      return false;
    if (!pass(f.entity, f.entity.includes(r.organizing_entity))) return false;
    const byDetail = (type: string, wanted: string[]) =>
      pass(
        wanted,
        r.organizing_entity === type &&
          r.entity_detail !== null &&
          wanted.includes(r.entity_detail),
      );
    if (!byDetail("college", f.college)) return false;
    if (!byDetail("deanship", f.deanship)) return false;
    if (!byDetail("institute", f.institute)) return false;
    if (!byDetail("center", f.center)) return false;
    if (!pass(f.status, f.status.includes(r.status))) return false;
    if (
      !pass(
        f.attendance,
        f.attendance.includes(attendanceBucket(attendanceOf(r))),
      )
    )
      return false;
    if (!pass(f.format, f.format.includes(r.activity_format))) return false;
    if (!pass(f.venue, f.venue.includes(r.venue))) return false;
    if (!pass(f.type, r.request_types.some((t) => f.type.includes(t))))
      return false;
    if (
      !pass(f.audience, r.target_audience.some((a) => f.audience.includes(a)))
    )
      return false;
    if (!pass(f.focusArea, r.focus_areas.some((fa) => f.focusArea.includes(fa))))
      return false;
    if (
      !pass(
        f.grandChallenge,
        r.grand_challenges.some((gc) => f.grandChallenge.includes(gc)),
      )
    )
      return false;
    if (
      !pass(
        f.report,
        f.report.includes(r.has_report ? "submitted" : "missing"),
      )
    )
      return false;
    return true;
  });
}
