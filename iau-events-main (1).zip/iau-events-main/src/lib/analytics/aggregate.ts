import type { RequestStatus } from "@/lib/requests/status";

/** Minimal request shape fetched for analytics (admin-only page). */
export type AnalyticsRequest = {
  status: RequestStatus | string;
  submitted_at: string;
  activity_date: string;
  organizing_entity: string;
  decided_at: string | null;
  has_report: boolean;
};

const year = (iso: string) => Number(iso.slice(0, 4));
const month = (iso: string) => Number(iso.slice(5, 7)) - 1; // 0-based

/** Distinct submission years, newest first. */
export function availableYears(reqs: AnalyticsRequest[]): number[] {
  return [...new Set(reqs.map((r) => year(r.submitted_at)))].sort(
    (a, b) => b - a,
  );
}

/** 12 counts (Jan..Dec) of `field` dates falling in `y`. */
export function monthlyCounts(
  reqs: AnalyticsRequest[],
  y: number,
  field: "submitted_at" | "activity_date",
): number[] {
  const out = Array(12).fill(0) as number[];
  for (const r of reqs) {
    const d = r[field];
    if (d && year(d) === y) out[month(d)]++;
  }
  return out;
}

/** Approved vs not-approved decisions per month of `y`. */
export function decisionByMonth(
  reqs: AnalyticsRequest[],
  y: number,
): { approved: number; notApproved: number }[] {
  const out = Array.from({ length: 12 }, () => ({
    approved: 0,
    notApproved: 0,
  }));
  for (const r of reqs) {
    if (!r.decided_at || year(r.decided_at) !== y) continue;
    const m = month(r.decided_at);
    // closed requests were approved first
    if (r.status === "approved" || r.status === "closed")
      out[m].approved++;
    else if (r.status === "not_approved") out[m].notApproved++;
  }
  return out;
}

/** Count by key, descending. */
export function rankBy<T>(
  items: T[],
  keyOf: (item: T) => string,
): { key: string; count: number }[] {
  const map = new Map<string, number>();
  for (const it of items) {
    const k = keyOf(it);
    map.set(k, (map.get(k) ?? 0) + 1);
  }
  return [...map.entries()]
    .map(([key, count]) => ({ key, count }))
    .sort((a, b) => b.count - a.count);
}

export const distributionOf = rankBy;

/** Final-report compliance: submitted vs due (approved & ended, or closed). */
export function reportCompliance(
  reqs: AnalyticsRequest[],
  todayIso: string = new Date().toISOString().slice(0, 10),
): { submitted: number; due: number; rate: number } {
  const due = reqs.filter(
    (r) =>
      r.status === "closed" ||
      (r.status === "approved" && r.activity_date < todayIso),
  );
  const submitted = due.filter((r) => r.has_report).length;
  const rate = due.length === 0 ? 100 : Math.round((submitted / due.length) * 100);
  return { submitted, due: due.length, rate };
}
