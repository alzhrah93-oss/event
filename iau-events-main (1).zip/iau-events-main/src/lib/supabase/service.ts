import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

/**
 * Service-role client for trusted server jobs (cron). Bypasses RLS.
 * SUPABASE_SERVICE_ROLE_KEY is added by the platform owner to the server
 * environment at deploy time — never committed, never sent to the browser.
 * Returns null when unconfigured so callers can no-op gracefully.
 */
export function createServiceClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) return null;
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    key,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );
}
