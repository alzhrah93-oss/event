import type { Localized } from "./content";

/**
 * Event shape shared by the marquee cards, calendar, and (later) dashboards.
 *
 * DEMO DATA CONTRACT: `DEMO_EVENTS` is placeholder content for the public
 * site until the Supabase phase. The replacement query must return the same
 * `EventItem` shape so consumers stay untouched.
 */
export type EventItem = {
  id: string;
  name: Localized;
  place: Localized;
  /** ISO date, e.g. "2026-07-20" */
  date: string;
  /** 24h "HH:MM" */
  startTime: string;
  endTime: string;
  type: Localized;
  college: Localized;
};

export const DEMO_EVENTS: EventItem[] = [
  {
    id: "ev-001",
    name: {
      en: "Innovation Bootcamp: From Idea to Prototype",
      ar: "معسكر الابتكار: من الفكرة إلى النموذج الأولي",
    },
    place: { en: "IIE Main Hall, Dammam Campus", ar: "القاعة الرئيسية للمعهد، مقر الدمام" },
    date: "2026-07-16",
    startTime: "09:00",
    endTime: "15:00",
    type: { en: "Program", ar: "برنامج" },
    college: { en: "Institute of Innovation & Entrepreneurship", ar: "معهد الابتكار وريادة الأعمال" },
  },
  {
    id: "ev-002",
    name: {
      en: "Health Innovation Hackathon",
      ar: "هاكاثون الابتكار الصحي",
    },
    place: { en: "College of Medicine Auditorium", ar: "مدرج كلية الطب" },
    date: "2026-07-22",
    startTime: "08:30",
    endTime: "20:00",
    type: { en: "Competition", ar: "مسابقة" },
    college: { en: "College of Medicine", ar: "كلية الطب" },
  },
  {
    id: "ev-003",
    name: {
      en: "Entrepreneurship Clinic: Business Model Design",
      ar: "عيادة ريادة الأعمال: تصميم نموذج العمل",
    },
    place: { en: "IIE Training Room 2", ar: "قاعة التدريب 2 بالمعهد" },
    date: "2026-07-28",
    startTime: "13:00",
    endTime: "16:00",
    type: { en: "Workshop", ar: "ورشة عمل" },
    college: { en: "College of Business Administration", ar: "كلية إدارة الأعمال" },
  },
  {
    id: "ev-004",
    name: {
      en: "AI in Education Forum",
      ar: "منتدى الذكاء الاصطناعي في التعليم",
    },
    place: { en: "University Conference Center", ar: "مركز مؤتمرات الجامعة" },
    date: "2026-08-04",
    startTime: "10:00",
    endTime: "14:00",
    type: { en: "Forum", ar: "منتدى" },
    college: { en: "College of Education", ar: "كلية التربية" },
  },
  {
    id: "ev-005",
    name: {
      en: "Sustainable Energy Startups Showcase",
      ar: "معرض الشركات الناشئة في الطاقة المستدامة",
    },
    place: { en: "College of Engineering Plaza", ar: "ساحة كلية الهندسة" },
    date: "2026-08-12",
    startTime: "09:00",
    endTime: "17:00",
    type: { en: "Exhibition", ar: "معرض" },
    college: { en: "College of Engineering", ar: "كلية الهندسة" },
  },
  {
    id: "ev-006",
    name: {
      en: "Intellectual Property for Researchers",
      ar: "الملكية الفكرية للباحثين",
    },
    place: { en: "Online (Virtual)", ar: "عن بُعد (افتراضي)" },
    date: "2026-08-19",
    startTime: "11:00",
    endTime: "13:00",
    type: { en: "Training", ar: "تدريب" },
    college: { en: "Deanship of Scientific Research", ar: "عمادة البحث العلمي" },
  },
  {
    id: "ev-007",
    name: {
      en: "Digital Tourism Ideathon",
      ar: "أيديثون السياحة الرقمية",
    },
    place: { en: "IIE Innovation Lab", ar: "مختبر الابتكار بالمعهد" },
    date: "2026-08-26",
    startTime: "09:30",
    endTime: "18:00",
    type: { en: "Competition", ar: "مسابقة" },
    college: {
      en: "College of Computer Science & IT",
      ar: "كلية علوم الحاسب وتقنية المعلومات",
    },
  },
  {
    id: "ev-008",
    name: {
      en: "Founders Talk: Scaling Saudi Startups",
      ar: "حديث المؤسسين: نمو الشركات الناشئة السعودية",
    },
    place: { en: "IIE Main Hall, Dammam Campus", ar: "القاعة الرئيسية للمعهد، مقر الدمام" },
    date: "2026-09-02",
    startTime: "18:00",
    endTime: "20:00",
    type: { en: "Event", ar: "فعالية" },
    college: { en: "Institute of Innovation & Entrepreneurship", ar: "معهد الابتكار وريادة الأعمال" },
  },
  {
    id: "ev-009",
    name: {
      en: "Smart Supply Chains Research Workshop",
      ar: "ورشة أبحاث سلاسل الإمداد الذكية",
    },
    place: { en: "College of Applied Studies Hall 5", ar: "قاعة 5 بكلية الدراسات التطبيقية" },
    date: "2026-09-15",
    startTime: "10:00",
    endTime: "13:30",
    type: { en: "Workshop", ar: "ورشة عمل" },
    college: {
      en: "College of Applied Studies & Community Service",
      ar: "كلية الدراسات التطبيقية وخدمة المجتمع",
    },
  },
  {
    id: "ev-010",
    name: {
      en: "National Innovation Week at IAU",
      ar: "أسبوع الابتكار الوطني في الجامعة",
    },
    place: { en: "University Main Campus", ar: "الحرم الجامعي الرئيسي" },
    date: "2026-10-06",
    startTime: "09:00",
    endTime: "21:00",
    type: { en: "Exhibition", ar: "معرض" },
    college: { en: "All Colleges", ar: "جميع الكليات" },
  },
];

/** Events within a calendar month (month is 1-based), sorted by date. */
export function getEventsForMonth(
  year: number,
  month: number,
  events: EventItem[] = DEMO_EVENTS,
): EventItem[] {
  const prefix = `${year}-${String(month).padStart(2, "0")}-`;
  return events
    .filter((e) => e.date.startsWith(prefix))
    .sort((a, b) => a.date.localeCompare(b.date));
}

/** Ongoing (today) and upcoming events, sorted ascending by date. */
export function getOngoingAndUpcoming(
  events: EventItem[] = DEMO_EVENTS,
  todayIso: string = new Date().toISOString().slice(0, 10),
): EventItem[] {
  return events
    .filter((e) => e.date >= todayIso)
    .sort((a, b) => a.date.localeCompare(b.date));
}
