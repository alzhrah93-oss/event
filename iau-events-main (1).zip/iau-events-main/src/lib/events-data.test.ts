import { describe, expect, it } from "vitest";
import {
  DEMO_EVENTS,
  getEventsForMonth,
  getOngoingAndUpcoming,
  type EventItem,
} from "./events-data";

describe("DEMO_EVENTS", () => {
  it("has at least 8 events with complete card fields", () => {
    expect(DEMO_EVENTS.length).toBeGreaterThanOrEqual(8);
    for (const e of DEMO_EVENTS) {
      expect(e.id).toBeTruthy();
      expect(e.name.en).toBeTruthy();
      expect(e.name.ar).toBeTruthy();
      expect(e.place.en).toBeTruthy();
      expect(e.place.ar).toBeTruthy();
      expect(e.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(e.startTime).toMatch(/^\d{2}:\d{2}$/);
      expect(e.endTime).toMatch(/^\d{2}:\d{2}$/);
      expect(e.type.en).toBeTruthy();
      expect(e.college.en).toBeTruthy();
    }
  });
});

describe("getEventsForMonth", () => {
  it("returns only events in the given year+month", () => {
    const sample: EventItem[] = [
      makeEvent("a", "2026-07-20"),
      makeEvent("b", "2026-08-01"),
      makeEvent("c", "2026-07-05"),
      makeEvent("d", "2025-07-15"),
    ];
    const july = getEventsForMonth(2026, 7, sample);
    expect(july.map((e) => e.id)).toEqual(["c", "a"]); // sorted by date
  });

  it("returns empty array when no events match", () => {
    expect(getEventsForMonth(1999, 1, DEMO_EVENTS)).toEqual([]);
  });
});

describe("getOngoingAndUpcoming", () => {
  it("excludes past events and sorts ascending by date", () => {
    const today = "2026-07-15";
    const sample: EventItem[] = [
      makeEvent("past", "2026-07-01"),
      makeEvent("today", "2026-07-15"),
      makeEvent("later", "2026-09-10"),
      makeEvent("soon", "2026-07-20"),
    ];
    const result = getOngoingAndUpcoming(sample, today);
    expect(result.map((e) => e.id)).toEqual(["today", "soon", "later"]);
  });
});

function makeEvent(id: string, date: string): EventItem {
  return {
    id,
    name: { en: id, ar: id },
    place: { en: "Hall A", ar: "قاعة أ" },
    date,
    startTime: "09:00",
    endTime: "12:00",
    type: { en: "Workshop", ar: "ورشة عمل" },
    college: { en: "IIE", ar: "معهد الابتكار" },
  };
}
