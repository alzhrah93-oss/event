export type RequestStatus =
  | "entity_review"
  | "new"
  | "pending_completion"
  | "under_review"
  | "awaiting_final"
  | "approved"
  | "not_approved"
  | "entity_rejected"
  | "cancelled"
  | "closed";

/** Badge styling tokens per status (Tailwind classes, light theme). */
export const STATUS_META: Record<
  RequestStatus,
  { badge: string; dot: string }
> = {
  entity_review: {
    badge: "bg-cyan-50 text-cyan-700 border-cyan-200",
    dot: "bg-cyan-500",
  },
  new: { badge: "bg-blue-50 text-blue-700 border-blue-200", dot: "bg-blue-500" },
  pending_completion: {
    badge: "bg-amber-50 text-amber-800 border-amber-200",
    dot: "bg-amber-500",
  },
  under_review: {
    badge: "bg-indigo-50 text-indigo-700 border-indigo-200",
    dot: "bg-indigo-500",
  },
  awaiting_final: {
    badge: "bg-purple-50 text-purple-700 border-purple-200",
    dot: "bg-purple-500",
  },
  approved: {
    badge: "bg-emerald-50 text-emerald-700 border-emerald-200",
    dot: "bg-emerald-500",
  },
  not_approved: {
    badge: "bg-red-50 text-red-700 border-red-200",
    dot: "bg-red-500",
  },
  entity_rejected: {
    badge: "bg-red-50 text-red-700 border-red-200",
    dot: "bg-red-500",
  },
  cancelled: {
    badge: "bg-gray-100 text-gray-600 border-gray-200",
    dot: "bg-gray-400",
  },
  closed: {
    badge: "bg-iau-green-light text-iau-green-dark border-iau-green/30",
    dot: "bg-iau-green",
  },
};

/**
 * Position on the 5-stage tracker:
 * 1 Submitted · 2 Entity Approval · 3 Institute Review · 4 Decision · 5 Closed.
 * Cancelled requests show a notice instead (stage 0).
 */
export function progressStage(status: RequestStatus): 0 | 1 | 2 | 3 | 4 | 5 {
  switch (status) {
    case "entity_review":
      return 2;
    case "new":
      return 3;
    case "pending_completion":
    case "under_review":
    case "awaiting_final":
      return 3;
    case "approved":
    case "not_approved":
    case "entity_rejected":
      return 4;
    case "closed":
      return 5;
    case "cancelled":
      return 0;
  }
}

export function isCancellable(status: RequestStatus): boolean {
  return (
    status === "entity_review" ||
    status === "new" ||
    status === "pending_completion" ||
    status === "under_review" ||
    status === "awaiting_final"
  );
}

export function canSubmitReport(
  status: RequestStatus,
  activityDateIso: string,
  hasReport: boolean,
  todayIso: string = new Date().toISOString().slice(0, 10),
): boolean {
  return status === "approved" && activityDateIso < todayIso && !hasReport;
}
