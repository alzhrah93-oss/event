import type { RequestFormData } from "./types";
import { OTHER_OPTION } from "./types";
import {
  isAtLeastWorkingDaysAhead,
  MIN_LEAD_WORKING_DAYS,
} from "./working-days";

export const TOTAL_STEPS = 7;

/** Error codes keyed by field; UI maps codes to localized messages. */
export type RequestErrors = Partial<
  Record<keyof RequestFormData | "form", string>
>;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
/** Only university accounts may appear on a request (name@iau.edu.sa). */
const IAU_EMAIL_RE = /^[^\s@]+@iau\.edu\.sa$/i;
const PHONE_RE = /^(05\d{8}|\+9665\d{8})$/;

export function validateRequestStep(
  step: number,
  d: RequestFormData,
  todayIso?: string,
): RequestErrors {
  const e: RequestErrors = {};
  const req = (field: keyof RequestFormData, ok: boolean) => {
    if (!ok) e[field] = "required";
  };

  switch (step) {
    case 1: {
      req("organizingEntity", !!d.organizingEntity);
      // Which college/hospital (dropdown) or a typed name; the Student
      // Council needs no detail — it routes to the Dean of Student Affairs
      if (d.organizingEntity && d.organizingEntity !== "student_council")
        req("entityDetail", !!d.entityDetail.trim());
      req("applicantName", !!d.applicantName.trim());
      req("jobTitle", !!d.jobTitle.trim());
      if (!d.universityEmail.trim()) e.universityEmail = "required";
      else if (!EMAIL_RE.test(d.universityEmail.trim()))
        e.universityEmail = "email";
      else if (!IAU_EMAIL_RE.test(d.universityEmail.trim()))
        e.universityEmail = "iauEmail";
      if (!d.mobile.trim()) e.mobile = "required";
      else if (!PHONE_RE.test(d.mobile.trim().replace(/[\s-]/g, "")))
        e.mobile = "phone";
      // Alternate coordinator (name + contact) is required
      req("altCoordinator", !!d.altCoordinator.trim());
      if (!d.altCoordinatorPhone.trim()) e.altCoordinatorPhone = "required";
      else if (
        !PHONE_RE.test(d.altCoordinatorPhone.trim().replace(/[\s-]/g, ""))
      )
        e.altCoordinatorPhone = "phone";
      if (!d.altCoordinatorEmail.trim()) e.altCoordinatorEmail = "required";
      else if (!EMAIL_RE.test(d.altCoordinatorEmail.trim()))
        e.altCoordinatorEmail = "email";
      else if (!IAU_EMAIL_RE.test(d.altCoordinatorEmail.trim()))
        e.altCoordinatorEmail = "iauEmail";
      break;
    }
    case 2: {
      req("requestTypes", d.requestTypes.length > 0);
      req("title", !!d.title.trim());
      if (!d.description.trim()) e.description = "required";
      else if (d.description.trim().split(/\s+/).length < 20)
        e.description = "descriptionLength";
      if (!d.activityDate) e.activityDate = "required";
      else if (
        !isAtLeastWorkingDaysAhead(
          d.activityDate,
          MIN_LEAD_WORKING_DAYS,
          todayIso,
        )
      )
        e.activityDate = "leadTime";
      req("startTime", !!d.startTime);
      req("endTime", !!d.endTime);
      req("targetAudience", d.targetAudience.length > 0);
      if (!d.expectedAttendance) e.expectedAttendance = "required";
      else if (
        !/^\d+$/.test(d.expectedAttendance) ||
        Number(d.expectedAttendance) < 1
      )
        e.expectedAttendance = "number";
      req("activityFormat", !!d.activityFormat);
      break;
    }
    case 3: {
      req("venue", !!d.venue);
      if (d.venue === "off_campus") {
        req("externalHost", !!d.externalHost.trim());
        req("cityCountry", !!d.cityCountry.trim());
        req("externalParticipationType", !!d.externalParticipationType);
      }
      break;
    }
    case 4: {
      req("hasStudents", d.hasStudents !== null);
      if (d.hasStudents) {
        if (!d.studentCount) e.studentCount = "required";
        else if (!/^\d+$/.test(d.studentCount)) e.studentCount = "number";
      }
      req("hasFaculty", d.hasFaculty !== null);
      if (d.hasFaculty) {
        if (!d.facultyCount) e.facultyCount = "required";
        else if (!/^\d+$/.test(d.facultyCount)) e.facultyCount = "number";
      }
      req("hasPartners", d.hasPartners !== null);
      if (d.hasPartners) {
        const complete =
          d.partners.length > 0 &&
          d.partners.every((p) => p.name.trim() && p.type);
        if (!complete) e.partners = "partnersRequired";
      }
      break;
    }
    case 5: {
      const hasGoal =
        d.alignment.length > 0 && d.alignment.some((a) => a.goals.length > 0);
      if (!hasGoal) e.alignment = "alignmentRequired";
      // A custom goal needs its text; a custom challenge stays optional
      const missingOtherGoal = d.alignment.some(
        (a) => a.goals.includes(OTHER_OPTION) && !(a.otherGoal ?? "").trim(),
      );
      if (missingOtherGoal) e.alignment = "otherGoalRequired";
      req("expectedOutputs", d.expectedOutputs.length > 0);
      if (
        d.followupPathways.includes(OTHER_OPTION) &&
        !d.followupOther.trim()
      )
        e.followupOther = "required";
      break;
    }
    case 6: {
      req("presentsIp", !!d.presentsIp);
      if (d.presentsIp === "yes" || d.presentsIp === "unsure") {
        req("ipDisclosed", d.ipDisclosed !== null);
        req("ipPrototype", d.ipPrototype !== null);
        req("ipPatent", !!d.ipPatent);
        req("ipUnpublished", d.ipUnpublished !== null);
        req("ipNda", !!d.ipNda);
      }
      break;
    }
    case 7: {
      req("needsFunding", d.needsFunding !== null);
      if (d.needsFunding) {
        req("fundingSource", !!d.fundingSource);
        const items =
          d.budgetItems.length > 0 &&
          d.budgetItems.every(
            (b) => b.item.trim() && /^\d+(\.\d+)?$/.test(b.cost),
          );
        if (!items) e.budgetItems = "budgetRequired";
      }
      req("needsLabs", d.needsLabs !== null);
      if (d.needsLabs) req("labsDetails", !!d.labsDetails.trim());
      req("needsMaterials", d.needsMaterials !== null);
      if (d.needsMaterials) req("materialsDetails", !!d.materialsDetails.trim());
      req("needsMedia", d.needsMedia !== null);
      if (!d.declaration) e.declaration = "declarationRequired";
      break;
    }
  }
  return e;
}

export function validateRequestFull(
  d: RequestFormData,
  todayIso?: string,
): RequestErrors {
  let all: RequestErrors = {};
  for (let s = 1; s <= TOTAL_STEPS; s++) {
    all = { ...all, ...validateRequestStep(s, d, todayIso) };
  }
  return all;
}
