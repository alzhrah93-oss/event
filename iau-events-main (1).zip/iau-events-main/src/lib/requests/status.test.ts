import { describe, expect, it } from "vitest";
import {
  canSubmitReport,
  isCancellable,
  progressStage,
  STATUS_META,
} from "./status";

describe("STATUS_META", () => {
  it("covers every request status", () => {
    for (const s of [
      "entity_review",
      "new",
      "pending_completion",
      "under_review",
      "awaiting_final",
      "approved",
      "not_approved",
      "entity_rejected",
      "cancelled",
      "closed",
    ]) {
      expect(STATUS_META[s as keyof typeof STATUS_META]).toBeDefined();
    }
  });
});

describe("progressStage", () => {
  it("maps statuses onto the 5-stage tracker", () => {
    expect(progressStage("entity_review")).toBe(2);
    expect(progressStage("new")).toBe(3);
    expect(progressStage("pending_completion")).toBe(3);
    expect(progressStage("under_review")).toBe(3);
    expect(progressStage("awaiting_final")).toBe(3);
    expect(progressStage("approved")).toBe(4);
    expect(progressStage("not_approved")).toBe(4);
    expect(progressStage("entity_rejected")).toBe(4);
    expect(progressStage("closed")).toBe(5);
    expect(progressStage("cancelled")).toBe(0); // tracker replaced by cancelled notice
  });
});

describe("isCancellable", () => {
  it("only while reviewable", () => {
    expect(isCancellable("entity_review")).toBe(true);
    expect(isCancellable("new")).toBe(true);
    expect(isCancellable("entity_rejected")).toBe(false);
    expect(isCancellable("pending_completion")).toBe(true);
    expect(isCancellable("under_review")).toBe(true);
    expect(isCancellable("awaiting_final")).toBe(true);
    expect(isCancellable("approved")).toBe(false);
    expect(isCancellable("cancelled")).toBe(false);
    expect(isCancellable("closed")).toBe(false);
  });
});

describe("canSubmitReport", () => {
  it("approved + event ended + no report yet", () => {
    expect(canSubmitReport("approved", "2026-07-01", false, "2026-07-15")).toBe(true);
    expect(canSubmitReport("approved", "2026-08-01", false, "2026-07-15")).toBe(false); // not ended
    expect(canSubmitReport("approved", "2026-07-01", true, "2026-07-15")).toBe(false); // already reported
    expect(canSubmitReport("new", "2026-07-01", false, "2026-07-15")).toBe(false); // not approved
  });
});
