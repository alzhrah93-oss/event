import { describe, expect, it } from "vitest";
import { labelsFor, optionLabel } from "./display";
import { REQUEST_TYPES, VENUES } from "./options";

describe("optionLabel", () => {
  it("maps a stored value to its localized label", () => {
    expect(optionLabel(VENUES, "on_campus", "en")).toBe("On campus");
    expect(optionLabel(VENUES, "on_campus", "ar")).toBe("داخل الجامعة");
  });

  it("falls back to the raw value for unknown entries", () => {
    expect(optionLabel(VENUES, "mystery", "en")).toBe("mystery");
  });
});

describe("labelsFor", () => {
  it("maps arrays and joins with a localized separator", () => {
    expect(labelsFor(REQUEST_TYPES, ["workshop", "forum"], "en")).toBe(
      "Workshop, Forum",
    );
    expect(labelsFor(REQUEST_TYPES, ["workshop", "forum"], "ar")).toBe(
      "ورشة عمل، ملتقى",
    );
  });

  it("returns a dash for empty arrays", () => {
    expect(labelsFor(REQUEST_TYPES, [], "en")).toBe("—");
  });
});
