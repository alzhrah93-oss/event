import { OTHER_PREFIX, type Option } from "./options";

type Loc = "en" | "ar";

/** Localized label for a stored option value; falls back to the raw value.
 * Custom "other:…" entries render their free text directly. */
export function optionLabel(list: Option[], value: string, locale: Loc): string {
  if (value.startsWith(OTHER_PREFIX)) return value.slice(OTHER_PREFIX.length);
  return list.find((o) => o.value === value)?.label[locale] ?? value;
}

/** Localized, comma-joined labels for a stored value array ("—" when empty). */
export function labelsFor(
  list: Option[],
  values: string[] | null | undefined,
  locale: Loc,
): string {
  if (!values || values.length === 0) return "—";
  const sep = locale === "ar" ? "، " : ", ";
  return values.map((v) => optionLabel(list, v, locale)).join(sep);
}

export function formatDate(iso: string | null, locale: Loc): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat(locale === "ar" ? "ar-SA" : "en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(iso.length === 10 ? `${iso}T00:00:00` : iso));
}

export function formatTime(t: string | null): string {
  return t ? t.slice(0, 5) : "—";
}
