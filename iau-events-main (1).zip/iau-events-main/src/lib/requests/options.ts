import type { Localized } from "@/lib/content";

/** Dropdown options — governance guide Appendix A. Keys are stable English slugs. */

export type Option = { value: string; label: Localized };

export const ORGANIZING_ENTITIES: Option[] = [
  { value: "college", label: { en: "College", ar: "كلية" } },
  { value: "deanship", label: { en: "Deanship", ar: "عمادة" } },
  { value: "institute", label: { en: "Institute", ar: "معهد" } },
  { value: "center", label: { en: "Center", ar: "مركز" } },
  { value: "student_council", label: { en: "Student Council", ar: "مجلس طلابي" } },
  { value: "hospital", label: { en: "Hospital", ar: "مستشفى" } },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

/** IAU university hospitals — dropdown when the organizing entity is a hospital */
export const HOSPITALS: Option[] = [
  {
    value: "kfhu",
    label: {
      en: "King Fahd Hospital of the University (KFHU)",
      ar: "مستشفى الملك فهد الجامعي",
    },
  },
  {
    value: "dental_hospital",
    label: { en: "University Dental Hospital", ar: "مستشفى طب الأسنان الجامعي" },
  },
  {
    value: "family_medicine_center",
    label: {
      en: "Family and Community Medicine Center",
      ar: "مركز طب العائلة والمجتمع",
    },
  },
];

/** IAU deanships — dropdown when the organizing entity is a deanship */
export const DEANSHIPS: Option[] = [
  { value: "admissions_registration", label: { en: "Deanship of Admissions and Registration", ar: "عمادة القبول والتسجيل" } },
  { value: "student_affairs", label: { en: "Deanship of Student Affairs", ar: "عمادة شؤون الطلاب" } },
  { value: "preparatory_year", label: { en: "Deanship of Preparatory Year and Supporting Studies", ar: "عمادة السنة التحضيرية والدراسات المساندة" } },
  { value: "graduate_studies", label: { en: "Deanship of Graduate Studies", ar: "عمادة الدراسات العليا" } },
  { value: "scientific_research", label: { en: "Deanship of Scientific Research", ar: "عمادة البحث العلمي" } },
  { value: "faculty_personnel", label: { en: "Deanship of Faculty and Personnel Affairs", ar: "عمادة شؤون أعضاء هيئة التدريس والموظفين" } },
  { value: "ict_deanship", label: { en: "Deanship of Information and Communication Technology", ar: "عمادة الاتصالات وتقنية المعلومات" } },
  { value: "elearning", label: { en: "Deanship of E-Learning and Distance Learning", ar: "عمادة التعليم الإلكتروني والتعلم عن بعد" } },
  { value: "quality_accreditation", label: { en: "Deanship of Quality and Academic Accreditation", ar: "عمادة الجودة والاعتماد الأكاديمي" } },
  { value: "education_development", label: { en: "Deanship of University Education Development", ar: "عمادة تطوير التعليم الجامعي" } },
  { value: "community_service", label: { en: "Deanship of Community Service and Sustainable Development", ar: "عمادة خدمة المجتمع والتنمية المستدامة" } },
];

/** IAU institutes — dropdown when the organizing entity is an institute */
export const INSTITUTES: Option[] = [
  { value: "studies_consulting", label: { en: "Institute for Studies and Consulting Services", ar: "معهد الدراسات والخدمات الاستشارية" } },
  { value: "research_medical_consultations", label: { en: "Institute for Research and Medical Consultations", ar: "معهد البحوث والاستشارات الطبية" } },
  { value: "innovation_entrepreneurship", label: { en: "Institute of Innovation and Entrepreneurship", ar: "معهد الابتكار وريادة الأعمال" } },
];

/** IAU centers — dropdown when the organizing entity is a center */
export const CENTERS: Option[] = [
  { value: "university_counseling", label: { en: "University Counseling Center", ar: "مركز الإرشاد الجامعي" } },
  { value: "urban_studies", label: { en: "Center for Urban Studies and Consultations", ar: "مركز الدراسات والاستشارات العمرانية" } },
  { value: "scientific_publications", label: { en: "Scientific Publications Center", ar: "مركز النشر العلمي" } },
  { value: "documents_archives", label: { en: "Documents and Archives Center", ar: "مركز الوثائق والمحفوظات" } },
  { value: "alumni_career", label: { en: "Alumni and Career Development Center", ar: "مركز الخريجين والتطوير المهني" } },
  { value: "assessment_examination", label: { en: "Assessment and Examination Quality Center", ar: "مركز التقويم وجودة الاختبارات" } },
  { value: "basic_applied_research", label: { en: "Center for Basic and Applied Scientific Research", ar: "مركز البحوث العلمية الأساسية والتطبيقية" } },
  { value: "leadership", label: { en: "Leadership Center", ar: "مركز القيادة" } },
  { value: "continuing_education", label: { en: "Continuing Education Center", ar: "مركز التعليم المستمر" } },
  { value: "student_skills", label: { en: "Student Skills Development Center", ar: "مركز تنمية مهارات الطلاب" } },
  { value: "ict_center", label: { en: "Information and Communication Technology Center", ar: "مركز الاتصالات وتقنية المعلومات" } },
  { value: "translational_medical", label: { en: "Translational Medical Sciences Research Center", ar: "مركز أبحاث العلوم الطبية الانتقالية" } },
  { value: "humanities_social", label: { en: "Humanities and Social Sciences Research Center", ar: "مركز بحوث العلوم الإنسانية والاجتماعية" } },
  { value: "communication_media", label: { en: "University Communication and Media Center", ar: "مركز الاتصال والإعلام الجامعي" } },
];

/** IAU colleges grouped by track — shown when the organizing entity is a college */
export type CollegeGroup = { group: Localized; colleges: Option[] };

export const COLLEGE_GROUPS: CollegeGroup[] = [
  {
    group: { en: "Health", ar: "المسار الصحي" },
    colleges: [
      { value: "medicine", label: { en: "College of Medicine", ar: "كلية الطب" } },
      { value: "dentistry", label: { en: "College of Dentistry", ar: "كلية طب الأسنان" } },
      { value: "nursing", label: { en: "College of Nursing", ar: "كلية التمريض" } },
      {
        value: "applied_medical_sciences",
        label: { en: "College of Applied Medical Sciences", ar: "كلية العلوم الطبية التطبيقية" },
      },
      { value: "pharmacy", label: { en: "College of Pharmacy", ar: "كلية الصيدلة" } },
      { value: "public_health", label: { en: "College of Public Health", ar: "كلية الصحة العامة" } },
      {
        value: "applied_medical_sciences_jubail",
        label: {
          en: "College of Applied Medical Sciences – Jubail",
          ar: "كلية العلوم الطبية التطبيقية بالجبيل",
        },
      },
    ],
  },
  {
    group: { en: "Sciences and Management", ar: "مسار العلوم والإدارة" },
    colleges: [
      {
        value: "applied_studies",
        label: {
          en: "College of Applied Studies and Community Service",
          ar: "كلية الدراسات التطبيقية وخدمة المجتمع",
        },
      },
      {
        value: "business_administration",
        label: { en: "College of Business Administration", ar: "كلية إدارة الأعمال" },
      },
      {
        value: "computer_science",
        label: {
          en: "College of Computer Science and Information Technology",
          ar: "كلية علوم الحاسب وتقنية المعلومات",
        },
      },
      { value: "science", label: { en: "College of Science", ar: "كلية العلوم" } },
      { value: "applied_college", label: { en: "Applied College", ar: "الكلية التطبيقية" } },
      {
        value: "science_humanities_jubail",
        label: {
          en: "College of Science and Humanities – Jubail",
          ar: "كلية العلوم والدراسات الإنسانية بالجبيل",
        },
      },
    ],
  },
  {
    group: { en: "Engineering", ar: "المسار الهندسي" },
    colleges: [
      {
        value: "architecture_planning",
        label: { en: "College of Architecture and Planning", ar: "كلية العمارة والتخطيط" },
      },
      { value: "design", label: { en: "College of Design", ar: "كلية التصاميم" } },
      { value: "engineering", label: { en: "College of Engineering", ar: "كلية الهندسة" } },
    ],
  },
  {
    group: { en: "Arts and Education", ar: "مسار الآداب والتعليم" },
    colleges: [
      { value: "arts", label: { en: "College of Arts", ar: "كلية الآداب" } },
      { value: "education", label: { en: "College of Education", ar: "كلية التربية" } },
      {
        value: "sharia_law",
        label: { en: "College of Sharia and Law", ar: "كلية الشريعة والقانون" },
      },
    ],
  },
];

/** Flat list of every college option (labels for display/filters). */
export const COLLEGES: Option[] = COLLEGE_GROUPS.flatMap((g) => g.colleges);

/** Detail catalog per organizing entity type ("other" / "student_council" are free text). */
export const ENTITY_DETAIL_LISTS: Record<string, Option[]> = {
  deanship: DEANSHIPS,
  institute: INSTITUTES,
  center: CENTERS,
  hospital: HOSPITALS,
};

/** Every catalogued entity-detail option (colleges + deanships + institutes + centers + hospitals). */
export const ALL_ENTITY_DETAILS: Option[] = [
  ...COLLEGES,
  ...DEANSHIPS,
  ...INSTITUTES,
  ...CENTERS,
  ...HOSPITALS,
];

/**
 * Routing key for the entity-approval stage — matches profiles.entity_key of
 * the entity head account. Student Council requests go to the Dean of Student
 * Affairs; "other" has no head and skips straight to the IIE queue (null).
 */
export function entityRouteKey(
  organizingEntity: string,
  entityDetail: string,
): string | null {
  switch (organizingEntity) {
    case "college":
    case "deanship":
    case "institute":
    case "center":
    case "hospital":
      return entityDetail ? `${organizingEntity}:${entityDetail}` : null;
    case "student_council":
      return "deanship:student_affairs";
    default:
      return null;
  }
}

export const REQUEST_TYPES: Option[] = [
  { value: "event", label: { en: "Event", ar: "فعالية" } },
  { value: "workshop", label: { en: "Workshop", ar: "ورشة عمل" } },
  { value: "initiative", label: { en: "Initiative", ar: "مبادرة" } },
  { value: "competition", label: { en: "Competition", ar: "مسابقة" } },
  { value: "program", label: { en: "Program", ar: "برنامج" } },
  { value: "judging", label: { en: "Judging", ar: "تحكيم" } },
  { value: "partnership", label: { en: "Partnership", ar: "شراكة" } },
  { value: "forum", label: { en: "Forum", ar: "ملتقى" } },
  { value: "conference", label: { en: "Conference", ar: "مؤتمر" } },
  { value: "exhibition", label: { en: "Exhibition", ar: "معرض" } },
  {
    value: "idea_disclosure",
    label: {
      en: "Disclosure of an idea or innovative project",
      ar: "الإفصاح عن فكرة أو مشروع ابتكاري",
    },
  },
  {
    value: "external_participation",
    label: { en: "External participation", ar: "مشاركة خارجية" },
  },
  { value: "training", label: { en: "Training", ar: "تدريب" } },
  {
    value: "student_nomination",
    label: { en: "Student nomination", ar: "ترشيح طلابي" },
  },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

export const TARGET_AUDIENCE: Option[] = [
  { value: "students", label: { en: "Students", ar: "الطلبة" } },
  { value: "researchers", label: { en: "Researchers", ar: "الباحثون" } },
  { value: "faculty", label: { en: "Faculty members", ar: "أعضاء هيئة التدريس" } },
  { value: "entrepreneurs", label: { en: "Entrepreneurs", ar: "روّاد الأعمال" } },
  { value: "investors", label: { en: "Investors", ar: "المستثمرون" } },
  {
    value: "government",
    label: { en: "Government entities", ar: "الجهات الحكومية" },
  },
  { value: "private_sector", label: { en: "Private sector", ar: "القطاع الخاص" } },
  { value: "community", label: { en: "Community", ar: "المجتمع" } },
  {
    value: "administrative_board",
    label: {
      en: "Members of the Administrative Board",
      ar: "أعضاء الهيئة الإدارية",
    },
  },
  {
    value: "university_staff",
    label: { en: "University staff", ar: "منسوبي الجامعة" },
  },
];

export const ACTIVITY_FORMATS: Option[] = [
  { value: "in_person", label: { en: "In-person", ar: "حضوري" } },
  { value: "virtual", label: { en: "Virtual", ar: "افتراضي" } },
  { value: "hybrid", label: { en: "Hybrid", ar: "مدمج" } },
];

export const VENUES: Option[] = [
  { value: "on_campus", label: { en: "On campus", ar: "داخل الجامعة" } },
  { value: "off_campus", label: { en: "Off campus", ar: "خارج الجامعة" } },
  { value: "virtual", label: { en: "Virtual", ar: "افتراضي" } },
];

export const EXTERNAL_PARTICIPATION_TYPES: Option[] = [
  {
    value: "delivering_workshop",
    label: { en: "Delivering a workshop", ar: "تقديم ورشة عمل" },
  },
  { value: "booth", label: { en: "Organizing a booth", ar: "تنظيم جناح" } },
  {
    value: "project_presentation",
    label: { en: "Presenting an innovative project", ar: "عرض مشروع ابتكاري" },
  },
  { value: "attendance", label: { en: "Attendance", ar: "حضور" } },
  { value: "competitor", label: { en: "Competitor", ar: "منافس" } },
  { value: "judge", label: { en: "Judge", ar: "محكّم" } },
  { value: "sponsor", label: { en: "Sponsor", ar: "راعٍ" } },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

export const PARTNERSHIP_TYPES: Option[] = [
  { value: "sponsorship", label: { en: "Sponsorship", ar: "رعاية" } },
  {
    value: "joint_implementation",
    label: { en: "Joint implementation", ar: "تنفيذ مشترك" },
  },
  { value: "training", label: { en: "Training", ar: "تدريب" } },
  { value: "judging", label: { en: "Judging", ar: "تحكيم" } },
  { value: "hosting", label: { en: "Hosting", ar: "استضافة" } },
  { value: "funding", label: { en: "Funding", ar: "تمويل" } },
  {
    value: "technical_support",
    label: { en: "Technical support", ar: "دعم تقني" },
  },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

export const EXPECTED_OUTPUTS: Option[] = [
  {
    value: "innovation_culture",
    label: { en: "Promote an innovation culture", ar: "تعزيز ثقافة الابتكار" },
  },
  { value: "attract_ideas", label: { en: "Attract ideas", ar: "استقطاب الأفكار" } },
  {
    value: "incubate_projects",
    label: { en: "Incubate projects", ar: "احتضان المشاريع" },
  },
  {
    value: "build_partnerships",
    label: { en: "Build partnerships", ar: "بناء الشراكات" },
  },
  {
    value: "qualify_entrepreneurs",
    label: { en: "Qualify entrepreneurs", ar: "تأهيل روّاد الأعمال" },
  },
  { value: "training", label: { en: "Training", ar: "تدريب" } },
  { value: "competitions", label: { en: "Competitions", ar: "مسابقات" } },
  {
    value: "register_ip",
    label: { en: "Register intellectual property", ar: "تسجيل ملكية فكرية" },
  },
  {
    value: "establish_startups",
    label: { en: "Establish start-ups", ar: "تأسيس شركات ناشئة" },
  },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

export const FOLLOWUP_PATHWAYS: Option[] = [
  {
    value: "innovation_bank",
    label: { en: "Referral to the Innovation Bank", ar: "إحالة إلى بنك الابتكار" },
  },
  { value: "incubation", label: { en: "Incubation", ar: "احتضان" } },
  {
    value: "intellectual_property",
    label: { en: "Intellectual property", ar: "ملكية فكرية" },
  },
  { value: "partnership", label: { en: "Partnership", ar: "شراكة" } },
  {
    value: "advanced_training",
    label: { en: "Advanced training", ar: "تدريب متقدم" },
  },
  {
    value: "closure",
    label: { en: "Closure without follow-up", ar: "إغلاق دون متابعة" },
  },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

/**
 * Custom "other" entries are stored inside the same text[] columns with this
 * prefix (e.g. "other:My custom pathway"); display code strips it.
 */
export const OTHER_PREFIX = "other:";

export const SDGS: Option[] = [
  { value: "sdg3", label: { en: "SDG 3: Good Health and Well-being", ar: "الهدف 3: الصحة الجيدة والرفاه" } },
  { value: "sdg4", label: { en: "SDG 4: Quality Education", ar: "الهدف 4: التعليم الجيد" } },
  { value: "sdg6", label: { en: "SDG 6: Clean Water and Sanitation", ar: "الهدف 6: المياه النظيفة والنظافة الصحية" } },
  { value: "sdg7", label: { en: "SDG 7: Affordable and Clean Energy", ar: "الهدف 7: طاقة نظيفة وبأسعار معقولة" } },
  { value: "sdg8", label: { en: "SDG 8: Decent Work and Economic Growth", ar: "الهدف 8: العمل اللائق ونمو الاقتصاد" } },
  { value: "sdg9", label: { en: "SDG 9: Industry, Innovation and Infrastructure", ar: "الهدف 9: الصناعة والابتكار والهياكل الأساسية" } },
  { value: "sdg11", label: { en: "SDG 11: Sustainable Cities and Communities", ar: "الهدف 11: مدن ومجتمعات مستدامة" } },
  { value: "sdg12", label: { en: "SDG 12: Responsible Consumption and Production", ar: "الهدف 12: الاستهلاك والإنتاج المسؤولان" } },
  { value: "sdg13", label: { en: "SDG 13: Climate Action", ar: "الهدف 13: العمل المناخي" } },
  { value: "sdg17", label: { en: "SDG 17: Partnerships for the Goals", ar: "الهدف 17: عقد الشراكات لتحقيق الأهداف" } },
];

export const FUNDING_SOURCES: Option[] = [
  { value: "student_fund", label: { en: "Student Fund", ar: "صندوق الطلبة" } },
  { value: "entity_budget", label: { en: "Entity budget", ar: "ميزانية الجهة" } },
  { value: "external_sponsor", label: { en: "External sponsor", ar: "راعٍ خارجي" } },
  { value: "in_kind", label: { en: "In-kind support", ar: "دعم عيني" } },
  { value: "other", label: { en: "Other", ar: "أخرى" } },
];

export const ATTACHMENT_KINDS = [
  { kind: "approved_letter", required: true },
  { kind: "agenda", required: false },
  { kind: "participants_list", required: false },
  { kind: "invitation_letter", required: false },
  { kind: "profile_deck", required: false },
  { kind: "ip_documents", required: false },
] as const;

export type AttachmentKind = (typeof ATTACHMENT_KINDS)[number]["kind"];

export const ACCEPTED_FILE_TYPES =
  ".pdf,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg";
/**
 * Server Actions accept at most 4MB per request (next.config bodySizeLimit;
 * Vercel caps bodies at ~4.5MB), so files are validated well below that to
 * leave room for the JSON payload + multipart overhead.
 */
export const MAX_FILE_MB = 3;
