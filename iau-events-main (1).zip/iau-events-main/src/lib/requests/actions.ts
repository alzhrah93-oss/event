"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import {
  ATTACHMENT_KINDS,
  entityRouteKey,
  MAX_FILE_MB,
  OTHER_PREFIX,
} from "./options";
import { isCancellable, type RequestStatus } from "./status";
import { OTHER_OPTION, type RequestFormData } from "./types";
import { validateRequestFull } from "./validate";

/** Replace the "__other__" sentinel with a prefixed custom entry. */
function withOther(values: string[], custom: string | undefined): string[] {
  const text = (custom ?? "").trim();
  return values
    .map((v) => (v === OTHER_OPTION ? (text ? OTHER_PREFIX + text : null) : v))
    .filter((v): v is string => v !== null);
}

export type SubmitResult =
  | { requestNumber: string; error?: never }
  | { error: string; requestNumber?: never };

const num = (s: string) => (s && /^\d+$/.test(s) ? Number(s) : null);

export async function submitRequest(fd: FormData): Promise<SubmitResult> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { error: "unauthorized" };

  let d: RequestFormData;
  try {
    d = JSON.parse(String(fd.get("payload")));
  } catch {
    return { error: "invalid" };
  }

  // Server-side re-validation — the client is never trusted.
  const errors = validateRequestFull(d);
  if (Object.keys(errors).length > 0) return { error: "invalid" };

  const approvedLetter = fd.get("file_approved_letter");
  if (!(approvedLetter instanceof File) || approvedLetter.size === 0)
    return { error: "attachmentRequired" };

  // Collect + size-check files
  const uploads: { kind: string; file: File }[] = [];
  for (const { kind } of ATTACHMENT_KINDS) {
    const f = fd.get(`file_${kind}`);
    if (f instanceof File && f.size > 0) {
      if (f.size > MAX_FILE_MB * 1024 * 1024) return { error: "fileTooLarge" };
      uploads.push({ kind, file: f });
    }
  }

  // Insert the request (trigger assigns request_number)
  const { data: request, error: insertError } = await supabase
    .from("event_requests")
    .insert({
      organizer_id: user.id,
      organizing_entity: d.organizingEntity,
      entity_detail: d.entityDetail.trim() || null,
      applicant_name: d.applicantName.trim(),
      job_title: d.jobTitle.trim(),
      university_email: d.universityEmail.trim(),
      mobile: d.mobile.trim().replace(/[\s-]/g, ""),
      alt_coordinator: d.altCoordinator.trim() || null,
      alt_coordinator_phone:
        d.altCoordinatorPhone.trim().replace(/[\s-]/g, "") || null,
      alt_coordinator_email: d.altCoordinatorEmail.trim() || null,
      request_types: d.requestTypes,
      title: d.title.trim(),
      description: d.description.trim(),
      activity_date: d.activityDate,
      start_time: d.startTime,
      end_time: d.endTime,
      target_audience: d.targetAudience,
      expected_attendance: num(d.expectedAttendance) ?? 0,
      activity_format: d.activityFormat,
      venue: d.venue,
      external_host: d.externalHost.trim() || null,
      city_country: d.cityCountry.trim() || null,
      location_details: d.locationDetails.trim() || null,
      external_participation_type: d.externalParticipationType || null,
      has_students: d.hasStudents === true,
      student_count: d.hasStudents ? num(d.studentCount) : null,
      has_faculty: d.hasFaculty === true,
      faculty_count: d.hasFaculty ? num(d.facultyCount) : null,
      has_partners: d.hasPartners === true,
      partners: d.hasPartners ? d.partners : [],
      sdgs: d.sdgs,
      expected_outputs: d.expectedOutputs,
      followup_pathways: withOther(d.followupPathways, d.followupOther),
      // Entity-approval routing: matches profiles.entity_key of the head;
      // the DB trigger forwards to the IIE queue when no head is registered.
      entity_route_key: entityRouteKey(d.organizingEntity, d.entityDetail.trim()),
      presents_ip: d.presentsIp,
      ip_disclosed: d.ipDisclosed,
      ip_prototype: d.ipPrototype,
      ip_patent: d.ipPatent || null,
      ip_unpublished: d.ipUnpublished,
      ip_nda: d.ipNda || null,
      needs_funding: d.needsFunding === true,
      funding_source: d.needsFunding ? d.fundingSource : null,
      budget_items: d.needsFunding ? d.budgetItems : [],
      needs_labs: d.needsLabs === true,
      labs_details: d.needsLabs ? d.labsDetails.trim() : null,
      needs_materials: d.needsMaterials === true,
      materials_details: d.needsMaterials ? d.materialsDetails.trim() : null,
      needs_media: d.needsMedia === true,
    })
    .select("id, request_number, status")
    .single();

  if (insertError || !request) return { error: "submitFailed" };

  const cleanupAndFail = async (): Promise<SubmitResult> => {
    await supabase.from("event_requests").delete().eq("id", request.id);
    return { error: "submitFailed" };
  };

  // Alignment rows (keep areas that carry goals or grand challenges);
  // "__other__" entries become prefixed custom text ("other:…")
  const alignmentRows = d.alignment
    .filter((a) => a.goals.length > 0 || (a.challenges ?? []).length > 0)
    .map((a) => ({
      request_id: request.id,
      focus_area_id: a.focusAreaId,
      goals: withOther(a.goals, a.otherGoal),
      grand_challenges: withOther(a.challenges ?? [], a.otherChallenge),
    }));
  if (alignmentRows.length > 0) {
    const { error } = await supabase
      .from("request_alignment")
      .insert(alignmentRows);
    if (error) return cleanupAndFail();
  }

  // Attachments → storage + rows
  for (const { kind, file } of uploads) {
    const safeName = file.name.replace(/[^\w.\-]+/g, "_");
    const path = `${request.id}/${kind}-${safeName}`;
    const { error: upErr } = await supabase.storage
      .from("request-attachments")
      .upload(path, file);
    if (upErr) return cleanupAndFail();
    const { error: rowErr } = await supabase.from("attachments").insert({
      request_id: request.id,
      kind,
      file_name: file.name,
      storage_path: path,
      uploaded_by: user.id,
    });
    if (rowErr) return cleanupAndFail();
  }

  // Status history: submitted (the routing trigger decides entity_review vs new)
  await supabase.from("request_status_history").insert({
    request_id: request.id,
    from_status: null,
    to_status: request.status,
    actor_id: user.id,
  });

  return { requestNumber: request.request_number as string };
}

/** Organizer cancels their own reviewable request. RLS enforces ownership + state. */
export async function cancelRequest(
  requestId: string,
): Promise<{ ok: boolean }> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false };

  const { data: current } = await supabase
    .from("event_requests")
    .select("status, request_number, title")
    .eq("id", requestId)
    .single();
  if (!current || !isCancellable(current.status as RequestStatus))
    return { ok: false };

  const { error } = await supabase
    .from("event_requests")
    .update({ status: "cancelled" })
    .eq("id", requestId);
  if (error) return { ok: false };

  await supabase.from("request_status_history").insert({
    request_id: requestId,
    from_status: current.status,
    to_status: "cancelled",
    actor_id: user.id,
  });

  revalidatePath("/[locale]/dashboard", "layout");
  return { ok: true };
}

/** Organizer submits the final report for an approved, ended activity. */
export async function submitFinalReport(
  requestId: string,
  fd: FormData,
): Promise<{ ok: boolean; error?: string }> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "unauthorized" };

  const summary = String(fd.get("summary") ?? "").trim();
  const actualDate = String(fd.get("actualDate") ?? "");
  const actualLocation = String(fd.get("actualLocation") ?? "").trim();
  const actualAttendance = Number(fd.get("actualAttendance") ?? NaN);
  if (!summary || !actualDate || !actualLocation || !Number.isFinite(actualAttendance))
    return { ok: false, error: "invalid" };

  // All count fields are required (0 is a valid answer, blank is not)
  const requiredInt = (k: string): number | null => {
    const raw = String(fd.get(k) ?? "").trim();
    if (!raw) return null;
    const n = Number(raw);
    return Number.isFinite(n) && n >= 0 ? Math.floor(n) : null;
  };
  const studentCount = requiredInt("studentCount");
  const ideasReceived = requiredInt("ideasReceived");
  const projectsNominated = requiredInt("projectsNominated");
  if (studentCount === null || ideasReceived === null || projectsNominated === null)
    return { ok: false, error: "invalid" };

  // Satisfaction percentage (required, 0–100)
  const satisfactionRaw = String(fd.get("satisfactionPct") ?? "").trim();
  const satisfactionNum = Number(satisfactionRaw);
  if (
    !satisfactionRaw ||
    !Number.isFinite(satisfactionNum) ||
    satisfactionNum < 0 ||
    satisfactionNum > 100
  )
    return { ok: false, error: "invalid" };
  const satisfactionPct = Math.round(satisfactionNum);

  // "Nothing or write it" fields: mode is required; "other" needs the text
  const choiceOrText = (k: string): { ok: boolean; value: string | null } => {
    const mode = String(fd.get(`${k}Mode`) ?? "");
    if (mode === "nothing") return { ok: true, value: null };
    if (mode === "other") {
      const text = String(fd.get(k) ?? "").trim();
      return text ? { ok: true, value: text } : { ok: false, value: null };
    }
    return { ok: false, value: null };
  };
  const nominationDesc = choiceOrText("projectsNominatedDesc");
  const partnerships = choiceOrText("partnerships");
  if (!nominationDesc.ok || !partnerships.ok)
    return { ok: false, error: "invalid" };

  // Evidence attachments are mandatory: the event's report with pictures
  // and media-coverage links.
  const evidence = fd
    .getAll("evidence")
    .filter((f): f is File => f instanceof File && f.size > 0);
  if (evidence.length === 0) return { ok: false, error: "evidenceRequired" };
  if (evidence.some((f) => f.size > MAX_FILE_MB * 1024 * 1024))
    return { ok: false, error: "fileTooLarge" };

  // Actual budget table: [{item, approved, spent, notes}] — numbers sanitized
  type BudgetRow = { item: string; approved: number; spent: number; notes: string };
  let actualBudget: BudgetRow[] = [];
  try {
    const parsed: unknown = JSON.parse(String(fd.get("actualBudget") ?? "[]"));
    if (!Array.isArray(parsed)) return { ok: false, error: "invalid" };
    actualBudget = parsed
      .map((row) => {
        const r = row as Partial<Record<keyof BudgetRow, unknown>>;
        return {
          item: String(r.item ?? "").trim(),
          approved: Number(r.approved ?? 0),
          spent: Number(r.spent ?? 0),
          notes: String(r.notes ?? "").trim(),
        };
      })
      .filter(
        (r) =>
          r.item && Number.isFinite(r.approved) && Number.isFinite(r.spent),
      );
  } catch {
    return { ok: false, error: "invalid" };
  }

  const { error } = await supabase.from("final_reports").insert({
    request_id: requestId,
    implementation_summary: summary,
    actual_date: actualDate,
    actual_location: actualLocation,
    actual_attendance: Math.floor(actualAttendance),
    student_count: studentCount,
    ideas_received: ideasReceived,
    projects_nominated: projectsNominated,
    projects_nominated_desc: nominationDesc.value,
    partnerships: partnerships.value,
    satisfaction_pct: satisfactionPct,
    actual_budget: actualBudget,
    submitted_by: user.id,
  });
  if (error) return { ok: false, error: "invalid" };

  // Evidence files (required, validated above)
  for (const f of evidence) {
    const safeName = f.name.replace(/[^\w.\-]+/g, "_");
    const path = `${requestId}/report-${safeName}`;
    const { error: upErr } = await supabase.storage
      .from("request-attachments")
      .upload(path, f);
    if (!upErr) {
      await supabase.from("attachments").insert({
        request_id: requestId,
        kind: "report_evidence",
        file_name: f.name,
        storage_path: path,
        uploaded_by: user.id,
      });
    }
  }

  revalidatePath("/[locale]/dashboard", "layout");
  return { ok: true };
}
