"use server";

import { revalidatePath } from "next/cache";
import { getSessionProfile } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";
import type { RequestStatus } from "./status";

export type RecommendationDecision = "approve" | "not_approve";

/** Statuses the super admin may (re)assign to a regular admin. */
const ASSIGNABLE: RequestStatus[] = [
  "new",
  "under_review",
  "pending_completion",
];

/**
 * Stage 1 — the super admin sends a request to a specific regular admin
 * for review. Moves the request to under_review and clears any previous
 * recommendation (reassignment restarts the review).
 */
export async function assignRequest(
  requestId: string,
  adminId: string,
): Promise<{ ok: boolean; error?: string }> {
  const profile = await getSessionProfile();
  if (profile?.role !== "super_admin")
    return { ok: false, error: "unauthorized" };

  const supabase = await createClient();
  const [{ data: current }, { data: admin }] = await Promise.all([
    supabase
      .from("event_requests")
      .select("status")
      .eq("id", requestId)
      .single(),
    supabase
      .from("profiles")
      .select("id, full_name")
      .eq("id", adminId)
      .eq("role", "admin")
      .single(),
  ]);
  if (!current || !ASSIGNABLE.includes(current.status as RequestStatus))
    return { ok: false, error: "notAssignable" };
  if (!admin) return { ok: false, error: "notAnAdmin" };

  const { error } = await supabase
    .from("event_requests")
    .update({
      assigned_admin_id: admin.id,
      assigned_at: new Date().toISOString(),
      status: "under_review",
      admin_recommendation: null,
      admin_recommendation_reason: null,
      recommended_at: null,
    })
    .eq("id", requestId);
  if (error) return { ok: false, error: "failed" };

  await supabase.from("request_status_history").insert({
    request_id: requestId,
    from_status: current.status,
    to_status: "under_review",
    actor_id: profile.id,
    note: admin.full_name || null,
  });

  revalidatePath("/[locale]/admin", "layout");
  return { ok: true };
}

/**
 * Stage 2 — the assigned admin reviews and records approve/not_approve with
 * their reasoning. The request then awaits the super admin's final decision.
 */
export async function submitRecommendation(
  requestId: string,
  decision: RecommendationDecision,
  reason: string,
): Promise<{ ok: boolean; error?: string }> {
  const profile = await getSessionProfile();
  if (profile?.role !== "admin") return { ok: false, error: "unauthorized" };

  const trimmedReason = reason.trim();
  if (!trimmedReason) return { ok: false, error: "reasonRequired" };

  const supabase = await createClient();
  const { data: current } = await supabase
    .from("event_requests")
    .select("status, assigned_admin_id")
    .eq("id", requestId)
    .single();
  if (!current || current.status !== "under_review")
    return { ok: false, error: "notReviewable" };
  if (current.assigned_admin_id !== profile.id)
    return { ok: false, error: "notAssigned" };

  const { error } = await supabase
    .from("event_requests")
    .update({
      status: "awaiting_final",
      admin_recommendation: decision,
      admin_recommendation_reason: trimmedReason,
      recommended_at: new Date().toISOString(),
      reviewer_id: profile.id,
    })
    .eq("id", requestId);
  if (error) return { ok: false, error: "failed" };

  await supabase.from("request_status_history").insert({
    request_id: requestId,
    from_status: current.status,
    to_status: "awaiting_final",
    actor_id: profile.id,
    note: trimmedReason,
  });

  revalidatePath("/[locale]/admin", "layout");
  return { ok: true };
}

/**
 * Stage 3 — the super admin takes the final decision after reading the
 * assigned admin's recommendation. Only this action can approve/not approve.
 */
export async function finalDecision(
  requestId: string,
  decision: RecommendationDecision,
  reason: string,
  notes: string,
): Promise<{ ok: boolean; error?: string }> {
  const profile = await getSessionProfile();
  if (profile?.role !== "super_admin")
    return { ok: false, error: "unauthorized" };

  const trimmedReason = reason.trim();
  if (decision === "not_approve" && !trimmedReason)
    return { ok: false, error: "reasonRequired" };

  const supabase = await createClient();
  const { data: current } = await supabase
    .from("event_requests")
    .select("status")
    .eq("id", requestId)
    .single();
  if (!current || current.status !== "awaiting_final")
    return { ok: false, error: "notReviewable" };

  const target: RequestStatus =
    decision === "approve" ? "approved" : "not_approved";
  const { error } = await supabase
    .from("event_requests")
    .update({
      status: target,
      decision_reason: decision === "not_approve" ? trimmedReason : null,
      institute_notes: notes.trim() || null,
    })
    .eq("id", requestId);
  if (error) return { ok: false, error: "failed" };

  await supabase.from("request_status_history").insert({
    request_id: requestId,
    from_status: current.status,
    to_status: target,
    actor_id: profile.id,
    note: decision === "not_approve" ? trimmedReason : notes.trim() || null,
  });

  revalidatePath("/[locale]/admin", "layout");
  return { ok: true };
}

/** Short-lived signed URL for an attachment (admin or owner — RLS enforces). */
export async function getAttachmentUrl(
  storagePath: string,
): Promise<string | null> {
  const supabase = await createClient();
  const { data } = await supabase.storage
    .from("request-attachments")
    .createSignedUrl(storagePath, 60 * 10, { download: true });
  return data?.signedUrl ?? null;
}
