import { describe, expect, it } from "vitest";
import { validateRequestStep, validateRequestFull, TOTAL_STEPS } from "./validate";
import { EMPTY_REQUEST, type RequestFormData } from "./types";

const base: RequestFormData = {
  ...EMPTY_REQUEST,
  organizingEntity: "institute",
  entityDetail: "Institute of Innovation and Entrepreneurship",
  applicantName: "Hatoon Test",
  jobTitle: "Coordinator",
  universityEmail: "h@iau.edu.sa",
  mobile: "0512345678",
  altCoordinator: "Backup Coordinator",
  altCoordinatorPhone: "0559876543",
  altCoordinatorEmail: "alt@iau.edu.sa",
  requestTypes: ["workshop"],
  title: "Innovation Workshop",
  description: Array.from({ length: 22 }, (_, i) => `word${i}`).join(" "),
  activityDate: "2026-09-20",
  startTime: "09:00",
  endTime: "13:00",
  targetAudience: ["students"],
  expectedAttendance: "80",
  activityFormat: "in_person",
  venue: "on_campus",
  hasStudents: false,
  hasFaculty: false,
  hasPartners: false,
  alignment: [{ focusAreaId: "ai-education", goals: ["Improving Student Career Decisions"], challenges: [] }],
  expectedOutputs: ["training"],
  presentsIp: "no",
  needsFunding: false,
  needsLabs: false,
  needsMaterials: false,
  needsMedia: false,
  declaration: true,
};

const TODAY = "2026-07-15";

describe("validateRequestStep", () => {
  it("valid base data passes every step", () => {
    for (let s = 1; s <= TOTAL_STEPS; s++) {
      expect(validateRequestStep(s, base, TODAY)).toEqual({});
    }
  });

  it("step 1 requires applicant fields", () => {
    const e = validateRequestStep(1, { ...base, applicantName: "", universityEmail: "bad" }, TODAY);
    expect(e.applicantName).toBe("required");
    expect(e.universityEmail).toBe("email");
  });

  it("step 1 accepts only @iau.edu.sa emails", () => {
    const gmail = validateRequestStep(
      1,
      { ...base, universityEmail: "someone@gmail.com", altCoordinatorEmail: "alt@hotmail.com" },
      TODAY,
    );
    expect(gmail.universityEmail).toBe("iauEmail");
    expect(gmail.altCoordinatorEmail).toBe("iauEmail");

    const iau = validateRequestStep(
      1,
      { ...base, universityEmail: "Someone@IAU.EDU.SA" },
      TODAY,
    );
    expect(iau.universityEmail).toBeUndefined();
  });

  it("step 1 requires the entity detail once an entity is chosen", () => {
    const e = validateRequestStep(1, { ...base, entityDetail: "" }, TODAY);
    expect(e.entityDetail).toBe("required");
    const college = validateRequestStep(
      1,
      { ...base, organizingEntity: "college", entityDetail: "medicine" },
      TODAY,
    );
    expect(college.entityDetail).toBeUndefined();
  });

  it("step 1 requires the alternate coordinator name and contact", () => {
    const empty = validateRequestStep(
      1,
      { ...base, altCoordinator: "", altCoordinatorPhone: "", altCoordinatorEmail: "" },
      TODAY,
    );
    expect(empty.altCoordinator).toBe("required");
    expect(empty.altCoordinatorPhone).toBe("required");
    expect(empty.altCoordinatorEmail).toBe("required");

    const bad = validateRequestStep(
      1,
      { ...base, altCoordinatorPhone: "123", altCoordinatorEmail: "nope" },
      TODAY,
    );
    expect(bad.altCoordinatorPhone).toBe("phone");
    expect(bad.altCoordinatorEmail).toBe("email");
  });

  it("step 2 enforces the 3-working-week lead time", () => {
    const e = validateRequestStep(2, { ...base, activityDate: "2026-07-20" }, TODAY);
    expect(e.activityDate).toBe("leadTime");
  });

  it("step 2 requires a description of at least 20 words", () => {
    const e = validateRequestStep(2, { ...base, description: "too short" }, TODAY);
    expect(e.description).toBe("descriptionLength");
    const nineteen = validateRequestStep(
      2,
      { ...base, description: Array(19).fill("w").join(" ") },
      TODAY,
    );
    expect(nineteen.description).toBe("descriptionLength");
  });

  it("step 3 conditional: off campus requires host/city/participation type", () => {
    const e = validateRequestStep(3, { ...base, venue: "off_campus" }, TODAY);
    expect(e.externalHost).toBe("required");
    expect(e.cityCountry).toBe("required");
    expect(e.externalParticipationType).toBe("required");
  });

  it("step 4 conditional: students yes requires count; partners yes requires entries", () => {
    const e = validateRequestStep(4, { ...base, hasStudents: true, hasPartners: true }, TODAY);
    expect(e.studentCount).toBe("required");
    expect(e.partners).toBe("partnersRequired");
  });

  it("step 5 requires at least one focus area with a goal", () => {
    const e = validateRequestStep(5, { ...base, alignment: [] }, TODAY);
    expect(e.alignment).toBe("alignmentRequired");
  });

  it("step 6 conditional: presenting IP requires the IP answers", () => {
    const e = validateRequestStep(6, { ...base, presentsIp: "yes" }, TODAY);
    expect(e.ipDisclosed).toBe("required");
    expect(e.ipPatent).toBe("required");
  });

  it("step 7 conditional: funding yes requires source and at least one item", () => {
    const e = validateRequestStep(7, { ...base, needsFunding: true }, TODAY);
    expect(e.fundingSource).toBe("required");
    expect(e.budgetItems).toBe("budgetRequired");
  });

  it("step 7 requires the declaration", () => {
    const e = validateRequestStep(7, { ...base, declaration: false }, TODAY);
    expect(e.declaration).toBe("declarationRequired");
  });

  it("step 5 requires the custom goal text when Other is selected", () => {
    const e = validateRequestStep(
      5,
      {
        ...base,
        alignment: [
          { focusAreaId: "ai-education", goals: ["__other__"], challenges: [] },
        ],
      },
      TODAY,
    );
    expect(e.alignment).toBe("otherGoalRequired");
  });

  it("step 5 requires the custom pathway text when Other is selected", () => {
    const e = validateRequestStep(
      5,
      { ...base, followupPathways: ["__other__"], followupOther: "" },
      TODAY,
    );
    expect(e.followupOther).toBe("required");
  });
});

describe("validateRequestFull", () => {
  it("aggregates all step errors", () => {
    const e = validateRequestFull(
      { ...base, applicantName: "", declaration: false },
      TODAY,
    );
    expect(e.applicantName).toBe("required");
    expect(e.declaration).toBe("declarationRequired");
  });

  it("clean data returns no errors", () => {
    expect(validateRequestFull(base, TODAY)).toEqual({});
  });
});
