import { describe, expect, it } from "vitest";
import { requestRowToEvent, type ApprovedRequestRow } from "./to-event";

const row: ApprovedRequestRow = {
  id: "abc",
  title: "Innovation Bootcamp",
  activity_date: "2026-09-20",
  start_time: "09:00:00",
  end_time: "15:30:00",
  request_types: ["workshop", "forum"],
  venue: "on_campus",
  location_details: "IIE Main Hall",
  organizing_entity: "institute",
};

describe("requestRowToEvent", () => {
  it("maps a request row to an EventItem with localized option labels", () => {
    const e = requestRowToEvent(row);
    expect(e.id).toBe("abc");
    expect(e.name.en).toBe("Innovation Bootcamp");
    expect(e.name.ar).toBe("Innovation Bootcamp"); // single-language title
    expect(e.date).toBe("2026-09-20");
    expect(e.startTime).toBe("09:00");
    expect(e.endTime).toBe("15:30");
    expect(e.type.en).toBe("Workshop"); // first request type
    expect(e.type.ar).toBe("ورشة عمل");
    expect(e.place.en).toBe("IIE Main Hall");
    expect(e.college.en).toBe("Institute");
    expect(e.college.ar).toBe("معهد");
  });

  it("falls back to the venue label when no location details", () => {
    const e = requestRowToEvent({ ...row, location_details: null });
    expect(e.place.en).toBe("On campus");
    expect(e.place.ar).toBe("داخل الجامعة");
  });
});
