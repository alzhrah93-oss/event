import { createClient } from "@/lib/supabase/server";
import { DEMO_EVENTS, type EventItem } from "@/lib/events-data";
import { requestRowToEvent, type ApprovedRequestRow } from "./to-event";

/**
 * Approved/closed events for the public calendar and marquee, read from the
 * `public_events` view (safe columns only). Falls back to the demo events
 * while the database has no approved events, so the public site never looks
 * empty during the pilot.
 */
export async function getPublicEvents(): Promise<EventItem[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("public_events")
    .select("*")
    .order("activity_date", { ascending: true });

  if (error || !data || data.length === 0) return DEMO_EVENTS;
  return (data as ApprovedRequestRow[]).map(requestRowToEvent);
}
