import type { EventItem } from "@/lib/events-data";
import { optionLabel } from "./display";
import {
  ORGANIZING_ENTITIES,
  REQUEST_TYPES,
  VENUES,
} from "./options";

/** The columns fetched for public calendar/marquee display. */
export type ApprovedRequestRow = {
  id: string;
  title: string;
  activity_date: string;
  start_time: string;
  end_time: string;
  request_types: string[];
  venue: string;
  location_details: string | null;
  organizing_entity: string;
};

/** Map an approved request to the public EventItem card shape. */
export function requestRowToEvent(r: ApprovedRequestRow): EventItem {
  const type = r.request_types[0] ?? "event";
  const place = r.location_details
    ? { en: r.location_details, ar: r.location_details }
    : {
        en: optionLabel(VENUES, r.venue, "en"),
        ar: optionLabel(VENUES, r.venue, "ar"),
      };
  return {
    id: r.id,
    name: { en: r.title, ar: r.title },
    place,
    date: r.activity_date,
    startTime: r.start_time.slice(0, 5),
    endTime: r.end_time.slice(0, 5),
    type: {
      en: optionLabel(REQUEST_TYPES, type, "en"),
      ar: optionLabel(REQUEST_TYPES, type, "ar"),
    },
    college: {
      en: optionLabel(ORGANIZING_ENTITIES, r.organizing_entity, "en"),
      ar: optionLabel(ORGANIZING_ENTITIES, r.organizing_entity, "ar"),
    },
  };
}
