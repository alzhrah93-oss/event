/**
 * KSA working-week helpers. Working days are Sunday–Thursday;
 * the weekend is Friday and Saturday.
 *
 * The governance guide requires requests at least three working weeks
 * (15 working days) before the implementation date.
 */

const FRIDAY = 5;
const SATURDAY = 6;

function isWeekend(d: Date): boolean {
  const day = d.getUTCDay();
  return day === FRIDAY || day === SATURDAY;
}

function toIso(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** The date `n` working days after `startIso` (start day not counted). */
export function addWorkingDays(startIso: string, n: number): string {
  const d = new Date(`${startIso}T00:00:00Z`);
  let remaining = n;
  while (remaining > 0) {
    d.setUTCDate(d.getUTCDate() + 1);
    if (!isWeekend(d)) remaining--;
  }
  return toIso(d);
}

/** Is `dateIso` at least `n` working days after `todayIso`? */
export function isAtLeastWorkingDaysAhead(
  dateIso: string,
  n: number,
  todayIso: string = new Date().toISOString().slice(0, 10),
): boolean {
  return dateIso >= addWorkingDays(todayIso, n);
}

/** Minimum working days of lead time required by the governance guide. */
export const MIN_LEAD_WORKING_DAYS = 15;
