import { describe, expect, it } from "vitest";
import { addWorkingDays, isAtLeastWorkingDaysAhead } from "./working-days";

// KSA working week: Sunday–Thursday; weekend = Friday + Saturday.
describe("addWorkingDays", () => {
  it("skips the KSA weekend (Fri+Sat)", () => {
    // Wed 2026-07-15 + 3 working days -> Thu 16, Sun 19, Mon 20
    expect(addWorkingDays("2026-07-15", 3)).toBe("2026-07-20");
  });

  it("handles multiples of full weeks", () => {
    // 15 working days = 3 KSA weeks from Wed 2026-07-15 -> Wed 2026-08-05
    expect(addWorkingDays("2026-07-15", 15)).toBe("2026-08-05");
  });

  it("starts counting from the next day", () => {
    // Thu + 1 working day -> Sunday (Fri/Sat skipped)
    expect(addWorkingDays("2026-07-16", 1)).toBe("2026-07-19");
  });
});

describe("isAtLeastWorkingDaysAhead", () => {
  const today = "2026-07-15"; // Wednesday

  it("accepts a date exactly 15 working days ahead", () => {
    expect(isAtLeastWorkingDaysAhead("2026-08-05", 15, today)).toBe(true);
  });

  it("rejects one day short", () => {
    expect(isAtLeastWorkingDaysAhead("2026-08-04", 15, today)).toBe(false);
  });

  it("accepts far-future dates and rejects past dates", () => {
    expect(isAtLeastWorkingDaysAhead("2026-12-01", 15, today)).toBe(true);
    expect(isAtLeastWorkingDaysAhead("2026-07-01", 15, today)).toBe(false);
  });
});
