/** Mirrors public.event_requests (camelCase). One draft object drives the wizard. */

export type PartnerEntry = {
  name: string;
  type: string;
  hasMou: boolean;
  mouRef: string;
  hasObligation: boolean;
  obligationNote: string;
};

export type BudgetItem = {
  item: string;
  description: string;
  cost: string; // keep as string in form; server parses
  source: string;
  justification: string;
};

export type AlignmentSelection = {
  focusAreaId: string;
  goals: string[]; // english goal keys (stable identifiers); "__other__" = custom
  challenges: string[]; // grand challenge ids (only 3 areas have any); "__other__" = custom
  otherGoal?: string; // custom goal text when goals include "__other__"
  otherChallenge?: string; // custom challenge text (optional)
};

/** Sentinel value for the "Other" choice inside goals/challenges/pathways lists. */
export const OTHER_OPTION = "__other__";

export type RequestFormData = {
  // 1. Applicant
  organizingEntity: string;
  /** College slug when entity = college; typed entity name otherwise */
  entityDetail: string;
  applicantName: string;
  jobTitle: string;
  universityEmail: string;
  mobile: string;
  altCoordinator: string;
  altCoordinatorPhone: string;
  altCoordinatorEmail: string;
  // 2. Activity
  requestTypes: string[];
  title: string;
  description: string;
  activityDate: string; // ISO
  startTime: string;
  endTime: string;
  targetAudience: string[];
  expectedAttendance: string;
  activityFormat: string;
  // 3. Venue
  venue: string; // on_campus | off_campus | virtual
  externalHost: string;
  cityCountry: string;
  locationDetails: string;
  externalParticipationType: string;
  // 4. Participants
  hasStudents: boolean | null;
  studentCount: string;
  hasFaculty: boolean | null;
  facultyCount: string;
  hasPartners: boolean | null;
  // 5. Partners
  partners: PartnerEntry[];
  // 6. Alignment
  alignment: AlignmentSelection[];
  sdgs: string[];
  expectedOutputs: string[];
  followupPathways: string[]; // "other" entry pairs with followupOther text
  followupOther: string;
  // 7. IP
  presentsIp: "yes" | "no" | "unsure" | "";
  ipDisclosed: boolean | null;
  ipPrototype: boolean | null;
  ipPatent: "yes" | "no" | "in_progress" | "";
  ipUnpublished: boolean | null;
  ipNda: "yes" | "no" | "institute_decides" | "";
  // 8. Budget
  needsFunding: boolean | null;
  fundingSource: string;
  budgetItems: BudgetItem[];
  needsLabs: boolean | null;
  labsDetails: string;
  needsMaterials: boolean | null;
  materialsDetails: string;
  needsMedia: boolean | null;
  // 9. Declaration
  declaration: boolean;
};

export const EMPTY_REQUEST: RequestFormData = {
  organizingEntity: "",
  entityDetail: "",
  applicantName: "",
  jobTitle: "",
  universityEmail: "",
  mobile: "",
  altCoordinator: "",
  altCoordinatorPhone: "",
  altCoordinatorEmail: "",
  requestTypes: [],
  title: "",
  description: "",
  activityDate: "",
  startTime: "",
  endTime: "",
  targetAudience: [],
  expectedAttendance: "",
  activityFormat: "",
  venue: "",
  externalHost: "",
  cityCountry: "",
  locationDetails: "",
  externalParticipationType: "",
  hasStudents: null,
  studentCount: "",
  hasFaculty: null,
  facultyCount: "",
  hasPartners: null,
  partners: [],
  alignment: [],
  sdgs: [],
  expectedOutputs: [],
  followupPathways: [],
  followupOther: "",
  presentsIp: "",
  ipDisclosed: null,
  ipPrototype: null,
  ipPatent: "",
  ipUnpublished: null,
  ipNda: "",
  needsFunding: null,
  fundingSource: "",
  budgetItems: [],
  needsLabs: null,
  labsDetails: "",
  needsMaterials: null,
  materialsDetails: "",
  needsMedia: null,
  declaration: false,
};
