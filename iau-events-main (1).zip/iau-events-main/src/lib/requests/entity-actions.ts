"use server";

import { revalidatePath } from "next/cache";
import { getSessionProfile } from "@/lib/auth/guard";
import { createClient } from "@/lib/supabase/server";
import type { RequestStatus } from "./status";

export type EntityDecision = "approve" | "not_approve";

/**
 * Stage 0 — the head of the organizing entity (dean/manager/president) reads
 * the request and approves (forwards it to the IIE dean's queue) or rejects
 * it. A reason is required for rejection. RLS restricts the update to
 * requests routed to the head's own entity while in entity_review.
 */
export async function entityDecision(
  requestId: string,
  decision: EntityDecision,
  reason: string,
): Promise<{ ok: boolean; error?: string }> {
  const profile = await getSessionProfile();
  if (profile?.role !== "entity_head")
    return { ok: false, error: "unauthorized" };

  const trimmedReason = reason.trim();
  if (decision === "not_approve" && !trimmedReason)
    return { ok: false, error: "reasonRequired" };

  const supabase = await createClient();
  const { data: current } = await supabase
    .from("event_requests")
    .select("status")
    .eq("id", requestId)
    .single();
  if (!current || current.status !== "entity_review")
    return { ok: false, error: "notReviewable" };

  const target: RequestStatus =
    decision === "approve" ? "new" : "entity_rejected";
  const { error } = await supabase
    .from("event_requests")
    .update({
      status: target,
      entity_decision: decision,
      entity_decision_reason: trimmedReason || null,
      entity_decided_at: new Date().toISOString(),
      entity_head_id: profile.id,
    })
    .eq("id", requestId);
  if (error) return { ok: false, error: "failed" };

  await supabase.from("request_status_history").insert({
    request_id: requestId,
    from_status: current.status,
    to_status: target,
    actor_id: profile.id,
    note: trimmedReason || null,
  });

  revalidatePath("/[locale]/entity", "layout");
  return { ok: true };
}
